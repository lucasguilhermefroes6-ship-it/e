export const baseCharacterCode = `// ============================================
// OMNIVERSE CHAOS: ARENA - ARQUITETURA BASE
// Engine: Unity 2023 LTS + Custom Physics
// ============================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace OmniverseChaos.Core
{
    // ==========================================
    // ENUMS E STRUCTS BASE
    // ==========================================
    
    public enum FightingStyle
    {
        Rushdown,      // Seiya, Yuji
        Zoner,         // Harry, Arceus
        Grappler,      // Tank, Shrek
        Assassin,      // Ink Demon, SCP-4975, Man From Fog
        Trickster,     // Waluigi, Dandy
        Wildcard,      // Pilgor, Ben 10
        Heavy          // Tank, Shrek
    }
    
    public enum FlightType
    {
        FreeFligh,     // Voo livre estilo DBZ
        DoubleJump,    // Pulo duplo com air dash
        Platform,      // Baseado em plataformas
        Teleport       // Teletransporte curto
    }
    
    public enum SkillCost
    {
        Low = 15,
        Medium = 35,
        High = 60,
        Ultimate = 100
    }
    
    [System.Serializable]
    public struct CharacterStats
    {
        [Range(50, 150)] public float maxHealth;
        [Range(30, 100)] public float speed;
        [Range(40, 120)] public float weight;
        [Range(0.5f, 2f)] public float hitboxScale;
        public float staminaRegenRate;
        public float blastGainMultiplier;
    }
    
    [System.Serializable]
    public struct SkillData
    {
        public string skillName;
        public SkillCost cost;
        public float cooldown;
        public float baseDamage;
        public float range;
        public AnimationClip animation;
        public GameObject vfxPrefab;
        public AudioClip sfx;
    }

    // ==========================================
    // CLASSE BASE - TODOS PERSONAGENS HERDAM
    // ==========================================
    
    public abstract class BaseCharacter : MonoBehaviour
    {
        // ----- REFERÊNCIAS -----
        [Header("Core References")]
        protected CharacterController controller;
        protected Animator animator;
        protected AudioSource audioSource;
        protected CameraController cameraController;
        
        // ----- STATS -----
        [Header("Character Stats")]
        [SerializeField] protected CharacterStats stats;
        [SerializeField] protected FightingStyle fightingStyle;
        [SerializeField] protected FlightType flightType;
        
        // ----- BARRAS DE RECURSO -----
        protected float currentHealth;
        protected float currentStamina = 100f;
        protected float currentBlast = 0f;
        protected const float MAX_STAMINA = 100f;
        protected const float MAX_BLAST = 100f;
        
        // ----- ESTADO -----
        protected bool isGrounded;
        protected bool isFlying;
        protected bool isAttacking;
        protected bool isStunned;
        protected bool isSuperArmor;
        protected bool isInvulnerable;
        protected BaseCharacter lockedTarget;
        
        // ----- SKILLS -----
        [Header("Skills Configuration")]
        [SerializeField] protected SkillData skill1Data;
        [SerializeField] protected SkillData skill2Data;
        [SerializeField] protected SkillData ultimateData;
        
        protected Dictionary<int, float> skillCooldowns = new();
        
        // ==========================================
        // LIFECYCLE METHODS
        // ==========================================
        
        protected virtual void Awake()
        {
            controller = GetComponent<CharacterController>();
            animator = GetComponent<Animator>();
            audioSource = GetComponent<AudioSource>();
            
            currentHealth = stats.maxHealth;
            InitializeSkillCooldowns();
        }
        
        protected virtual void Update()
        {
            if (!isStunned)
            {
                HandleMovement();
                HandleFlightSystem();
                HandleSkillInput();
                RegenerateStamina();
            }
            
            UpdateCooldowns();
            UpdateAnimations();
        }
        
        protected virtual void FixedUpdate()
        {
            ApplyGravity();
            CheckGroundStatus();
        }
        
        // ==========================================
        // SISTEMA DE MOVIMENTO
        // ==========================================
        
        protected virtual void HandleMovement()
        {
            Vector3 input = new Vector3(
                Input.GetAxis("Horizontal"),
                0,
                Input.GetAxis("Vertical")
            );
            
            // Movimento relativo à câmera
            Vector3 cameraForward = Camera.main.transform.forward;
            cameraForward.y = 0;
            cameraForward.Normalize();
            
            Vector3 moveDirection = 
                cameraForward * input.z + 
                Camera.main.transform.right * input.x;
            
            // Dash com custo de stamina
            if (Input.GetButtonDown("Dash") && currentStamina >= 20f)
            {
                StartCoroutine(PerformDash(moveDirection));
            }
            
            controller.Move(moveDirection * stats.speed * Time.deltaTime);
        }
        
        protected virtual IEnumerator PerformDash(Vector3 direction)
        {
            currentStamina -= 20f;
            isInvulnerable = true;
            
            float dashDuration = 0.3f;
            float dashSpeed = stats.speed * 4f;
            
            while (dashDuration > 0)
            {
                controller.Move(direction * dashSpeed * Time.deltaTime);
                dashDuration -= Time.deltaTime;
                yield return null;
            }
            
            isInvulnerable = false;
        }
        
        // ==========================================
        // SISTEMA DE VOO - IMPLEMENTAÇÃO POR TIPO
        // ==========================================
        
        protected virtual void HandleFlightSystem()
        {
            switch (flightType)
            {
                case FlightType.FreeFlight:
                    HandleFreeFlight();
                    break;
                case FlightType.DoubleJump:
                    HandleDoubleJump();
                    break;
                case FlightType.Teleport:
                    HandleTeleport();
                    break;
            }
        }
        
        protected virtual void HandleFreeFlight()
        {
            // Voo livre estilo DBZ - consome stamina
            if (Input.GetButton("Flight") && currentStamina > 0)
            {
                isFlying = true;
                float verticalInput = Input.GetAxis("FlightVertical");
                
                Vector3 flightMove = transform.up * verticalInput;
                controller.Move(flightMove * stats.speed * Time.deltaTime);
                
                currentStamina -= 10f * Time.deltaTime;
            }
            else if (Input.GetButtonUp("Flight"))
            {
                isFlying = false;
            }
        }
        
        protected virtual void HandleDoubleJump()
        {
            // Pulo duplo com air dash
            // Implementação específica por personagem
        }
        
        protected virtual void HandleTeleport()
        {
            // Teletransporte curto - para personagens de terror
            // Implementação específica por personagem
        }
        
        // ==========================================
        // SISTEMA DE SKILLS - TEMPLATE METHOD
        // ==========================================
        
        protected virtual void HandleSkillInput()
        {
            if (Input.GetButtonDown("Skill1") && CanUseSkill(1))
            {
                ExecuteSkill1();
            }
            
            if (Input.GetButtonDown("Skill2") && CanUseSkill(2))
            {
                ExecuteSkill2();
            }
            
            if (Input.GetButtonDown("Ultimate") && CanUseUltimate())
            {
                ExecuteUltimate();
            }
        }
        
        protected bool CanUseSkill(int skillIndex)
        {
            if (isAttacking || isStunned) return false;
            if (skillCooldowns.ContainsKey(skillIndex) && 
                skillCooldowns[skillIndex] > 0) return false;
            
            float cost = skillIndex == 1 ? 
                (float)skill1Data.cost : (float)skill2Data.cost;
                
            return currentStamina >= cost;
        }
        
        protected bool CanUseUltimate()
        {
            return currentBlast >= MAX_BLAST && 
                   !isAttacking && !isStunned;
        }
        
        // ----- MÉTODOS ABSTRATOS - CADA PERSONAGEM IMPLEMENTA -----
        
        public abstract void ExecuteSkill1();
        public abstract void ExecuteSkill2();
        public abstract void ExecuteUltimate();
        public abstract void ExecutePassive();
        
        // ==========================================
        // SISTEMA DE DANO
        // ==========================================
        
        public virtual void TakeDamage(float damage, DamageType type, 
                                       Vector3 knockbackDir)
        {
            if (isInvulnerable) return;
            
            // Super armadura reduz dano mas não evita
            float finalDamage = isSuperArmor ? damage * 0.7f : damage;
            currentHealth -= finalDamage;
            
            // Ganho de Blast ao receber dano
            currentBlast += damage * stats.blastGainMultiplier;
            currentBlast = Mathf.Clamp(currentBlast, 0, MAX_BLAST);
            
            // Knockback baseado no peso
            if (!isSuperArmor)
            {
                float knockbackForce = damage * (100f / stats.weight);
                controller.Move(knockbackDir * knockbackForce);
            }
            
            // Verificar morte
            if (currentHealth <= 0)
            {
                OnDeath();
            }
            
            animator.SetTrigger("Hit");
            OnDamageReceived(damage, type);
        }
        
        protected virtual void OnDamageReceived(float damage, DamageType type)
        {
            // Hook para efeitos específicos de personagem
        }
        
        protected virtual void OnDeath()
        {
            animator.SetTrigger("Death");
            // Notificar GameManager
        }
        
        // ==========================================
        // SISTEMA DE DESTRUIÇÃO DE CENÁRIO
        // ==========================================
        
        protected void DamageEnvironment(Vector3 position, float radius, 
                                         float force)
        {
            Collider[] colliders = Physics.OverlapSphere(
                position, radius, LayerMask.GetMask("Destructible")
            );
            
            foreach (var col in colliders)
            {
                var destructible = col.GetComponent<IDestructible>();
                destructible?.TakeImpact(force, position);
            }
        }
        
        // ==========================================
        // UTILITÁRIOS
        // ==========================================
        
        protected void InitializeSkillCooldowns()
        {
            skillCooldowns[1] = 0;
            skillCooldowns[2] = 0;
            skillCooldowns[3] = 0;
        }
        
        protected void StartCooldown(int skillIndex, float duration)
        {
            skillCooldowns[skillIndex] = duration;
        }
        
        protected void UpdateCooldowns()
        {
            var keys = new List<int>(skillCooldowns.Keys);
            foreach (var key in keys)
            {
                if (skillCooldowns[key] > 0)
                    skillCooldowns[key] -= Time.deltaTime;
            }
        }
        
        protected void RegenerateStamina()
        {
            if (!isAttacking && !isFlying)
            {
                currentStamina += stats.staminaRegenRate * Time.deltaTime;
                currentStamina = Mathf.Clamp(currentStamina, 0, MAX_STAMINA);
            }
        }
        
        protected virtual void ApplyGravity()
        {
            if (!isFlying && !isGrounded)
            {
                controller.Move(Physics.gravity * Time.fixedDeltaTime);
            }
        }
        
        protected void CheckGroundStatus()
        {
            isGrounded = Physics.Raycast(
                transform.position, Vector3.down, 0.1f
            );
        }
        
        protected virtual void UpdateAnimations()
        {
            animator.SetBool("IsGrounded", isGrounded);
            animator.SetBool("IsFlying", isFlying);
            animator.SetFloat("Speed", controller.velocity.magnitude);
        }
    }
    
    // ==========================================
    // ENUM DE TIPO DE DANO
    // ==========================================
    
    public enum DamageType
    {
        Physical,
        Energy,
        Fire,
        Ice,
        Electric,
        Poison,
        Psychic,
        True  // Ignora defesa
    }
    
    // ==========================================
    // INTERFACE PARA DESTRUTÍVEIS
    // ==========================================
    
    public interface IDestructible
    {
        void TakeImpact(float force, Vector3 impactPoint);
        float GetDebrisSize();
    }
}`;

export const inkDemonCode = `// ============================================
// INK DEMON - CLASSE ESPECÍFICA
// Estilo: Assassino / Terror / Stealth
// Origin: Bendy and the Dark Revival
// ============================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace OmniverseChaos.Characters
{
    public class InkDemon : BaseCharacter
    {
        // ----- CONFIGURAÇÕES ESPECÍFICAS -----
        [Header("Ink Demon Specifics")]
        [SerializeField] private GameObject inkPuddlePrefab;
        [SerializeField] private GameObject searcherPrefab;
        [SerializeField] private GameObject darkPuddleUltimatePrefab;
        [SerializeField] private Material dissolveMaterial;
        [SerializeField] private ParticleSystem inkParticles;
        
        // ----- ESTADO ESPECÍFICO -----
        private bool isDissolvedInInk = false;
        private float dissolveTimer = 0f;
        private const float MAX_DISSOLVE_TIME = 3f;
        private List<SearcherAI> activeSearchers = new List<SearcherAI>();
        private const int MAX_SEARCHERS = 5;
        
        // ==========================================
        // INICIALIZAÇÃO
        // ==========================================
        
        protected override void Awake()
        {
            base.Awake();
            
            // Configurar stats específicos do Ink Demon
            stats = new CharacterStats
            {
                maxHealth = 85f,
                speed = 60f,
                weight = 70f,
                hitboxScale = 1.2f,
                staminaRegenRate = 8f,
                blastGainMultiplier = 1.2f
            };
            
            flightType = FlightType.Teleport;
            fightingStyle = FightingStyle.Assassin;
        }
        
        // ==========================================
        // PASSIVA: DISSOLUÇÃO EM TINTA
        // ==========================================
        
        public override void ExecutePassive()
        {
            // Ativada automaticamente ao segurar botão de agachar
            if (Input.GetButton("Crouch") && !isDissolvedInInk && 
                isGrounded && currentStamina >= 5f)
            {
                StartCoroutine(DissolveIntoInk());
            }
        }
        
        private IEnumerator DissolveIntoInk()
        {
            isDissolvedInInk = true;
            isInvulnerable = true;
            
            // Visual: personagem "derrete" no chão
            animator.SetTrigger("Dissolve");
            
            // Transição de material para efeito de tinta
            float dissolveAmount = 0f;
            while (dissolveAmount < 1f)
            {
                dissolveAmount += Time.deltaTime * 3f;
                dissolveMaterial.SetFloat("_DissolveAmount", dissolveAmount);
                yield return null;
            }
            
            // Criar poça de tinta no chão
            var puddle = Instantiate(inkPuddlePrefab, 
                transform.position, Quaternion.identity);
            
            dissolveTimer = MAX_DISSOLVE_TIME;
            
            // Movimento enquanto dissolvido (mais lento, mas invisível)
            while (dissolveTimer > 0 && Input.GetButton("Crouch"))
            {
                dissolveTimer -= Time.deltaTime;
                currentStamina -= 5f * Time.deltaTime;
                
                // Movimento como "poça" no chão
                Vector3 input = new Vector3(
                    Input.GetAxis("Horizontal"), 0, 
                    Input.GetAxis("Vertical")
                );
                transform.Translate(input * (stats.speed * 0.6f) * 
                    Time.deltaTime, Space.World);
                
                // Mover visual da poça junto
                puddle.transform.position = transform.position;
                
                if (currentStamina <= 0) break;
                yield return null;
            }
            
            // Emergir da tinta
            yield return StartCoroutine(EmergeFromInk());
            Destroy(puddle);
        }
        
        private IEnumerator EmergeFromInk()
        {
            animator.SetTrigger("Emerge");
            
            float dissolveAmount = 1f;
            while (dissolveAmount > 0f)
            {
                dissolveAmount -= Time.deltaTime * 3f;
                dissolveMaterial.SetFloat("_DissolveAmount", dissolveAmount);
                yield return null;
            }
            
            isDissolvedInInk = false;
            isInvulnerable = false;
        }
        
        // ==========================================
        // SKILL 1: TINTA CORROSIVA
        // Custo: Baixo (15 Stamina)
        // Dano: 8% + 2%/s por 4 segundos
        // ==========================================
        
        public override void ExecuteSkill1()
        {
            currentStamina -= (float)SkillCost.Low;
            isAttacking = true;
            
            animator.SetTrigger("InkSpray");
            StartCoroutine(CorrosiveInkRoutine());
            StartCooldown(1, skill1Data.cooldown);
        }
        
        private IEnumerator CorrosiveInkRoutine()
        {
            // Esperar animação de preparação
            yield return new WaitForSeconds(0.3f);
            
            // Criar projétil de tinta
            Vector3 direction = lockedTarget != null ? 
                (lockedTarget.transform.position - transform.position).normalized :
                transform.forward;
            
            var inkProjectile = Instantiate(
                inkPuddlePrefab, 
                transform.position + direction * 1.5f,
                Quaternion.LookRotation(direction)
            );
            
            // Configurar projétil
            var projectile = inkProjectile.GetComponent<InkProjectile>();
            projectile.Initialize(
                direction * 25f,  // velocidade
                8f,               // dano inicial
                2f,               // DoT por segundo
                4f,               // duração do DoT
                this              // referência ao dono
            );
            
            // Efeito visual: reduzir visão do inimigo
            projectile.OnHit += (target) =>
            {
                var enemy = target.GetComponent<BaseCharacter>();
                if (enemy != null)
                {
                    StartCoroutine(ApplyVisionReduction(enemy, 4f));
                }
            };
            
            yield return new WaitForSeconds(0.5f);
            isAttacking = false;
        }
        
        private IEnumerator ApplyVisionReduction(BaseCharacter target, 
                                                  float duration)
        {
            // Aplicar efeito de pós-processamento no inimigo
            var visionEffect = target.GetComponent<VisionEffects>();
            if (visionEffect != null)
            {
                visionEffect.ApplyInkBlur(0.6f); // 60% de blur
                yield return new WaitForSeconds(duration);
                visionEffect.ClearEffects();
            }
        }
        
        // ==========================================
        // SKILL 2: INVOCAÇÃO DE SEARCHERS
        // Custo: Médio (35 Stamina)
        // Dano: 6% cada (até 18% total)
        // ==========================================
        
        public override void ExecuteSkill2()
        {
            currentStamina -= (float)SkillCost.Medium;
            isAttacking = true;
            
            animator.SetTrigger("SummonSearchers");
            StartCoroutine(SummonSearchersRoutine());
            StartCooldown(2, skill2Data.cooldown);
        }
        
        private IEnumerator SummonSearchersRoutine()
        {
            // Limpar Searchers antigos se exceder limite
            CleanupOldSearchers();
            
            yield return new WaitForSeconds(0.5f);
            
            // Criar 3 Searchers em posições ao redor
            Vector3[] spawnOffsets = new Vector3[]
            {
                new Vector3(-2f, -0.5f, 1f),
                new Vector3(0f, -0.5f, 2f),
                new Vector3(2f, -0.5f, 1f)
            };
            
            foreach (var offset in spawnOffsets)
            {
                Vector3 spawnPos = transform.position + 
                    transform.TransformDirection(offset);
                
                // Efeito: Searchers emergem do chão
                SpawnSearcherWithEffect(spawnPos);
                
                yield return new WaitForSeconds(0.2f);
            }
            
            isAttacking = false;
        }
        
        private void SpawnSearcherWithEffect(Vector3 position)
        {
            // Efeito de tinta emergindo
            inkParticles.transform.position = position;
            inkParticles.Play();
            
            // Criar Searcher
            var searcher = Instantiate(searcherPrefab, 
                position, Quaternion.identity);
            
            var searcherAI = searcher.GetComponent<SearcherAI>();
            searcherAI.Initialize(
                lockedTarget?.transform,  // alvo
                6f,                        // dano ao tocar
                8f,                        // velocidade de perseguição
                10f                        // tempo de vida
            );
            
            activeSearchers.Add(searcherAI);
            
            // Searcher se destrói após causar dano
            searcherAI.OnDamageDealt += (amount) =>
            {
                activeSearchers.Remove(searcherAI);
                Destroy(searcher);
            };
        }
        
        private void CleanupOldSearchers()
        {
            while (activeSearchers.Count >= MAX_SEARCHERS)
            {
                var oldest = activeSearchers[0];
                activeSearchers.RemoveAt(0);
                if (oldest != null)
                    Destroy(oldest.gameObject);
            }
        }
        
        // ==========================================
        // ULTIMATE: THE DARK PUDDLE
        // Custo: 100 Blast
        // Dano: 45%
        // ==========================================
        
        public override void ExecuteUltimate()
        {
            if (!CanUseUltimate()) return;
            
            currentBlast = 0f;
            StartCoroutine(TheDarkPuddleRoutine());
        }
        
        private IEnumerator TheDarkPuddleRoutine()
        {
            // Verificar se há alvo no range
            if (lockedTarget == null || 
                Vector3.Distance(transform.position, 
                    lockedTarget.transform.position) > 15f)
            {
                // Falhou - muito longe
                animator.SetTrigger("UltimateFail");
                yield break;
            }
            
            // ===== FASE 1: PREPARAÇÃO =====
            isAttacking = true;
            isInvulnerable = true;
            
            // Pausar tempo do jogo (efeito cinematográfico)
            Time.timeScale = 0.3f;
            
            animator.SetTrigger("UltimateStart");
            
            // Criar poça gigante sob o inimigo
            var darkPuddle = Instantiate(
                darkPuddleUltimatePrefab,
                lockedTarget.transform.position,
                Quaternion.identity
            );
            
            darkPuddle.transform.localScale = Vector3.zero;
            
            // Expandir poça
            float expandTime = 0f;
            while (expandTime < 1f)
            {
                expandTime += Time.unscaledDeltaTime * 2f;
                darkPuddle.transform.localScale = 
                    Vector3.Lerp(Vector3.zero, Vector3.one * 10f, expandTime);
                yield return null;
            }
            
            // ===== FASE 2: PUXAR PARA O ABISMO =====
            
            // Aplicar força de sucção no inimigo
            var enemyRb = lockedTarget.GetComponent<Rigidbody>();
            Vector3 pullCenter = darkPuddle.transform.position;
            
            float pullDuration = 1.5f;
            while (pullDuration > 0)
            {
                Vector3 pullDir = (pullCenter - 
                    lockedTarget.transform.position).normalized;
                lockedTarget.transform.position += 
                    pullDir * 5f * Time.unscaledDeltaTime;
                
                // Inimigo afunda gradualmente
                lockedTarget.transform.position -= 
                    Vector3.up * 2f * Time.unscaledDeltaTime;
                
                pullDuration -= Time.unscaledDeltaTime;
                yield return null;
            }
            
            // ===== FASE 3: CUTSCENE DO MUNDO DE TINTA =====
            
            // Transição de tela para preto
            yield return StartCoroutine(
                CinematicManager.Instance.FadeToBlack(0.5f));
            
            // Trocar para câmera cinematográfica
            CinematicManager.Instance.PlayCutscene("InkDemon_DarkPuddle");
            
            // Cena: Interior do mundo de tinta
            // - Inimigo submerso em tinta
            // - Ink Demon emerge como criatura gigante
            // - Tentáculos de tinta atacam de todas as direções
            
            yield return new WaitForSecondsRealtime(3f);
            
            // Aplicar dano
            lockedTarget.TakeDamage(45f, DamageType.Psychic, Vector3.up);
            
            // ===== FASE 4: RETORNO =====
            
            yield return StartCoroutine(
                CinematicManager.Instance.FadeFromBlack(0.5f));
            
            // Inimigo é "cuspido" da poça
            lockedTarget.transform.position = 
                pullCenter + Vector3.up * 3f;
            
            var knockback = (lockedTarget.transform.position - 
                transform.position).normalized * 15f + Vector3.up * 8f;
            
            if (enemyRb != null)
                enemyRb.AddForce(knockback, ForceMode.Impulse);
            
            // Limpar
            Destroy(darkPuddle);
            Time.timeScale = 1f;
            isAttacking = false;
            isInvulnerable = false;
        }
        
        // ==========================================
        // OVERRIDE DE TELETRANSPORTE
        // ==========================================
        
        protected override void HandleTeleport()
        {
            if (Input.GetButtonDown("Flight") && currentStamina >= 25f)
            {
                StartCoroutine(InkTeleport());
            }
        }
        
        private IEnumerator InkTeleport()
        {
            currentStamina -= 25f;
            
            // Efeito: dissolver rapidamente
            animator.SetTrigger("QuickDissolve");
            
            yield return new WaitForSeconds(0.2f);
            
            // Calcular posição de destino
            Vector3 teleportDir = lockedTarget != null ?
                (lockedTarget.transform.position - transform.position).normalized :
                transform.forward;
            
            Vector3 destination = transform.position + teleportDir * 8f;
            
            // Verificar se destino é válido
            if (Physics.Raycast(destination + Vector3.up * 5f, 
                Vector3.down, out RaycastHit hit, 10f))
            {
                destination = hit.point + Vector3.up * 0.5f;
            }
            
            // Teletransportar
            transform.position = destination;
            
            // Efeito: emergir
            animator.SetTrigger("QuickEmerge");
            inkParticles.Play();
        }
        
        // ==========================================
        // HOOK PERSONALIZADO DE DANO
        // ==========================================
        
        protected override void OnDamageReceived(float damage, DamageType type)
        {
            base.OnDamageReceived(damage, type);
            
            // Se receber dano enquanto HP está baixo, chance de 
            // auto-dissolve defensivo
            if (currentHealth < stats.maxHealth * 0.3f && 
                Random.Range(0f, 1f) > 0.7f && !isDissolvedInInk)
            {
                StartCoroutine(EmergencyDissolve());
            }
        }
        
        private IEnumerator EmergencyDissolve()
        {
            // Dissolve rápido de emergência (0.5s de i-frames)
            isInvulnerable = true;
            animator.SetTrigger("EmergencyDissolve");
            
            yield return new WaitForSeconds(0.5f);
            
            isInvulnerable = false;
        }
    }
    
    // ==========================================
    // CLASSES AUXILIARES
    // ==========================================
    
    public class InkProjectile : MonoBehaviour
    {
        public System.Action<Collider> OnHit;
        
        private Vector3 velocity;
        private float initialDamage;
        private float dotDamage;
        private float dotDuration;
        private BaseCharacter owner;
        
        public void Initialize(Vector3 vel, float initDmg, 
            float dot, float dotDur, BaseCharacter own)
        {
            velocity = vel;
            initialDamage = initDmg;
            dotDamage = dot;
            dotDuration = dotDur;
            owner = own;
        }
        
        private void Update()
        {
            transform.position += velocity * Time.deltaTime;
        }
        
        private void OnTriggerEnter(Collider other)
        {
            if (other.gameObject == owner.gameObject) return;
            
            var target = other.GetComponent<BaseCharacter>();
            if (target != null)
            {
                // Dano inicial
                target.TakeDamage(initialDamage, DamageType.Poison, 
                    velocity.normalized);
                
                // Aplicar DoT
                target.StartCoroutine(ApplyDoT(target));
                
                OnHit?.Invoke(other);
            }
            
            Destroy(gameObject);
        }
        
        private IEnumerator ApplyDoT(BaseCharacter target)
        {
            float timer = dotDuration;
            while (timer > 0)
            {
                target.TakeDamage(dotDamage, DamageType.Poison, Vector3.zero);
                yield return new WaitForSeconds(1f);
                timer -= 1f;
            }
        }
    }
    
    public class SearcherAI : MonoBehaviour
    {
        public System.Action<float> OnDamageDealt;
        
        private Transform target;
        private float damage;
        private float speed;
        private float lifetime;
        
        public void Initialize(Transform t, float d, float s, float l)
        {
            target = t;
            damage = d;
            speed = s;
            lifetime = l;
        }
        
        private void Update()
        {
            lifetime -= Time.deltaTime;
            if (lifetime <= 0)
            {
                Destroy(gameObject);
                return;
            }
            
            if (target != null)
            {
                Vector3 dir = (target.position - transform.position).normalized;
                transform.position += dir * speed * Time.deltaTime;
                transform.LookAt(target);
            }
        }
        
        private void OnTriggerEnter(Collider other)
        {
            var character = other.GetComponent<BaseCharacter>();
            if (character != null && character.transform != target?.root)
            {
                character.TakeDamage(damage, DamageType.Physical, 
                    (other.transform.position - transform.position).normalized);
                OnDamageDealt?.Invoke(damage);
            }
        }
    }
}`;

export const ben10Code = `// ============================================
// BEN 10 - CLASSE ESPECÍFICA
// Estilo: Stance Switcher (Troca de Formas)
// Origin: Ben 10
// ============================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace OmniverseChaos.Characters
{
    // Enum para as formas alienígenas
    public enum AlienForm
    {
        Human,
        XLR8,
        FourArms,
        AlienX
    }
    
    public class Ben10 : BaseCharacter
    {
        // ----- CONFIGURAÇÕES ESPECÍFICAS -----
        [Header("Ben 10 Specifics")]
        [SerializeField] private float transformationDuration = 8f;
        [SerializeField] private float omnitrixCooldown = 4f;
        
        [Header("Form Prefabs & Data")]
        [SerializeField] private AlienFormData xlr8Data;
        [SerializeField] private AlienFormData fourArmsData;
        [SerializeField] private AlienFormData alienXData;
        
        [Header("VFX")]
        [SerializeField] private ParticleSystem transformVFX;
        [SerializeField] private GameObject omnitrixGlow;
        [SerializeField] private Material greenFlashMaterial;
        
        // ----- ESTADO ESPECÍFICO -----
        private AlienForm currentForm = AlienForm.Human;
        private float formTimer = 0f;
        private float omnitrixCooldownTimer = 0f;
        private bool isTransforming = false;
        private CharacterStats originalStats;
        private SkinnedMeshRenderer characterMesh;
        private Mesh[] alienMeshes;
        
        // ----- STATS POR FORMA -----
        private Dictionary<AlienForm, CharacterStats> formStats;
        
        // ==========================================
        // INICIALIZAÇÃO
        // ==========================================
        
        protected override void Awake()
        {
            base.Awake();
            
            // Stats base do Ben humano
            originalStats = new CharacterStats
            {
                maxHealth = 95f,
                speed = 75f,
                weight = 60f,
                hitboxScale = 1f,
                staminaRegenRate = 10f,
                blastGainMultiplier = 1.1f
            };
            
            stats = originalStats;
            flightType = FlightType.DoubleJump;
            fightingStyle = FightingStyle.Wildcard;
            
            InitializeFormStats();
        }
        
        private void InitializeFormStats()
        {
            formStats = new Dictionary<AlienForm, CharacterStats>
            {
                // XLR8: Velocidade extrema, baixa defesa
                { AlienForm.XLR8, new CharacterStats
                    {
                        maxHealth = 70f,
                        speed = 150f,  // Velocidade 2x
                        weight = 40f,
                        hitboxScale = 0.9f,
                        staminaRegenRate = 15f,
                        blastGainMultiplier = 0.8f
                    }
                },
                
                // Four Arms: Força bruta, lento mas tanque
                { AlienForm.FourArms, new CharacterStats
                    {
                        maxHealth = 140f,
                        speed = 45f,
                        weight = 130f,
                        hitboxScale = 1.5f,
                        staminaRegenRate = 6f,
                        blastGainMultiplier = 1.3f
                    }
                },
                
                // Alien X: Poder absoluto (só no Ultimate)
                { AlienForm.AlienX, new CharacterStats
                    {
                        maxHealth = 200f,
                        speed = 80f,
                        weight = 100f,
                        hitboxScale = 1.3f,
                        staminaRegenRate = 0f,
                        blastGainMultiplier = 0f
                    }
                }
            };
        }
        
        // ==========================================
        // UPDATE - GERENCIAR TRANSFORMAÇÕES
        // ==========================================
        
        protected override void Update()
        {
            base.Update();
            
            // Atualizar timer de transformação
            if (currentForm != AlienForm.Human && 
                currentForm != AlienForm.AlienX)
            {
                formTimer -= Time.deltaTime;
                
                // Visual: Omnitrix pisca quando acabando
                if (formTimer <= 2f)
                {
                    OmnitrixWarningBlink();
                }
                
                if (formTimer <= 0f)
                {
                    StartCoroutine(RevertToHuman());
                }
            }
            
            // Cooldown do Omnitrix
            if (omnitrixCooldownTimer > 0)
            {
                omnitrixCooldownTimer -= Time.deltaTime;
            }
        }
        
        // ==========================================
        // PASSIVA: OMNITRIX
        // Troca entre formas com cooldown
        // ==========================================
        
        public override void ExecutePassive()
        {
            // A passiva é o próprio sistema de transformação
            // Gerenciado pelas Skills
        }
        
        // ==========================================
        // SKILL 1: TRANSFORMAÇÃO XLR8
        // Custo: Baixo (15 Stamina)
        // Efeito: Velocidade 150%, ataques rápidos
        // ==========================================
        
        public override void ExecuteSkill1()
        {
            if (!CanTransform()) return;
            
            currentStamina -= (float)SkillCost.Low;
            StartCoroutine(TransformTo(AlienForm.XLR8));
            StartCooldown(1, omnitrixCooldown);
        }
        
        private IEnumerator XLR8Behavior()
        {
            // Enquanto em forma XLR8, ataques básicos viram combos rápidos
            while (currentForm == AlienForm.XLR8)
            {
                if (Input.GetButtonDown("Attack"))
                {
                    yield return StartCoroutine(XLR8ComboAttack());
                }
                yield return null;
            }
        }
        
        private IEnumerator XLR8ComboAttack()
        {
            isAttacking = true;
            
            // Combo de 8 hits em 1 segundo
            int hits = 8;
            float damagePerHit = 3f;
            
            for (int i = 0; i < hits; i++)
            {
                animator.SetTrigger("XLR8_Hit" + (i % 4));
                
                // Detectar inimigos no range
                Collider[] enemies = Physics.OverlapSphere(
                    transform.position + transform.forward * 2f,
                    2f,
                    LayerMask.GetMask("Character")
                );
                
                foreach (var enemy in enemies)
                {
                    var character = enemy.GetComponent<BaseCharacter>();
                    if (character != null && character != this)
                    {
                        character.TakeDamage(
                            damagePerHit, 
                            DamageType.Physical,
                            transform.forward
                        );
                    }
                }
                
                yield return new WaitForSeconds(0.125f);
            }
            
            isAttacking = false;
        }
        
        // ==========================================
        // SKILL 2: TRANSFORMAÇÃO QUATRO BRAÇOS
        // Custo: Médio (35 Stamina)
        // Efeito: Super Armadura, Agarrões Devastadores
        // ==========================================
        
        public override void ExecuteSkill2()
        {
            if (!CanTransform()) return;
            
            currentStamina -= (float)SkillCost.Medium;
            StartCoroutine(TransformTo(AlienForm.FourArms));
            StartCooldown(2, omnitrixCooldown);
        }
        
        private IEnumerator FourArmsBehavior()
        {
            // Ativar Super Armadura
            isSuperArmor = true;
            
            while (currentForm == AlienForm.FourArms)
            {
                // Ataque especial: Agarrão com 4 braços
                if (Input.GetButtonDown("Attack"))
                {
                    yield return StartCoroutine(FourArmsGrab());
                }
                
                // Ataque secundário: Palmas Sísmicas
                if (Input.GetButton("Attack") && Input.GetButton("Skill1"))
                {
                    yield return StartCoroutine(SeismicClap());
                }
                
                yield return null;
            }
            
            isSuperArmor = false;
        }
        
        private IEnumerator FourArmsGrab()
        {
            isAttacking = true;
            animator.SetTrigger("FourArms_Grab");
            
            yield return new WaitForSeconds(0.3f);
            
            // Tentar agarrar inimigo à frente
            RaycastHit hit;
            if (Physics.SphereCast(
                transform.position,
                1.5f,
                transform.forward,
                out hit,
                3f,
                LayerMask.GetMask("Character")))
            {
                var enemy = hit.collider.GetComponent<BaseCharacter>();
                if (enemy != null)
                {
                    yield return StartCoroutine(
                        ExecuteGrabSequence(enemy));
                }
            }
            
            isAttacking = false;
        }
        
        private IEnumerator ExecuteGrabSequence(BaseCharacter enemy)
        {
            // Prender inimigo
            enemy.isStunned = true;
            
            // Animação: Levantar inimigo com 4 braços
            animator.SetTrigger("FourArms_Lift");
            enemy.transform.SetParent(transform);
            
            yield return new WaitForSeconds(0.5f);
            
            // Esmagar inimigo no chão
            animator.SetTrigger("FourArms_Slam");
            
            yield return new WaitForSeconds(0.3f);
            
            // Dano + Destruição de cenário
            enemy.TakeDamage(20f, DamageType.Physical, Vector3.down * 2f);
            enemy.transform.SetParent(null);
            enemy.isStunned = false;
            
            // Destruir chão
            DamageEnvironment(enemy.transform.position, 5f, 1000f);
            
            // Criar cratera
            CreateCrater(enemy.transform.position, 3f);
        }
        
        private IEnumerator SeismicClap()
        {
            isAttacking = true;
            animator.SetTrigger("FourArms_Clap");
            
            yield return new WaitForSeconds(0.5f);
            
            // Onda de choque em área
            Collider[] affected = Physics.OverlapSphere(
                transform.position, 8f, 
                LayerMask.GetMask("Character", "Destructible")
            );
            
            foreach (var col in affected)
            {
                var character = col.GetComponent<BaseCharacter>();
                if (character != null && character != this)
                {
                    Vector3 knockback = 
                        (col.transform.position - transform.position)
                        .normalized * 20f + Vector3.up * 5f;
                    
                    character.TakeDamage(15f, DamageType.Physical, knockback);
                }
                
                var destructible = col.GetComponent<IDestructible>();
                destructible?.TakeImpact(500f, transform.position);
            }
            
            isAttacking = false;
        }
        
        // ==========================================
        // ULTIMATE: ALIEN X
        // Custo: 100 Blast
        // Efeito: Manipulação da Realidade (3 segundos)
        // Dano: 80%
        // ==========================================
        
        public override void ExecuteUltimate()
        {
            if (!CanUseUltimate()) return;
            
            currentBlast = 0f;
            StartCoroutine(AlienXTransformation());
        }
        
        private IEnumerator AlienXTransformation()
        {
            isTransforming = true;
            isInvulnerable = true;
            
            // ===== FASE 1: TRANSFORMAÇÃO ÉPICA =====
            
            // Slow-motion
            Time.timeScale = 0.2f;
            
            // Flash verde do Omnitrix
            omnitrixGlow.SetActive(true);
            var glowIntensity = omnitrixGlow
                .GetComponent<Light>().intensity;
            
            float flashTime = 0f;
            while (flashTime < 1f)
            {
                flashTime += Time.unscaledDeltaTime * 2f;
                omnitrixGlow.GetComponent<Light>().intensity = 
                    Mathf.Lerp(1f, 50f, flashTime);
                yield return null;
            }
            
            // Trocar modelo para Alien X
            yield return StartCoroutine(
                MorphToAlien(alienXData.mesh, alienXData.materials));
            
            currentForm = AlienForm.AlienX;
            stats = formStats[AlienForm.AlienX];
            
            Time.timeScale = 1f;
            
            // ===== FASE 2: PAUSA CÓSMICA =====
            
            // Alien X para o tempo para todos menos ele
            GameManager.Instance.FreezeAllExcept(this, 3f);
            
            // Cutscene: Espaço com estrelas ao redor
            CinematicManager.Instance.SetCosmicBackground(true);
            
            // Voz de Alien X
            AudioManager.Instance.PlayVoiceLine("AlienX_Reality");
            
            // ===== FASE 3: MANIPULAÇÃO DA REALIDADE =====
            
            yield return new WaitForSeconds(1f);
            
            // Animação de gesto de alteração da realidade
            animator.SetTrigger("AlienX_Manipulate");
            
            // Criar efeito de "apagar" parte do inimigo
            if (lockedTarget != null)
            {
                yield return StartCoroutine(
                    EraseFromExistence(lockedTarget));
            }
            
            yield return new WaitForSeconds(1f);
            
            // ===== FASE 4: DANO MASSIVO =====
            
            if (lockedTarget != null)
            {
                // Dano = 80% da vida máxima do alvo
                float damage = lockedTarget.stats.maxHealth * 0.80f;
                lockedTarget.TakeDamage(
                    damage, DamageType.True, Vector3.zero);
            }
            
            // ===== FASE 5: REVERSÃO =====
            
            yield return new WaitForSeconds(1f);
            
            CinematicManager.Instance.SetCosmicBackground(false);
            GameManager.Instance.UnfreezeAll();
            
            // Forçar reversão (Alien X é instável)
            yield return StartCoroutine(ForceRevertToHuman());
            
            isTransforming = false;
            isInvulnerable = false;
            
            // Cooldown longo após Alien X
            omnitrixCooldownTimer = 15f;
        }
        
        private IEnumerator EraseFromExistence(BaseCharacter target)
        {
            // Visual: Partes do inimigo se tornam transparentes/glitchadas
            var renderer = target.GetComponentInChildren<Renderer>();
            var material = renderer.material;
            
            // Efeito de dissolução cósmica
            material.SetFloat("_CosmicDissolve", 0f);
            
            float dissolveProgress = 0f;
            while (dissolveProgress < 0.7f)
            {
                dissolveProgress += Time.deltaTime * 0.5f;
                material.SetFloat("_CosmicDissolve", dissolveProgress);
                
                // Estrelas aparecem onde o corpo "some"
                SpawnCosmicParticles(target.transform.position);
                
                yield return null;
            }
            
            // Restaurar visual (mas dano já foi aplicado)
            material.SetFloat("_CosmicDissolve", 0f);
        }
        
        // ==========================================
        // SISTEMA DE TRANSFORMAÇÃO CORE
        // ==========================================
        
        private bool CanTransform()
        {
            return omnitrixCooldownTimer <= 0 && 
                   !isTransforming && 
                   !isAttacking &&
                   currentForm == AlienForm.Human;
        }
        
        private IEnumerator TransformTo(AlienForm form)
        {
            isTransforming = true;
            isInvulnerable = true;
            
            // Animação do Omnitrix
            animator.SetTrigger("OmnitrixSlam");
            transformVFX.Play();
            
            // Flash verde
            yield return StartCoroutine(GreenFlash(0.5f));
            
            // Trocar stats e visual
            currentForm = form;
            stats = formStats[form];
            formTimer = transformationDuration;
            
            // Trocar mesh/materiais baseado na forma
            switch (form)
            {
                case AlienForm.XLR8:
                    yield return StartCoroutine(
                        MorphToAlien(xlr8Data.mesh, xlr8Data.materials));
                    StartCoroutine(XLR8Behavior());
                    break;
                    
                case AlienForm.FourArms:
                    yield return StartCoroutine(
                        MorphToAlien(fourArmsData.mesh, fourArmsData.materials));
                    StartCoroutine(FourArmsBehavior());
                    break;
            }
            
            isTransforming = false;
            isInvulnerable = false;
        }
        
        private IEnumerator RevertToHuman()
        {
            isTransforming = true;
            
            // Flash vermelho (timeout)
            animator.SetTrigger("OmnitrixTimeout");
            
            yield return StartCoroutine(RedFlash(0.3f));
            
            // Reverter stats e visual
            currentForm = AlienForm.Human;
            stats = originalStats;
            isSuperArmor = false;
            
            yield return StartCoroutine(MorphToHuman());
            
            isTransforming = false;
            omnitrixCooldownTimer = omnitrixCooldown;
        }
        
        private IEnumerator ForceRevertToHuman()
        {
            // Reversão forçada de Alien X (mais dramática)
            isTransforming = true;
            
            // Alien X "colapsa" em si mesmo
            animator.SetTrigger("AlienX_Collapse");
            
            yield return new WaitForSeconds(1f);
            
            // Flash branco intenso
            yield return StartCoroutine(WhiteFlash(0.5f));
            
            currentForm = AlienForm.Human;
            stats = originalStats;
            
            yield return StartCoroutine(MorphToHuman());
            
            isTransforming = false;
        }
        
        // ==========================================
        // HELPERS VISUAIS
        // ==========================================
        
        private IEnumerator MorphToAlien(Mesh mesh, Material[] materials)
        {
            // Transição suave de mesh
            float t = 0f;
            while (t < 1f)
            {
                t += Time.deltaTime * 5f;
                // Blend shape ou morph target aqui
                yield return null;
            }
            
            characterMesh.sharedMesh = mesh;
            characterMesh.materials = materials;
        }
        
        private IEnumerator MorphToHuman()
        {
            yield return StartCoroutine(
                MorphToAlien(alienMeshes[0], new[] { greenFlashMaterial }));
        }
        
        private IEnumerator GreenFlash(float duration)
        {
            var overlay = UIManager.Instance.screenFlash;
            overlay.color = new Color(0, 1, 0, 0);
            overlay.gameObject.SetActive(true);
            
            float t = 0f;
            while (t < duration / 2)
            {
                t += Time.deltaTime;
                overlay.color = new Color(0, 1, 0, t / (duration / 2));
                yield return null;
            }
            
            while (t < duration)
            {
                t += Time.deltaTime;
                overlay.color = new Color(0, 1, 0, 
                    1 - (t - duration / 2) / (duration / 2));
                yield return null;
            }
            
            overlay.gameObject.SetActive(false);
        }
        
        private IEnumerator RedFlash(float duration)
        {
            // Similar ao GreenFlash mas vermelho
            yield return null;
        }
        
        private IEnumerator WhiteFlash(float duration)
        {
            // Similar ao GreenFlash mas branco
            yield return null;
        }
        
        private void OmnitrixWarningBlink()
        {
            // Piscar vermelho quando transformação está acabando
            float blinkIntensity = Mathf.PingPong(Time.time * 4f, 1f);
            omnitrixGlow.GetComponent<Light>().color = 
                Color.Lerp(Color.green, Color.red, blinkIntensity);
        }
        
        private void SpawnCosmicParticles(Vector3 position)
        {
            // Spawnar partículas de estrelas
        }
        
        private void CreateCrater(Vector3 position, float radius)
        {
            // Deformar terreno para criar cratera
        }
    }
    
    // ==========================================
    // STRUCT PARA DADOS DE FORMA ALIENÍGENA
    // ==========================================
    
    [System.Serializable]
    public struct AlienFormData
    {
        public string alienName;
        public Mesh mesh;
        public Material[] materials;
        public RuntimeAnimatorController animatorController;
        public AudioClip transformSound;
        public AudioClip[] voiceLines;
    }
}`;

export const cameraSystemCode = `// ============================================
// SISTEMA DE CÂMERA E LOCK-ON
// Omniverse Chaos: Arena
// ============================================

using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace OmniverseChaos.Camera
{
    // ==========================================
    // CONFIGURAÇÃO DE ESCALA POR PERSONAGEM
    // ==========================================
    
    public enum CharacterScale
    {
        Tiny,      // Pilgor (cabra)
        Small,     // Ben 10 humano, Waluigi
        Medium,    // Seiya, Yuji, Harry
        Large,     // Shrek, Tank
        Huge,      // Arceus, Four Arms
        Colossal   // Formas especiais (Demon Goat, etc)
    }
    
    [System.Serializable]
    public struct CameraScaleSettings
    {
        public CharacterScale scale;
        public float baseDistance;         // Distância base da câmera
        public float heightOffset;         // Altura em relação ao pivot
        public float fovMultiplier;        // Multiplicador de FOV
        public Vector2 lockOnPointOffset;  // Offset do ponto de mira
        public float minZoomDistance;      // Zoom mínimo permitido
        public float maxZoomDistance;      // Zoom máximo permitido
    }

    // ==========================================
    // CÂMERA PRINCIPAL - OVER THE SHOULDER
    // ==========================================
    
    public class ArenaCameraController : MonoBehaviour
    {
        // ----- REFERÊNCIAS -----
        [Header("References")]
        public Transform playerTransform;
        public Transform lockedTarget;
        private Camera mainCamera;
        
        // ----- CONFIGURAÇÕES BASE -----
        [Header("Base Settings")]
        [SerializeField] private float baseFOV = 60f;
        [SerializeField] private float baseDistance = 5f;
        [SerializeField] private float baseHeight = 2f;
        [SerializeField] private float shoulderOffset = 1.2f;
        
        [Header("Sensitivity")]
        [SerializeField] private float horizontalSensitivity = 3f;
        [SerializeField] private float verticalSensitivity = 2f;
        [SerializeField] private float zoomSpeed = 5f;
        
        // ----- LIMITES -----
        [Header("Limits")]
        [SerializeField] private float minVerticalAngle = -30f;
        [SerializeField] private float maxVerticalAngle = 60f;
        [SerializeField] private float minDistance = 2f;
        [SerializeField] private float maxDistance = 25f;
        
        // ----- LOCK-ON -----
        [Header("Lock-On System")]
        [SerializeField] private float lockOnRange = 50f;
        [SerializeField] private float lockOnAngle = 60f;
        [SerializeField] private LayerMask lockOnLayers;
        [SerializeField] private float lockOnSwitchCooldown = 0.3f;
        
        // ----- AJUSTES DINÂMICOS -----
        [Header("Dynamic Adjustments")]
        [SerializeField] private List<CameraScaleSettings> scaleSettings;
        [SerializeField] private float transitionSpeed = 3f;
        [SerializeField] private float combatZoomOut = 1.3f;
        
        // ----- ESTADO -----
        private bool isLockedOn = false;
        private float currentDistance;
        private float currentHeight;
        private float currentYaw;
        private float currentPitch;
        private float targetFOV;
        private float lastLockSwitchTime;
        
        // Cache de escala
        private CameraScaleSettings playerScaleSettings;
        private CameraScaleSettings targetScaleSettings;
        
        // ==========================================
        // INICIALIZAÇÃO
        // ==========================================
        
        private void Awake()
        {
            mainCamera = GetComponent<Camera>();
            currentDistance = baseDistance;
            currentHeight = baseHeight;
            targetFOV = baseFOV;
            
            Cursor.lockState = CursorLockMode.Locked;
            Cursor.visible = false;
        }
        
        private void Start()
        {
            // Pegar escala inicial do jogador
            UpdatePlayerScale();
        }
        
        // ==========================================
        // UPDATE PRINCIPAL
        // ==========================================
        
        private void LateUpdate()
        {
            if (playerTransform == null) return;
            
            // Atualizar escala se necessário
            UpdateScaleBasedOnCombat();
            
            if (isLockedOn && lockedTarget != null)
            {
                UpdateLockedCamera();
            }
            else
            {
                UpdateFreeCamera();
            }
            
            // Aplicar FOV com lerp suave
            mainCamera.fieldOfView = Mathf.Lerp(
                mainCamera.fieldOfView, targetFOV, 
                Time.deltaTime * transitionSpeed
            );
            
            // Collision avoidance
            HandleCameraCollision();
        }
        
        // ==========================================
        // CÂMERA LIVRE (SEM LOCK-ON)
        // ==========================================
        
        private void UpdateFreeCamera()
        {
            // Input do mouse/controle
            float mouseX = Input.GetAxis("Mouse X") * horizontalSensitivity;
            float mouseY = Input.GetAxis("Mouse Y") * verticalSensitivity;
            float scroll = Input.GetAxis("Mouse ScrollWheel") * zoomSpeed;
            
            // Atualizar ângulos
            currentYaw += mouseX;
            currentPitch -= mouseY;
            currentPitch = Mathf.Clamp(currentPitch, 
                minVerticalAngle, maxVerticalAngle);
            
            // Atualizar distância (zoom)
            currentDistance -= scroll;
            currentDistance = Mathf.Clamp(currentDistance,
                playerScaleSettings.minZoomDistance,
                playerScaleSettings.maxZoomDistance);
            
            // Calcular posição da câmera
            Quaternion rotation = Quaternion.Euler(currentPitch, currentYaw, 0);
            
            Vector3 targetPos = playerTransform.position + 
                Vector3.up * (currentHeight + playerScaleSettings.heightOffset);
            
            // Offset de ombro (over the shoulder)
            Vector3 shoulderPos = targetPos + 
                rotation * Vector3.right * shoulderOffset;
            
            Vector3 cameraPos = shoulderPos - 
                rotation * Vector3.forward * currentDistance;
            
            // Aplicar com suavização
            transform.position = Vector3.Lerp(
                transform.position, cameraPos, 
                Time.deltaTime * 10f
            );
            
            transform.LookAt(targetPos);
        }
        
        // ==========================================
        // CÂMERA COM LOCK-ON
        // ==========================================
        
        private void UpdateLockedCamera()
        {
            if (lockedTarget == null)
            {
                DisableLockOn();
                return;
            }
            
            // Calcular distância entre jogador e alvo
            float distanceToTarget = Vector3.Distance(
                playerTransform.position, 
                lockedTarget.position
            );
            
            // ===== AJUSTE DINÂMICO DE CÂMERA =====
            
            // Calcular diferença de escala
            float scaleDifference = GetScaleDifference();
            
            // Ponto médio entre jogador e alvo
            // (ajustado pela escala - personagens maiores "puxam" 
            //  o ponto médio para eles)
            Vector3 midPoint = CalculateWeightedMidpoint(scaleDifference);
            
            // Distância da câmera baseada na distância do combate
            float dynamicDistance = CalculateDynamicDistance(
                distanceToTarget, scaleDifference
            );
            
            // Altura baseada no personagem mais alto
            float dynamicHeight = CalculateDynamicHeight(scaleDifference);
            
            // ===== POSICIONAMENTO =====
            
            // Direção do jogador para o alvo
            Vector3 combatDir = 
                (lockedTarget.position - playerTransform.position).normalized;
            combatDir.y = 0;
            
            // Câmera atrás do jogador, olhando para o alvo
            Vector3 cameraOffset = -combatDir * dynamicDistance + 
                Vector3.up * dynamicHeight;
            
            // Offset lateral (over the shoulder) ajustado
            Vector3 lateralOffset = Vector3.Cross(Vector3.up, combatDir) * 
                (shoulderOffset * playerScaleSettings.fovMultiplier);
            
            Vector3 targetCameraPos = playerTransform.position + 
                cameraOffset + lateralOffset;
            
            // Suavização
            transform.position = Vector3.Lerp(
                transform.position, targetCameraPos,
                Time.deltaTime * 8f
            );
            
            // ===== LOOK AT =====
            
            // Calcular ponto de foco (entre os dois personagens, 
            // ajustado pela escala)
            Vector3 focusPoint = CalculateFocusPoint(scaleDifference);
            
            Quaternion targetRotation = 
                Quaternion.LookRotation(focusPoint - transform.position);
            
            transform.rotation = Quaternion.Slerp(
                transform.rotation, targetRotation, 
                Time.deltaTime * 6f
            );
            
            // ===== FOV DINÂMICO =====
            
            // Aumentar FOV quando lutando contra personagens grandes
            // ou quando estão longe
            targetFOV = baseFOV * 
                Mathf.Lerp(1f, combatZoomOut, scaleDifference) * 
                Mathf.Lerp(1f, 1.2f, distanceToTarget / 30f);
        }
        
        // ==========================================
        // CÁLCULOS DE ESCALA DINÂMICA
        // ==========================================
        
        private float GetScaleDifference()
        {
            // Retorna 0-1 onde 1 = máxima diferença de escala
            float playerScale = (float)GetCharacterScale(playerTransform);
            float targetScale = (float)GetCharacterScale(lockedTarget);
            
            float diff = Mathf.Abs(playerScale - targetScale);
            return diff / 5f; // Normalizar para 0-1
        }
        
        private Vector3 CalculateWeightedMidpoint(float scaleDiff)
        {
            if (lockedTarget == null) return playerTransform.position;
            
            // Personagens maiores "puxam" o ponto médio para eles
            float playerWeight = 1f / (1f + playerScaleSettings.fovMultiplier);
            float targetWeight = 1f / (1f + targetScaleSettings.fovMultiplier);
            
            // Normalizar pesos
            float totalWeight = playerWeight + targetWeight;
            playerWeight /= totalWeight;
            targetWeight /= totalWeight;
            
            Vector3 playerPos = playerTransform.position + 
                Vector3.up * playerScaleSettings.heightOffset;
            Vector3 targetPos = lockedTarget.position + 
                Vector3.up * targetScaleSettings.heightOffset;
            
            return playerPos * playerWeight + targetPos * targetWeight;
        }
        
        private float CalculateDynamicDistance(float combatDist, float scaleDiff)
        {
            // Base: distância mínima do jogador
            float baseD = playerScaleSettings.baseDistance;
            
            // Adicionar baseado na distância de combate
            float combatFactor = Mathf.Clamp01(combatDist / 30f);
            
            // Adicionar baseado na diferença de escala
            float scaleFactor = 1f + scaleDiff * 0.5f;
            
            // Se lutando contra personagem gigante, afastar mais
            if (targetScaleSettings.scale >= CharacterScale.Huge)
            {
                scaleFactor *= 1.3f;
            }
            
            return baseD * scaleFactor * (1f + combatFactor * 0.5f);
        }
        
        private float CalculateDynamicHeight(float scaleDiff)
        {
            // Pegar a maior altura entre os dois
            float maxHeight = Mathf.Max(
                playerScaleSettings.heightOffset,
                targetScaleSettings.heightOffset
            );
            
            // Subir a câmera quando há diferença de escala grande
            float heightBonus = scaleDiff * 3f;
            
            return baseHeight + maxHeight + heightBonus;
        }
        
        private Vector3 CalculateFocusPoint(float scaleDiff)
        {
            if (lockedTarget == null) return playerTransform.position;
            
            Vector3 playerCenter = playerTransform.position + 
                Vector3.up * playerScaleSettings.heightOffset * 0.7f;
            
            Vector3 targetCenter = lockedTarget.position + 
                Vector3.up * targetScaleSettings.heightOffset * 0.7f;
            
            // Foco mais próximo do jogador quando inimigo é gigante
            // (para não perder o jogador de vista)
            float focusBias = 0.5f;
            if (targetScaleSettings.scale >= CharacterScale.Huge)
            {
                focusBias = 0.35f; // Mais próximo do jogador
            }
            else if (targetScaleSettings.scale <= CharacterScale.Small)
            {
                focusBias = 0.65f; // Mais próximo do alvo (pequeno)
            }
            
            return Vector3.Lerp(playerCenter, targetCenter, focusBias);
        }
        
        // ==========================================
        // SISTEMA DE LOCK-ON
        // ==========================================
        
        public void ToggleLockOn()
        {
            if (isLockedOn)
            {
                DisableLockOn();
            }
            else
            {
                TryLockOn();
            }
        }
        
        private void TryLockOn()
        {
            // Encontrar alvos no range
            Collider[] potentialTargets = Physics.OverlapSphere(
                playerTransform.position, lockOnRange, lockOnLayers
            );
            
            Transform bestTarget = null;
            float bestScore = float.MaxValue;
            
            foreach (var col in potentialTargets)
            {
                if (col.transform == playerTransform) continue;
                
                // Verificar ângulo
                Vector3 dirToTarget = 
                    col.transform.position - playerTransform.position;
                float angle = Vector3.Angle(transform.forward, dirToTarget);
                
                if (angle > lockOnAngle) continue;
                
                // Score baseado em distância e ângulo
                float distance = dirToTarget.magnitude;
                float score = distance + angle * 0.5f;
                
                // Priorizar personagens visíveis
                if (!Physics.Raycast(playerTransform.position + Vector3.up,
                    dirToTarget.normalized, distance, 
                    LayerMask.GetMask("Environment")))
                {
                    score *= 0.5f; // Bônus para alvos visíveis
                }
                
                if (score < bestScore)
                {
                    bestScore = score;
                    bestTarget = col.transform;
                }
            }
            
            if (bestTarget != null)
            {
                EnableLockOn(bestTarget);
            }
        }
        
        private void EnableLockOn(Transform target)
        {
            lockedTarget = target;
            isLockedOn = true;
            
            // Atualizar configurações de escala do alvo
            UpdateTargetScale();
            
            // Notificar UI para mostrar indicador
            UIManager.Instance.ShowLockOnIndicator(target);
            
            // Audio feedback
            AudioManager.Instance.PlaySFX("LockOn");
        }
        
        private void DisableLockOn()
        {
            lockedTarget = null;
            isLockedOn = false;
            
            UIManager.Instance.HideLockOnIndicator();
        }
        
        public void SwitchLockOnTarget(int direction)
        {
            // direction: -1 = esquerda, 1 = direita
            if (!isLockedOn || Time.time - lastLockSwitchTime < 
                lockOnSwitchCooldown) return;
            
            lastLockSwitchTime = Time.time;
            
            // Encontrar próximo alvo na direção
            Collider[] potentialTargets = Physics.OverlapSphere(
                playerTransform.position, lockOnRange, lockOnLayers
            );
            
            List<Transform> validTargets = new List<Transform>();
            
            foreach (var col in potentialTargets)
            {
                if (col.transform == playerTransform || 
                    col.transform == lockedTarget) continue;
                
                validTargets.Add(col.transform);
            }
            
            if (validTargets.Count == 0) return;
            
            // Ordenar por posição relativa à câmera
            validTargets.Sort((a, b) =>
            {
                Vector3 toA = a.position - transform.position;
                Vector3 toB = b.position - transform.position;
                
                float angleA = Vector3.SignedAngle(
                    transform.forward, toA, Vector3.up);
                float angleB = Vector3.SignedAngle(
                    transform.forward, toB, Vector3.up);
                
                return direction > 0 ? 
                    angleA.CompareTo(angleB) : 
                    angleB.CompareTo(angleA);
            });
            
            // Selecionar próximo alvo
            EnableLockOn(validTargets[0]);
        }
        
        // ==========================================
        // COLISÃO DE CÂMERA
        // ==========================================
        
        private void HandleCameraCollision()
        {
            Vector3 targetPos = isLockedOn ? 
                CalculateWeightedMidpoint(GetScaleDifference()) : 
                playerTransform.position + Vector3.up * currentHeight;
            
            Vector3 direction = transform.position - targetPos;
            float distance = direction.magnitude;
            
            RaycastHit hit;
            if (Physics.SphereCast(
                targetPos, 0.3f, direction.normalized, 
                out hit, distance, LayerMask.GetMask("Environment")))
            {
                // Mover câmera para frente do obstáculo
                transform.position = hit.point + hit.normal * 0.5f;
            }
        }
        
        // ==========================================
        // HELPERS
        // ==========================================
        
        private CharacterScale GetCharacterScale(Transform character)
        {
            var baseChar = character.GetComponent<BaseCharacter>();
            if (baseChar != null)
            {
                return GetScaleFromHitbox(baseChar.stats.hitboxScale);
            }
            return CharacterScale.Medium;
        }
        
        private CharacterScale GetScaleFromHitbox(float hitboxScale)
        {
            if (hitboxScale < 0.7f) return CharacterScale.Tiny;
            if (hitboxScale < 0.9f) return CharacterScale.Small;
            if (hitboxScale < 1.2f) return CharacterScale.Medium;
            if (hitboxScale < 1.6f) return CharacterScale.Large;
            if (hitboxScale < 2.5f) return CharacterScale.Huge;
            return CharacterScale.Colossal;
        }
        
        private void UpdatePlayerScale()
        {
            var scale = GetCharacterScale(playerTransform);
            playerScaleSettings = scaleSettings.Find(s => s.scale == scale);
        }
        
        private void UpdateTargetScale()
        {
            if (lockedTarget != null)
            {
                var scale = GetCharacterScale(lockedTarget);
                targetScaleSettings = scaleSettings.Find(s => s.scale == scale);
            }
        }
        
        private void UpdateScaleBasedOnCombat()
        {
            // Atualizar se as escalas mudaram (ex: Ben 10 transformou)
            UpdatePlayerScale();
            if (lockedTarget != null)
                UpdateTargetScale();
        }
    }
    
    // ==========================================
    // CONFIGURAÇÕES PADRÃO DE ESCALA
    // ==========================================
    
    /*
    CONFIGURAÇÕES RECOMENDADAS:
    
    Tiny (Pilgor):
    - baseDistance: 3.5f
    - heightOffset: 0.8f
    - fovMultiplier: 0.9f
    - lockOnPointOffset: (0, -0.3f)
    - minZoom: 2f, maxZoom: 8f
    
    Small (Ben 10, Waluigi):
    - baseDistance: 4f
    - heightOffset: 1.5f
    - fovMultiplier: 1f
    - lockOnPointOffset: (0, 0)
    - minZoom: 2.5f, maxZoom: 12f
    
    Medium (Seiya, Yuji, Harry):
    - baseDistance: 5f
    - heightOffset: 1.8f
    - fovMultiplier: 1f
    - lockOnPointOffset: (0, 0)
    - minZoom: 3f, maxZoom: 15f
    
    Large (Shrek, Tank):
    - baseDistance: 6.5f
    - heightOffset: 2.5f
    - fovMultiplier: 1.1f
    - lockOnPointOffset: (0, 0.3f)
    - minZoom: 4f, maxZoom: 20f
    
    Huge (Arceus, Four Arms):
    - baseDistance: 10f
    - heightOffset: 4f
    - fovMultiplier: 1.25f
    - lockOnPointOffset: (0, 1f)
    - minZoom: 6f, maxZoom: 25f
    
    Colossal (Demon Goat, formas especiais):
    - baseDistance: 15f
    - heightOffset: 8f
    - fovMultiplier: 1.4f
    - lockOnPointOffset: (0, 2f)
    - minZoom: 10f, maxZoom: 35f
    */
}`;
