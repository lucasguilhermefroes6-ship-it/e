export interface CharacterSkill {
  name: string;
  cost: 'Baixo' | 'Médio' | 'Alto' | 'Blast Completo';
  description: string;
  cooldown: number;
  damage: string;
}

export interface Character {
  id: string;
  name: string;
  origin: string;
  style: string;
  archetype: string;
  flightType: 'Voo Livre' | 'Pulo Duplo' | 'Plataforma' | 'Teletransporte';
  health: number;
  speed: number;
  weight: number;
  passive?: string;
  skill1: CharacterSkill;
  skill2: CharacterSkill;
  ultimate: CharacterSkill;
  icon: string;
  color: string;
}

export const characters: Character[] = [
  {
    id: 'ink-demon',
    name: 'Ink Demon',
    origin: 'Bendy and the Dark Revival',
    style: 'Terror/Stealth',
    archetype: 'Assassino',
    flightType: 'Teletransporte',
    health: 85,
    speed: 60,
    weight: 70,
    passive: 'Dissolução em Tinta: Pode se dissolver no chão para evitar ataques e se mover invisível por 3 segundos.',
    skill1: {
      name: 'Tinta Corrosiva',
      cost: 'Baixo',
      description: 'Dispara um jato de tinta que causa dano contínuo (DoT) por 4 segundos e reduz a visão do oponente.',
      cooldown: 5,
      damage: '8% + 2%/s por 4s'
    },
    skill2: {
      name: 'Invocação de Searchers',
      cost: 'Médio',
      description: 'Invoca 3 Searchers do chão que perseguem o inimigo. Cada um causa dano ao tocar e desaparece.',
      cooldown: 12,
      damage: '6% cada (18% total)'
    },
    ultimate: {
      name: 'The Dark Puddle',
      cost: 'Blast Completo',
      description: 'Ink Demon cria uma poça gigante de tinta que suga o oponente para o mundo de tinta. Cutscene de afogamento onde o inimigo é devorado pela escuridão.',
      cooldown: 0,
      damage: '45%'
    },
    icon: '🖤',
    color: 'from-gray-900 to-amber-800'
  },
  {
    id: 'vapor',
    name: 'Vapor',
    origin: 'Pillar Chase 2 (Roblox)',
    style: 'Hit-and-Run',
    archetype: 'Speedster',
    flightType: 'Teletransporte',
    health: 75,
    speed: 95,
    weight: 40,
    passive: 'Forma Intangível: A cada 20 segundos, o próximo ataque recebido é ignorado.',
    skill1: {
      name: 'Crânios Flutuantes',
      cost: 'Baixo',
      description: 'Dispara 3 crânios que perseguem o inimigo em padrão errático. Causam stun leve ao acertar.',
      cooldown: 6,
      damage: '4% cada'
    },
    skill2: {
      name: 'Cortina de Fumaça',
      cost: 'Médio',
      description: 'Libera fumaça densa em área. Inimigos dentro têm visão reduzida e Vapor ganha 50% de velocidade extra.',
      cooldown: 15,
      damage: '0% (Utilitário)'
    },
    ultimate: {
      name: 'Jump Scare Takedown',
      cost: 'Blast Completo',
      description: 'A tela pisca em preto e branco. Vapor aparece gigante atrás do inimigo e executa sua animação de morte clássica do Roblox.',
      cooldown: 0,
      damage: '50%'
    },
    icon: '💨',
    color: 'from-purple-900 to-gray-700'
  },
  {
    id: 'pilgor',
    name: 'Pilgor',
    origin: 'Goat Simulator',
    style: 'Joke Character / Physics Based',
    archetype: 'Wildcard',
    flightType: 'Pulo Duplo',
    health: 90,
    speed: 70,
    weight: 50,
    passive: 'Ragdoll Physics: Quando derrubado, pode "bugar" e causar dano aleatório em área ao cair.',
    skill1: {
      name: 'Cabeçada Insana',
      cost: 'Baixo',
      description: 'Cabeçada com knockback extremamente alto. Pode arremessar inimigos contra paredes para dano extra.',
      cooldown: 4,
      damage: '10% + 8% (colisão)'
    },
    skill2: {
      name: 'Língua-Gancho',
      cost: 'Médio',
      description: 'A língua funciona como grappling hook. Puxa o inimigo até Pilgor ou puxa Pilgor até cenários.',
      cooldown: 8,
      damage: '5% + Setup'
    },
    ultimate: {
      name: 'Ritual Pentagram',
      cost: 'Blast Completo',
      description: 'Pilgor transforma-se em Demon Goat. A física do jogo "quebra" - a gravidade inverte e o oponente é arremessado para fora do mapa em slow-motion.',
      cooldown: 0,
      damage: '55%'
    },
    icon: '🐐',
    color: 'from-orange-600 to-red-800'
  },
  {
    id: 'shrek',
    name: 'Shrek',
    origin: 'Shrek',
    style: 'Tank / Brawler',
    archetype: 'Heavy',
    flightType: 'Pulo Duplo',
    health: 130,
    speed: 45,
    weight: 100,
    passive: 'Camadas de Cebola: Ganha redução de dano progressiva (5%/10%/15%) quanto menos HP tiver.',
    skill1: {
      name: 'Do the Roar!',
      cost: 'Baixo',
      description: 'Shrek grita ferozmente, causando stun em área cônica à frente. Inimigos próximos são empurrados.',
      cooldown: 8,
      damage: '6% + Stun 1.5s'
    },
    skill2: {
      name: 'Cebola Explosiva',
      cost: 'Médio',
      description: 'Arremessa uma cebola que explode em 3 ondas concêntricas. Cada onda causa dano e slow.',
      cooldown: 10,
      damage: '12% (centro) + 8% (meio) + 4% (borda)'
    },
    ultimate: {
      name: 'Get Out of My Swamp!',
      cost: 'Blast Completo',
      description: 'Shrek assobia para a Dragão de Burro. Ela cuspir fogo massivo enquanto Shrek carrega um soco devastador. O inimigo é pego entre fogo e punho.',
      cooldown: 0,
      damage: '60%'
    },
    icon: '🧅',
    color: 'from-green-700 to-green-900'
  },
  {
    id: 'waluigi',
    name: 'Waluigi',
    origin: 'Mario Series',
    style: 'Técnico / Trapaceiro',
    archetype: 'Trickster',
    flightType: 'Pulo Duplo',
    health: 88,
    speed: 78,
    weight: 55,
    passive: 'Número 1 Injustiçado: Ao ser acertado 3 vezes seguidas, ganha um contra-ataque automático gratuito.',
    skill1: {
      name: 'Raquete de Tênis',
      cost: 'Baixo',
      description: 'Rebate projéteis de volta com 150% do dano original. Contra melee, funciona como golpe rápido.',
      cooldown: 3,
      damage: '7% ou Reflexão'
    },
    skill2: {
      name: 'Rose Whip',
      cost: 'Médio',
      description: 'Chicote de rosas com espinhos. Alcance médio, pode prender inimigos por 1 segundo se acertar a ponta.',
      cooldown: 9,
      damage: '14% + Bind'
    },
    ultimate: {
      name: 'Negative Zone Dance',
      cost: 'Blast Completo',
      description: 'Waluigi dança enquanto pétalas de rosa caem. Inimigos na área têm seus controles invertidos por 4 segundos, seguido de um chute final estilizado.',
      cooldown: 0,
      damage: '35% + Confusão 4s'
    },
    icon: '💜',
    color: 'from-purple-600 to-purple-900'
  },
  {
    id: 'seiya',
    name: 'Seiya de Pégaso',
    origin: 'Saint Seiya',
    style: 'Rushdown / Velocidade Extrema',
    archetype: 'Rushdown',
    flightType: 'Voo Livre',
    health: 90,
    speed: 100,
    weight: 60,
    passive: 'Cosmo Ardente: Combos longos (5+ hits) aumentam o dano em 2% por hit adicional.',
    skill1: {
      name: 'Meteoro de Pégaso',
      cost: 'Baixo',
      description: 'Rajada de 100 golpes em 2 segundos. Cada hit é fraco, mas o volume é devastador. Pode ser bloqueado.',
      cooldown: 6,
      damage: '0.5% x hits (até 25%)'
    },
    skill2: {
      name: 'Turbilhão de Pégaso',
      cost: 'Médio',
      description: 'Seiya gira em alta velocidade criando um furacão de cosmos. Atrai inimigos para o centro.',
      cooldown: 12,
      damage: '18%'
    },
    ultimate: {
      name: 'Cometa de Pégaso',
      cost: 'Blast Completo',
      description: 'Seiya veste a Armadura de Ouro de Sagitário temporariamente. Dispara a Flecha Dourada que atravessa o oponente em uma cutscene celestial.',
      cooldown: 0,
      damage: '65%'
    },
    icon: '⭐',
    color: 'from-blue-500 to-gold-400'
  },
  {
    id: 'man-from-fog',
    name: 'The Man From The Fog',
    origin: 'Minecraft Dweller Mod',
    style: 'Horror Sobrenatural',
    archetype: 'Assassino',
    flightType: 'Teletransporte',
    health: 95,
    speed: 85,
    weight: 80,
    passive: 'Tick-Tock: Um som de relógio aumenta conforme ele se aproxima. Inimigos próximos têm dano reduzido em 10% pelo medo.',
    skill1: {
      name: 'Raio do Vazio',
      cost: 'Baixo',
      description: 'Teletransporta com um raio, reaparecendo atrás do inimigo. O raio causa dano leve na área de partida.',
      cooldown: 7,
      damage: '8%'
    },
    skill2: {
      name: 'Névoa Cegante',
      cost: 'Médio',
      description: 'Cega o oponente por 3 segundos. Durante esse tempo, Man From The Fog fica invisível e ganha 20% de dano.',
      cooldown: 18,
      damage: '0% + Buff'
    },
    ultimate: {
      name: 'Midnight Stalk',
      cost: 'Blast Completo',
      description: 'O cenário vira noite instantaneamente. Man From The Fog ataca de múltiplas direções como sombras, culminando em um jumpscare com dano massivo.',
      cooldown: 0,
      damage: '55%'
    },
    icon: '🌫️',
    color: 'from-slate-800 to-blue-950'
  },
  {
    id: 'dandy',
    name: 'Dandy',
    origin: "Dandy's World (Roblox)",
    style: 'Item User / RNG',
    archetype: 'Sorte',
    flightType: 'Pulo Duplo',
    health: 85,
    speed: 65,
    weight: 55,
    passive: 'Loja Ambulante: A cada 15 segundos, ganha um item aleatório no inventário (máximo 3).',
    skill1: {
      name: 'Roleta de Itens',
      cost: 'Baixo',
      description: 'Usa um item aleatório: Fita Adesiva (prende), Medkit (cura 10%), Bala de Canhão (dano), Banana (slow).',
      cooldown: 5,
      damage: 'Variável'
    },
    skill2: {
      name: 'Armadilha de Fitas',
      cost: 'Médio',
      description: 'Coloca 3 armadilhas invisíveis no chão. Inimigos que pisam ficam presos e recebem dano contínuo.',
      cooldown: 14,
      damage: '5% + 3%/s por 3s'
    },
    ultimate: {
      name: 'Twisted Form',
      cost: 'Blast Completo',
      description: 'Dandy revela sua forma monstruosa/corrompida. Ataca freneticamente com fitas contaminadas que drenam vida.',
      cooldown: 0,
      damage: '40% + Lifesteal 20%'
    },
    icon: '🎪',
    color: 'from-yellow-500 to-red-600'
  },
  {
    id: 'yuji',
    name: 'Yuji Itadori',
    origin: 'Jujutsu Kaisen',
    style: 'Close Combat / Striker',
    archetype: 'Striker',
    flightType: 'Pulo Duplo',
    health: 100,
    speed: 88,
    weight: 65,
    passive: 'Força Sobre-Humana: Ataques básicos têm 15% de chance de causar knockdown.',
    skill1: {
      name: 'Divergent Fist',
      cost: 'Baixo',
      description: 'Soco com impacto atrasado. O primeiro hit causa dano, e 0.3s depois vem o segundo impacto maior.',
      cooldown: 5,
      damage: '6% + 10% (delay)'
    },
    skill2: {
      name: 'Arremesso de Destroços',
      cost: 'Médio',
      description: 'Arranca um pedaço do cenário e arremessa. Dano baseado no tamanho do objeto. Destrói ambiente.',
      cooldown: 10,
      damage: '15-25%'
    },
    ultimate: {
      name: 'Black Flash Chain',
      cost: 'Blast Completo',
      description: 'Yuji entra em estado de concentração máxima. Executa 4 Black Flashes consecutivos com distorção espacial. Cada hit causa flash preto na tela.',
      cooldown: 0,
      damage: '70%'
    },
    icon: '⚫',
    color: 'from-pink-500 to-purple-700'
  },
  {
    id: 'harry',
    name: 'Harry Potter',
    origin: 'Harry Potter',
    style: 'Zoner (Luta à distância)',
    archetype: 'Zoner',
    flightType: 'Voo Livre',
    health: 75,
    speed: 72,
    weight: 45,
    passive: 'Voo de Vassoura: Pode montar na Firebolt para mobilidade extrema, mas recebe 20% mais dano enquanto voa.',
    skill1: {
      name: 'Expelliarmus',
      cost: 'Baixo',
      description: 'Desarma o oponente, cancelando o próximo ataque especial dele. Também funciona como deflect de projéteis.',
      cooldown: 6,
      damage: '5% + Desarme'
    },
    skill2: {
      name: 'Stupefy + Incendio',
      cost: 'Médio',
      description: 'Combo de feitiços: Stupefy atordoa e Incendio causa dano flamejante em área.',
      cooldown: 11,
      damage: '18% + Stun 1s'
    },
    ultimate: {
      name: 'Expecto Patronum',
      cost: 'Blast Completo',
      description: 'Harry conjura Prongs, o cervo patrono gigante. O cervo atropela o inimigo, seguido por um Sectumsempra devastador.',
      cooldown: 0,
      damage: '50%'
    },
    icon: '⚡',
    color: 'from-blue-800 to-amber-500'
  },
  {
    id: 'ben10',
    name: 'Ben 10',
    origin: 'Ben 10',
    style: 'Stance Switcher',
    archetype: 'Transformador',
    flightType: 'Pulo Duplo',
    health: 95,
    speed: 75,
    weight: 60,
    passive: 'Omnitrix: Pode trocar entre 3 formas. Cada forma dura 8 segundos antes de voltar a Ben humano.',
    skill1: {
      name: 'Transformação: XLR8',
      cost: 'Baixo',
      description: 'Transforma em XLR8. Ganha velocidade 150% e ataques rápidos em sequência. Ideal para combos.',
      cooldown: 4,
      damage: '3% x hits'
    },
    skill2: {
      name: 'Transformação: Quatro Braços',
      cost: 'Médio',
      description: 'Transforma em Quatro Braços. Super armadura, agarrões devastadores e arremesso de inimigos.',
      cooldown: 10,
      damage: '20% (agarrão)'
    },
    ultimate: {
      name: 'Alien X',
      cost: 'Blast Completo',
      description: 'Ben transforma-se em Alien X por 3 segundos. O tempo para para todos menos para ele. Manipula a realidade para "apagar" parte da existência do inimigo.',
      cooldown: 0,
      damage: '80%'
    },
    icon: '👽',
    color: 'from-green-500 to-emerald-700'
  },
  {
    id: 'tank',
    name: 'Tank',
    origin: 'Left 4 Dead',
    style: 'Juggernaut',
    archetype: 'Grappler',
    flightType: 'Pulo Duplo',
    health: 150,
    speed: 35,
    weight: 120,
    passive: 'Super Armadura: Não pode ser interrompido durante ataques. Imune a stun e knockback leve.',
    skill1: {
      name: 'Arremesso de Concreto',
      cost: 'Baixo',
      description: 'Arranca um pedaço de concreto do chão e arremessa. Projétil pesado com knockdown garantido.',
      cooldown: 7,
      damage: '12%'
    },
    skill2: {
      name: 'Charge Imparável',
      cost: 'Médio',
      description: 'Corre em linha reta. Qualquer coisa no caminho é atropelada. Destrói cenário e causa dano em área.',
      cooldown: 14,
      damage: '22%'
    },
    ultimate: {
      name: 'Horde Call',
      cost: 'Blast Completo',
      description: 'Tank ruge chamando a horda. Zumbis comuns emergem e seguram o inimigo imóvel. Tank então esmaga o oponente com um carro inteiro.',
      cooldown: 0,
      damage: '65%'
    },
    icon: '🧟',
    color: 'from-gray-600 to-red-900'
  },
  {
    id: 'arceus',
    name: 'Arceus',
    origin: 'Pokémon',
    style: 'Boss Character / Zoner Divino',
    archetype: 'Divino',
    flightType: 'Voo Livre',
    health: 120,
    speed: 60,
    weight: 90,
    passive: 'Criador: Imune a efeitos de controle (stun, slow, confuse) por mais de 1 segundo.',
    skill1: {
      name: 'Judgment',
      cost: 'Baixo',
      description: 'Chama meteoros de luz do céu. Área de efeito grande, difícil de esquivar, mas com delay de 1 segundo.',
      cooldown: 8,
      damage: '14%'
    },
    skill2: {
      name: 'Troca de Tipo',
      cost: 'Médio',
      description: 'Troca entre tipos: Normal (balanceado), Fogo (DoT), Gelo (slow), Elétrico (stun). Muda resistências e efeitos.',
      cooldown: 5,
      damage: '0% (Stance)'
    },
    ultimate: {
      name: 'Creation & Destruction',
      cost: 'Blast Completo',
      description: 'Arceus reinicia o universo. Cutscene branca onde tudo é desfeito e recriado. O oponente tem sua vida reduzida para 1 HP, independente do valor atual.',
      cooldown: 0,
      damage: 'Reduz para 1 HP'
    },
    icon: '✨',
    color: 'from-yellow-300 to-emerald-400'
  },
  {
    id: 'scp-4975',
    name: "SCP-4975 'Time's Up'",
    origin: 'Fundação SCP',
    style: 'Assassino / Psicológico',
    archetype: 'Horror',
    flightType: 'Teletransporte',
    health: 88,
    speed: 90,
    weight: 65,
    passive: "Tick-Tock: Som de relógio aumenta conforme se aproxima. A cada 10 segundos perto do inimigo, o dano do próximo ataque aumenta em 10%.",
    skill1: {
      name: 'Bicada Perfurante',
      cost: 'Baixo',
      description: 'Bicada rápida que ignora 50% da defesa do oponente. Baixo dano mas atravessa guard.',
      cooldown: 4,
      damage: '9% (ignora defesa)'
    },
    skill2: {
      name: 'Camuflagem Predatória',
      cost: 'Médio',
      description: 'Fica 80% invisível por 5 segundos. Movimento não faz barulho. Próximo ataque causa 40% a mais de dano.',
      cooldown: 16,
      damage: '0% + Buff'
    },
    ultimate: {
      name: 'Predation Event',
      cost: 'Blast Completo',
      description: 'O oponente fica paralisado pelo medo puro. SCP-4975 emerge da escuridão lentamente para um ataque fatal no pescoço. Cutscene perturbadora.',
      cooldown: 0,
      damage: '58%'
    },
    icon: '🦅',
    color: 'from-stone-800 to-black'
  }
];
