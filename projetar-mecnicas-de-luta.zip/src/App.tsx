import { useEffect } from 'react';
import { useGameStore } from './store/gameStore';
import { GameScene } from './components/GameScene';
import { GameHUD } from './components/GameUI';
import { MainMenu, CharacterSelect, RoundEnd, GameOver, PauseMenu } from './components/Menus';
import { UltimateCutscene } from './components/UltimateCutscenes';

function App() {
  const { gameState, setKey } = useGameStore();
  
  // Global key listener for menu navigation
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Enter' && gameState === 'menu') {
        useGameStore.getState().startGame();
      }
    };
    
    // Clear all keys on blur (prevent stuck keys)
    const handleBlur = () => {
      const keys = ['w', 'a', 's', 'd', ' ', 'q', 'e', 'r', 'f', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'];
      keys.forEach(key => setKey(key, false));
    };
    
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('blur', handleBlur);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('blur', handleBlur);
    };
  }, [gameState, setKey]);
  
  return (
    <div className="w-screen h-screen bg-black overflow-hidden relative">
      {/* 3D Game Scene */}
      <GameScene />
      
      {/* UI Overlays */}
      <GameHUD />
      <UltimateCutscene />
      
      {/* Menus */}
      <MainMenu />
      <CharacterSelect />
      <RoundEnd />
      <GameOver />
      <PauseMenu />
      
      {/* Loading indicator for when game is starting */}
      {gameState === 'fighting' && (
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none opacity-0 animate-pulse">
          <div className="text-4xl font-bold text-white">FIGHT!</div>
        </div>
      )}
    </div>
  );
}

export default App;
