import { useRef, useEffect } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { Vector3 } from 'three';
import { useGameStore } from '../store/gameStore';
import { Arena, Skybox } from './Arena';
import { Fighter } from './Fighter';
import { Projectiles, Effects } from './Projectiles';

function CameraController() {
  const { player1, player2, player3, player4, gameMode, cameraShake, setCameraShake, gameState, isUltimateActive } = useGameStore();
  const { camera } = useThree();
  const targetPosition = useRef(new Vector3(0, 8, 18));
  const shakeOffset = useRef({ x: 0, y: 0 });
  
  useFrame((_, delta) => {
    if (gameState !== 'fighting') return;
    
    // Coletar todos os jogadores ativos
    const activePlayers = [player1, player2];
    if (gameMode === '2v2') {
      if (player3 && player3.isAlive) activePlayers.push(player3);
      if (player4 && player4.isAlive) activePlayers.push(player4);
    }
    
    // Calcular ponto médio de todos os jogadores
    let midX = 0, midY = 0, midZ = 0;
    for (const p of activePlayers) {
      midX += p.position.x;
      midY += p.position.y;
      midZ += p.position.z;
    }
    midX /= activePlayers.length;
    midY = midY / activePlayers.length + 2;
    midZ /= activePlayers.length;
    
    // Calcular distância máxima entre jogadores
    let maxDist = 0;
    for (let i = 0; i < activePlayers.length; i++) {
      for (let j = i + 1; j < activePlayers.length; j++) {
        const dx = activePlayers[i].position.x - activePlayers[j].position.x;
        const dz = activePlayers[i].position.z - activePlayers[j].position.z;
        const dist = Math.sqrt(dx * dx + dz * dz);
        if (dist > maxDist) maxDist = dist;
      }
    }
    
    // Camera distance based on player separation (maior no 2v2)
    const baseDist = gameMode === '2v2' ? 14 : 12;
    const maxCamDist = gameMode === '2v2' ? 30 : 25;
    const cameraDistance = Math.max(baseDist, Math.min(maxCamDist, maxDist * 1.2 + 10));
    
    // Target camera position
    const targetX = midX;
    const targetY = midY + 6;
    const targetZ = midZ + cameraDistance;
    
    // Smooth camera movement
    targetPosition.current.lerp(
      new Vector3(targetX, targetY, targetZ),
      delta * 3
    );
    
    // Apply camera shake
    if (cameraShake > 0) {
      shakeOffset.current.x = (Math.random() - 0.5) * cameraShake * 0.5;
      shakeOffset.current.y = (Math.random() - 0.5) * cameraShake * 0.5;
      setCameraShake(Math.max(0, cameraShake - delta * 3));
    } else {
      shakeOffset.current.x = 0;
      shakeOffset.current.y = 0;
    }
    
    // Ultimate zoom effect
    if (isUltimateActive) {
      camera.position.lerp(new Vector3(midX, midY + 3, midZ + 8), delta * 5);
    } else {
      camera.position.set(
        targetPosition.current.x + shakeOffset.current.x,
        targetPosition.current.y + shakeOffset.current.y,
        targetPosition.current.z
      );
    }
    
    // Look at midpoint
    camera.lookAt(midX, midY, midZ);
  });
  
  return null;
}

function GameLogic() {
  const { 
    player1, 
    player2, 
    gameState, 
    endRound, 
    roundTime, 
    setGameState,
    setKey,
    setMouseDown,
    gameMode,
  } = useGameStore();
  
  // AI update
  useFrame((_, delta) => {
    if ((gameMode === 'pve' || gameMode === '2v2' || gameMode === 'boss') && gameState === 'fighting') {
      useGameStore.getState().updateAllAI(delta);
    }
  });
  
  // Mouse input for punching
  useEffect(() => {
    const handleMouseDown = () => {
      if (gameState === 'fighting') {
        setMouseDown(true);
      }
    };
    
    const handleMouseUp = () => {
      setMouseDown(false);
    };
    
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    
    return () => {
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
    };
  }, [gameState, setMouseDown]);
  
  // Round timer and win condition
  useFrame((_, delta) => {
    if (gameState !== 'fighting') return;
    
    // Update round time
    const newTime = Math.max(0, roundTime - delta);
    useGameStore.setState({ roundTime: newTime });
    
    const state = useGameStore.getState();
    
    // Modo 2v2: verificar se todo o time foi derrotado
    if (gameMode === '2v2') {
      // Atualizar status de vida IMEDIATAMENTE quando HP chega a 0
      const currentState = useGameStore.getState();
      
      if (currentState.player1.health <= 0 && currentState.player1.isAlive) {
        state.updatePlayer(1, { isAlive: false });
      }
      if (currentState.player2.health <= 0 && currentState.player2.isAlive) {
        state.updatePlayer(2, { isAlive: false });
      }
      if (currentState.player3 && currentState.player3.health <= 0 && currentState.player3.isAlive) {
        state.updatePlayer(3, { isAlive: false });
      }
      if (currentState.player4 && currentState.player4.health <= 0 && currentState.player4.isAlive) {
        state.updatePlayer(4, { isAlive: false });
      }
      
      // Rechecar o estado após as atualizações
      const p1 = currentState.player1;
      const p2 = currentState.player2;
      const p3 = currentState.player3;
      const p4 = currentState.player4;
      
      // Time 1: P1 + P3, Time 2: P2 + P4
      const team1Alive = p1.health > 0 || (p3?.health ?? 0) > 0;
      const team2Alive = p2.health > 0 || (p4?.health ?? 0) > 0;
      
      // Verificar vitória imediata
      if (!team1Alive && !team2Alive) {
        endRound('draw');
        return;
      } else if (!team1Alive) {
        endRound(2);
        return;
      } else if (!team2Alive) {
        endRound(1);
        return;
      }
      
      // Verificar timeout
      if (newTime <= 0) {
        const team1Health = p1.health + (p3?.health ?? 0);
        const team2Health = p2.health + (p4?.health ?? 0);
        
        if (team1Health > team2Health) {
          endRound(1);
        } else if (team2Health > team1Health) {
          endRound(2);
        } else {
          endRound('draw');
        }
        return;
      }
    } else {
      // Modo normal: PvP, PvE, Boss
      if (player1.health <= 0) {
        endRound(2);
      } else if (player2.health <= 0) {
        endRound(1);
      } else if (newTime <= 0) {
        if (player1.health > player2.health) {
          endRound(1);
        } else if (player2.health > player1.health) {
          endRound(2);
        } else {
          endRound('draw');
        }
      }
    }
  });
  
  // Keyboard input
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Prevent default for game keys
      if (['w', 'a', 's', 'd', ' ', 'q', 'e', 'r', 'f', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        e.preventDefault();
      }
      
      // Pause
      if (e.key === 'Escape') {
        if (gameState === 'fighting') {
          setGameState('paused');
        } else if (gameState === 'paused') {
          setGameState('fighting');
        }
        return;
      }
      
      setKey(e.key, true);
    };
    
    const handleKeyUp = (e: KeyboardEvent) => {
      setKey(e.key, false);
    };
    
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [gameState, setKey, setGameState]);
  
  return null;
}

export function GameScene() {
  const { gameState, player1, player2, player3, player4, gameMode } = useGameStore();
  
  if (gameState !== 'fighting' && gameState !== 'paused') return null;
  
  return (
    <div className="absolute inset-0">
      <Canvas
        shadows
        camera={{ position: [0, 8, 18], fov: 60 }}
        gl={{ antialias: true }}
      >
        {/* Lighting */}
        <ambientLight intensity={0.4} />
        <directionalLight 
          position={[10, 20, 10]} 
          intensity={1} 
          castShadow
          shadow-mapSize-width={2048}
          shadow-mapSize-height={2048}
          shadow-camera-far={50}
          shadow-camera-left={-20}
          shadow-camera-right={20}
          shadow-camera-top={20}
          shadow-camera-bottom={-20}
        />
        <pointLight position={[-10, 10, -10]} intensity={0.5} color="#6366f1" />
        <pointLight position={[10, 10, -10]} intensity={0.5} color="#f97316" />
        
        {/* Fog */}
        <fog attach="fog" args={['#0a0a1a', 30, 80]} />
        
        {/* Scene */}
        <Skybox />
        <Arena />
        
        {/* Fighters - Player 1 e 2 sempre existem */}
        <Fighter player={player1} isPlayer1={true} />
        <Fighter player={player2} isPlayer1={false} />
        
        {/* Fighters 3 e 4 para modo 2v2 */}
        {gameMode === '2v2' && player3 && (
          <Fighter player={player3} isPlayer1={false} />
        )}
        {gameMode === '2v2' && player4 && (
          <Fighter player={player4} isPlayer1={false} />
        )}
        
        {/* Combat */}
        <Projectiles />
        <Effects />
        
        {/* Controllers */}
        <CameraController />
        <GameLogic />
      </Canvas>
    </div>
  );
}
