import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Group, Vector3, Mesh } from 'three';
import { useGameStore, CHARACTERS, Player } from '../store/gameStore';
import { 
  executeSkill1, 
  executeSkill2, 
  executeSpecialAttack,
  SkillContext 
} from '../systems/SkillSystem';

interface FighterProps {
  player: Player;
  isPlayer1: boolean;
}

export function Fighter({ player, isPlayer1 }: FighterProps) {
  const groupRef = useRef<Group>(null);
  const bodyRef = useRef<Mesh>(null);
  const character = CHARACTERS[player.characterId];
  
  const {
    keys,
    mouseDown,
    updatePlayer,
    player1,
    player2,
    player3,
    player4,
    addProjectile,
    addEffect,
    addSummon,
    setCameraShake,
    setUltimateActive,
    gameState,
    isUltimateActive,
    gameMode,
  } = useGameStore();
  
  // Encontrar o oponente mais próximo (para 2v2)
  const getClosestEnemy = (): Player => {
    if (gameMode !== '2v2') {
      return isPlayer1 ? player2 : player1;
    }
    
    const enemies: Player[] = [];
    if (player.team === 1) {
      if (player2.isAlive) enemies.push(player2);
      if (player4?.isAlive) enemies.push(player4);
    } else {
      if (player1.isAlive) enemies.push(player1);
      if (player3?.isAlive) enemies.push(player3);
    }
    
    if (enemies.length === 0) return player.team === 1 ? player2 : player1;
    
    let closest = enemies[0];
    let closestDist = Infinity;
    for (const enemy of enemies) {
      const dx = enemy.position.x - player.position.x;
      const dz = enemy.position.z - player.position.z;
      const dist = Math.sqrt(dx*dx + dz*dz);
      if (dist < closestDist) {
        closestDist = dist;
        closest = enemy;
      }
    }
    return closest;
  };
  
  const opponent = getClosestEnemy();
  
  // Animation state
  const animationTime = useRef(0);
  const attackTimer = useRef(0);
  const lastPunchTime = useRef(0);
  
  // Controls mapping
  const controls = isPlayer1
    ? { 
        up: 'w', down: 's', left: 'a', right: 'd', 
        jump: ' ', skill1: 'q', skill2: 'e', ultimate: 'r', 
        block: 'f', special: 'g', punch: 'mouse'
      }
    : { 
        up: 'ArrowUp', down: 'ArrowDown', left: 'ArrowLeft', right: 'ArrowRight', 
        jump: 'Numpad0', skill1: 'Numpad1', skill2: 'Numpad2', ultimate: 'Numpad3', 
        block: 'Numpad4', special: 'Numpad5', punch: 'Numpad6'
      };
  
  useFrame((_, delta) => {
    if (gameState !== 'fighting' || isUltimateActive) return;
    if (!groupRef.current) return;
    
    // Se o jogador está morto, não processar inputs
    if (!player.isAlive) {
      // Manter a posição deitada
      if (bodyRef.current) {
        bodyRef.current.rotation.x = Math.PI / 2;
        bodyRef.current.position.y = 0.3;
      }
      return;
    }
    
    // Se é o player 1 e está morto no modo 2v2, entrar em modo espectador
    if (player.id === 1 && player.health <= 0 && gameMode === '2v2') {
      updatePlayer(1, { isAlive: false });
      return;
    }
    
    // Se o jogador está sendo AGARRADO (ex: Pegasus Rolling Crush), não pode fazer NADA
    if (player.isGrabbed) {
      // Apenas atualizar a posição visual - o jogador está preso
      if (groupRef.current) {
        groupRef.current.position.set(player.position.x, player.position.y, player.position.z);
        groupRef.current.rotation.y = player.rotation;
      }
      
      // Animação de "preso" - balançar levemente
      if (bodyRef.current) {
        bodyRef.current.rotation.z = Math.sin(animationTime.current * 15) * 0.15;
        bodyRef.current.scale.set(0.9, 1.1, 0.9);
      }
      
      return; // NÃO PROCESSAR NENHUM INPUT
    }
    
    // Skip P2 input processing if PvE mode (handled by AI)
    const isAIControlled = player.isAI;
    
    animationTime.current += delta;
    
    // Update cooldowns
    const newCooldowns = {
      skill1: Math.max(0, player.cooldowns.skill1 - delta * 1000),
      skill2: Math.max(0, player.cooldowns.skill2 - delta * 1000),
      ultimate: Math.max(0, player.cooldowns.ultimate - delta * 1000),
    };
    
    // Regenerate stamina
    let newStamina = Math.min(character.maxStamina, player.stamina + delta * 12);
    
    // Build blast meter over time
    let newBlast = Math.min(character.maxBlast, player.blast + delta * 2);
    
    // Build special bar over time (slower)
    let newSpecialBar = Math.min(100, player.specialBar + delta * 5);
    
    // Update status effect timers
    const newBlindTimer = Math.max(0, player.blindTimer - delta);
    const newSlowTimer = Math.max(0, player.slowTimer - delta);
    const newConfusedTimer = Math.max(0, player.confusedTimer - delta);
    const newDamageBoostTimer = Math.max(0, player.damageBoostTimer - delta);
    const newFormTimer = Math.max(0, player.formTimer - delta);
    
    // Punch combo timer
    let newPunchComboTimer = Math.max(0, player.punchComboTimer - delta);
    let newComboCount = player.comboCount;
    
    // Reset combo if timer expired
    if (newPunchComboTimer <= 0) {
      newComboCount = 0;
    }
    
    // Transform timer (Ben 10)
    let newCurrentForm = player.currentForm;
    if (newFormTimer <= 0 && player.currentForm !== 'base') {
      newCurrentForm = 'base';
    }
    
    // Passive timers
    let newPassiveTimer = player.passiveTimer + delta;
    let newPassiveStacks = player.passiveStacks;
    const newConsecutiveHits = player.consecutiveHits;
    
    // Character-specific passive updates
    switch (character.id) {
      case 'vapor':
        if (newPassiveTimer >= 20) {
          newPassiveTimer = 0;
          newPassiveStacks = 1;
        }
        break;
      case 'dandy':
        if (newPassiveTimer >= 15 && newPassiveStacks < 3) {
          newPassiveTimer = 0;
          newPassiveStacks++;
        }
        break;
      case 'scp4975': {
        const distToEnemy = Math.sqrt(
          (player.position.x - opponent.position.x) ** 2 +
          (player.position.z - opponent.position.z) ** 2
        );
        if (distToEnemy < 8 && newPassiveTimer >= 10) {
          newPassiveTimer = 0;
          newPassiveStacks = Math.min(5, newPassiveStacks + 1);
        }
        break;
      }
    }
    
    // Se é AI, não processar inputs manuais mas atualizar visuais
    if (isAIControlled) {
      // IMPORTANTE: Decrementar o stun para AI também!
      const newStunnedAI = Math.max(0, player.stunned - delta);
      
      // Atualizar a posição visual do mesh
      groupRef.current.position.set(player.position.x, player.position.y, player.position.z);
      groupRef.current.rotation.y = player.rotation;
      
      // Atualizar animação visual do corpo
      if (bodyRef.current) {
        const bobAmount = Math.sin(animationTime.current * 8) * 0.05;
        bodyRef.current.position.y = 1 + bobAmount;
        
        if (player.isAttacking) {
          bodyRef.current.scale.z = 1.3;
          bodyRef.current.scale.x = 0.8;
        } else if (player.isBlocking) {
          bodyRef.current.scale.set(1.2, 0.9, 1.2);
        } else if (newStunnedAI > 0) {
          bodyRef.current.rotation.z = Math.sin(animationTime.current * 20) * 0.2;
        } else {
          bodyRef.current.scale.set(1, 1, 1);
          bodyRef.current.rotation.z = 0;
        }
      }
      
      // Atualizar cooldowns e outros estados para AI - INCLUINDO STUN!
      updatePlayer(player.id, {
        cooldowns: newCooldowns,
        stamina: newStamina,
        blast: newBlast,
        specialBar: newSpecialBar,
        blindTimer: newBlindTimer,
        slowTimer: newSlowTimer,
        confusedTimer: newConfusedTimer,
        isConfused: newConfusedTimer > 0,
        damageBoostTimer: newDamageBoostTimer,
        formTimer: newFormTimer,
        currentForm: newCurrentForm,
        passiveTimer: newPassiveTimer,
        passiveStacks: newPassiveStacks,
        stunned: newStunnedAI, // <-- CORREÇÃO: Decrementar stun para AI
      });
      
      return;
    }
    
    // Movement
    let moveX = 0;
    let moveZ = 0;
    const speedMultiplier = player.slowTimer > 0 ? 0.5 : 1;
    const blockMultiplier = player.isBlocking ? 0.3 : 1;
    const formSpeedMultiplier = player.currentForm === 'xlr8' ? 1.5 : (player.currentForm === 'fourarms' ? 0.7 : 1);
    const speed = character.speed * speedMultiplier * blockMultiplier * formSpeedMultiplier;
    
    const confuseMultiplier = player.isConfused ? -1 : 1;
    
    if (player.stunned <= 0) {
      if (keys[controls.up]) moveZ -= speed * confuseMultiplier;
      if (keys[controls.down]) moveZ += speed * confuseMultiplier;
      if (keys[controls.left]) moveX -= speed * confuseMultiplier;
      if (keys[controls.right]) moveX += speed * confuseMultiplier;
    }
    
    // Jump
    let newVelocityY = player.velocity.y;
    let newIsGrounded = player.isGrounded;
    
    if (keys[controls.jump] && player.isGrounded && player.stunned <= 0) {
      newVelocityY = 0.3;
      newIsGrounded = false;
      newStamina -= 5;
    }
    
    // Apply gravity
    if (!player.isGrounded) {
      newVelocityY -= delta * 0.8;
    }
    
    // Calculate new position
    let newY = player.position.y + newVelocityY;
    if (newY <= 0) {
      newY = 0;
      newVelocityY = 0;
      newIsGrounded = true;
    }
    
    // Boundary check
    const newX = Math.max(-17, Math.min(17, player.position.x + moveX));
    const newZ = Math.max(-17, Math.min(17, player.position.z + moveZ));
    
    // Face opponent
    const dx = opponent.position.x - player.position.x;
    const dz = opponent.position.z - player.position.z;
    const targetRotation = Math.atan2(dx, dz);
    
    // Block
    const isBlocking = keys[controls.block] && player.isGrounded && player.stunned <= 0;
    
    // ============== PUNCH COMBO SYSTEM ==============
    const punchPressed = isPlayer1 ? mouseDown : keys[controls.punch];
    
    if (punchPressed && !player.isAttacking && player.stunned <= 0 && Date.now() - lastPunchTime.current > 250) {
      lastPunchTime.current = Date.now();
      
      newComboCount = (player.comboCount % 4) + 1;
      newPunchComboTimer = 1.5;
      
      const direction = new Vector3(
        Math.sin(targetRotation),
        0,
        Math.cos(targetRotation)
      ).normalize();
      
      const isPowerPunch = newComboCount === 4;
      const punchDamage = isPowerPunch ? 15 : 5;
      const knockbackMult = isPowerPunch ? 3 : 1;
      
      addProjectile({
        owner: player.id,
        position: {
          x: player.position.x + direction.x * 1.2,
          y: player.position.y + 1,
          z: player.position.z + direction.z * 1.2,
        },
        velocity: {
          x: direction.x * 35,
          y: 0,
          z: direction.z * 35,
        },
        damage: punchDamage,
        lifetime: 0.15,
        color: isPowerPunch ? '#FFD700' : character.color,
        size: isPowerPunch ? 0.6 : 0.3,
        effect: { type: 'projectile', knockbackMultiplier: knockbackMult },
        skillType: 'punch',
      });
      
      if (isPowerPunch) {
        setCameraShake(0.4);
        addEffect({
          type: 'hit',
          position: { x: player.position.x + direction.x * 1.5, y: player.position.y + 1, z: player.position.z + direction.z * 1.5 },
          lifetime: 0.3,
          color: '#FFD700',
          scale: 1.5,
        });
        newComboCount = 0;
      }
      
      attackTimer.current = 0.2;
      newSpecialBar = Math.min(100, newSpecialBar + 8);
    }
    
    // Create skill context for skill system
    const createSkillContext = (): SkillContext => ({
      player,
      opponent,
      direction: { x: Math.sin(targetRotation), y: 0, z: Math.cos(targetRotation) },
      targetRotation,
      addProjectile: addProjectile as SkillContext['addProjectile'],
      addEffect: addEffect as SkillContext['addEffect'],
      addSummon: addSummon as SkillContext['addSummon'],
      updatePlayer,
      setCameraShake,
    });
    
    // ============== SKILL 1 ==============
    if (keys[controls.skill1] && player.cooldowns.skill1 <= 0 && player.stamina >= character.skill1Cost && player.stunned <= 0 && !player.isAttacking) {
      executeSkill1(player.characterId, createSkillContext());
      newStamina -= character.skill1Cost;
      newCooldowns.skill1 = character.skill1Cooldown;
      attackTimer.current = 0.4;
      newBlast = Math.min(100, newBlast + 5);
    }
    
    // ============== SKILL 2 ==============
    if (keys[controls.skill2] && player.cooldowns.skill2 <= 0 && player.stamina >= character.skill2Cost && player.stunned <= 0 && !player.isAttacking) {
      executeSkill2(player.characterId, createSkillContext());
      newStamina -= character.skill2Cost;
      newCooldowns.skill2 = character.skill2Cooldown;
      attackTimer.current = 0.6;
      setCameraShake(0.3);
      newBlast = Math.min(100, newBlast + 8);
    }
    
    // ============== SPECIAL ATTACK (G KEY) ==============
    if (keys[controls.special] && player.specialBar >= 100 && player.stunned <= 0 && !player.isAttacking) {
      executeSpecialAttack(player.characterId, createSkillContext());
      newSpecialBar = 0;
      attackTimer.current = 0.5;
      setCameraShake(0.5);
      newBlast = Math.min(100, newBlast + 10);
    }
    
    // ============== ULTIMATE ==============
    if (keys[controls.ultimate] && player.blast >= 100 && player.stunned <= 0 && !player.isAttacking) {
      setUltimateActive(true, player.id);
      newBlast = 0;
      
      setTimeout(() => {
        const opponentStore = useGameStore.getState()[isPlayer1 ? 'player2' : 'player1'];
        const charData = CHARACTERS[player.characterId];
        
        let damage = charData.ultimateDamage;
        if (charData.id === 'arceus') {
          damage = opponentStore.health - 1;
        }
        
        const boostMult = 1 + (player.damageBoost / 100);
        damage *= boostMult;
        
        useGameStore.getState().updatePlayer(opponent.id, {
          health: Math.max(1, opponentStore.health - damage),
          stunned: charData.ultimateEffect.stunDuration || 2,
          isConfused: charData.ultimateEffect.confuseControls || false,
          confusedTimer: charData.ultimateEffect.confuseControls ? 4 : 0,
        });
        
        useGameStore.getState().addEffect({
          type: 'ultimate',
          position: opponentStore.position,
          lifetime: 1.5,
          color: charData.secondaryColor,
          scale: 3,
        });
        
        useGameStore.getState().setCameraShake(1);
        useGameStore.getState().setUltimateActive(false);
      }, 2500);
    }
    
    // Update attack state
    if (attackTimer.current > 0) {
      attackTimer.current -= delta;
    }
    
    // Update stun
    const newStunned = Math.max(0, player.stunned - delta);
    
    // Invisibility check
    let newIsInvisible = player.isInvisible;
    if (player.damageBoostTimer <= 0 && player.isInvisible) {
      newIsInvisible = false;
    }
    
    // Update animation
    let currentAnimation = 'idle';
    if (player.stunned > 0) currentAnimation = 'stun';
    else if (attackTimer.current > 0) currentAnimation = 'attack';
    else if (!player.isGrounded) currentAnimation = 'jump';
    else if (isBlocking) currentAnimation = 'block';
    else if (Math.abs(moveX) > 0 || Math.abs(moveZ) > 0) currentAnimation = 'run';
    
    // Apply updates
    updatePlayer(player.id, {
      position: { x: newX, y: newY, z: newZ },
      velocity: { ...player.velocity, y: newVelocityY },
      rotation: targetRotation,
      isGrounded: newIsGrounded,
      isBlocking,
      isAttacking: attackTimer.current > 0,
      cooldowns: newCooldowns,
      stamina: newStamina,
      blast: newBlast,
      specialBar: newSpecialBar,
      stunned: newStunned,
      currentAnimation,
      comboCount: newComboCount,
      punchComboTimer: newPunchComboTimer,
      blindTimer: newBlindTimer,
      slowTimer: newSlowTimer,
      confusedTimer: newConfusedTimer,
      isConfused: newConfusedTimer > 0,
      damageBoostTimer: newDamageBoostTimer,
      formTimer: newFormTimer,
      currentForm: newCurrentForm,
      passiveTimer: newPassiveTimer,
      passiveStacks: newPassiveStacks,
      consecutiveHits: newConsecutiveHits,
      isInvisible: newIsInvisible,
    });
    
    // Apply to mesh
    groupRef.current.position.set(player.position.x, player.position.y, player.position.z);
    groupRef.current.rotation.y = player.rotation;
    
    // Body animation
    if (bodyRef.current) {
      const bobAmount = currentAnimation === 'run' ? Math.sin(animationTime.current * 15) * 0.1 : Math.sin(animationTime.current * 2) * 0.05;
      bodyRef.current.position.y = 1 + bobAmount;
      
      if (currentAnimation === 'attack') {
        bodyRef.current.scale.z = 1.3;
        bodyRef.current.scale.x = 0.8;
      } else if (currentAnimation === 'block') {
        bodyRef.current.scale.set(1.2, 0.9, 1.2);
      } else if (currentAnimation === 'stun') {
        bodyRef.current.rotation.z = Math.sin(animationTime.current * 20) * 0.2;
      } else {
        bodyRef.current.scale.set(1, 1, 1);
        bodyRef.current.rotation.z = 0;
      }
      
      // Transform visual (Ben 10)
      if (player.currentForm === 'xlr8') {
        bodyRef.current.scale.set(0.8, 1.2, 0.8);
      } else if (player.currentForm === 'fourarms') {
        bodyRef.current.scale.set(1.5, 1.3, 1.5);
      }
    }
    
    // Suppress AI flag warning
    void isAIControlled;
  });
  
  // Determine visual state
  const healthPercent = player.health / character.maxHealth;
  const tintedColor = healthPercent < 0.3 ? '#ff0000' : character.color;
  
  // Form-based color (Ben 10)
  let displayColor = tintedColor;
  if (player.currentForm === 'xlr8') displayColor = '#00BFFF';
  else if (player.currentForm === 'fourarms') displayColor = '#FF4500';
  else if (player.currentForm === 'alienx') displayColor = '#000033';
  
  // Invisible characters
  const opacity = player.isInvisible ? 0.3 : 1;
  
  // Se o jogador está morto, renderizar deitado ou escondido
  if (!player.isAlive || player.health <= 0) {
    return (
      <group ref={groupRef} position={[player.position.x, 0, player.position.z]}>
        {/* Shadow */}
        <mesh position={[0, 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[1, 16]} />
          <meshBasicMaterial color="#000000" transparent opacity={0.3} />
        </mesh>
        
        {/* Corpo deitado */}
        <group rotation={[Math.PI / 2, 0, player.rotation]}>
          <mesh position={[0, 0.3, 0]} castShadow>
            <capsuleGeometry args={[0.5, 1, 8, 16]} />
            <meshStandardMaterial 
              color={character.color}
              metalness={0.1}
              roughness={0.9}
              transparent
              opacity={0.6}
            />
          </mesh>
          <mesh position={[0, 1.2, 0]} castShadow>
            <sphereGeometry args={[0.4, 16, 16]} />
            <meshStandardMaterial 
              color={character.secondaryColor}
              transparent
              opacity={0.6}
            />
          </mesh>
        </group>
        
        {/* X vermelho indicando morte */}
        <mesh position={[0, 0.5, 0]} rotation={[-Math.PI / 2, 0, Math.PI / 4]}>
          <boxGeometry args={[0.1, 1.5, 0.1]} />
          <meshBasicMaterial color="#ff0000" />
        </mesh>
        <mesh position={[0, 0.5, 0]} rotation={[-Math.PI / 2, 0, -Math.PI / 4]}>
          <boxGeometry args={[0.1, 1.5, 0.1]} />
          <meshBasicMaterial color="#ff0000" />
        </mesh>
        
        {/* Texto "K.O." */}
        <mesh position={[0, 1.5, 0]}>
          <sphereGeometry args={[0.3, 8, 8]} />
          <meshBasicMaterial color="#ff0000" transparent opacity={0.5} />
        </mesh>
      </group>
    );
  }
  
  // Se o jogador está em modo RAGDOLL (sendo puxado pela língua do Pilgor)
  if (player.isRagdoll) {
    return (
      <group ref={groupRef} position={[player.position.x, player.position.y, player.position.z]}>
        {/* Shadow */}
        <mesh position={[0, 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
          <circleGeometry args={[1.2, 16]} />
          <meshBasicMaterial color="#000000" transparent opacity={0.4} />
        </mesh>
        
        {/* Corpo deitado de costas (ragdoll) */}
        <group rotation={[Math.PI / 2, 0, player.rotation]}>
          {/* Corpo principal */}
          <mesh position={[0, 0.3, 0]} castShadow>
            <capsuleGeometry args={[0.5, 1, 8, 16]} />
            <meshStandardMaterial 
              color={character.color}
              metalness={0.1}
              roughness={0.9}
            />
          </mesh>
          
          {/* Cabeça */}
          <mesh position={[0, 1.2, 0]} castShadow>
            <sphereGeometry args={[0.4, 16, 16]} />
            <meshStandardMaterial 
              color={character.secondaryColor}
            />
          </mesh>
          
          {/* Braços esticados (simulando ragdoll) */}
          <mesh position={[0.8, 0.3, 0]} rotation={[0, 0, Math.PI / 2]} castShadow>
            <capsuleGeometry args={[0.15, 0.6, 4, 8]} />
            <meshStandardMaterial color={character.color} />
          </mesh>
          <mesh position={[-0.8, 0.3, 0]} rotation={[0, 0, -Math.PI / 2]} castShadow>
            <capsuleGeometry args={[0.15, 0.6, 4, 8]} />
            <meshStandardMaterial color={character.color} />
          </mesh>
          
          {/* Pernas esticadas */}
          <mesh position={[0.3, -0.6, 0]} castShadow>
            <capsuleGeometry args={[0.18, 0.5, 4, 8]} />
            <meshStandardMaterial color={character.secondaryColor} />
          </mesh>
          <mesh position={[-0.3, -0.6, 0]} castShadow>
            <capsuleGeometry args={[0.18, 0.5, 4, 8]} />
            <meshStandardMaterial color={character.secondaryColor} />
          </mesh>
        </group>
        
        {/* Efeito de "sendo arrastado" - poeira */}
        <mesh position={[0, 0.2, 0]}>
          <sphereGeometry args={[0.6, 8, 8]} />
          <meshBasicMaterial color="#8B4513" transparent opacity={0.3} />
        </mesh>
        
        {/* Indicador de stun/ragdoll (estrelas girando) */}
        <mesh position={[0, 0.8, 0]} rotation={[0, animationTime.current * 5, 0]}>
          <torusGeometry args={[0.5, 0.05, 4, 6]} />
          <meshBasicMaterial color="#FFFF00" />
        </mesh>
        
        {/* Triângulo indicador do time */}
        <mesh position={[0, 1.5, 0]}>
          <coneGeometry args={[0.2, 0.4, 4]} />
          <meshBasicMaterial color={
            player.id === 1 ? '#3b82f6' :
            player.team === 1 ? '#22c55e' :
            '#ef4444'
          } />
        </mesh>
      </group>
    );
  }
  
  return (
    <group ref={groupRef} position={[player.position.x, player.position.y, player.position.z]}>
      {/* Shadow */}
      <mesh position={[0, 0.01, 0]} rotation={[-Math.PI / 2, 0, 0]}>
        <circleGeometry args={[0.8, 16]} />
        <meshBasicMaterial color="#000000" transparent opacity={0.5} />
      </mesh>
      
      {/* Body */}
      <mesh ref={bodyRef} position={[0, 1, 0]} castShadow>
        <capsuleGeometry args={[0.5, 1, 8, 16]} />
        <meshStandardMaterial 
          color={displayColor}
          metalness={0.3}
          roughness={0.7}
          emissive={player.isAttacking ? character.secondaryColor : '#000000'}
          emissiveIntensity={player.isAttacking ? 0.5 : 0}
          transparent
          opacity={opacity}
        />
      </mesh>
      
      {/* Head */}
      <mesh position={[0, 2.2, 0]} castShadow>
        <sphereGeometry args={[0.4, 16, 16]} />
        <meshStandardMaterial 
          color={character.secondaryColor}
          metalness={0.4}
          roughness={0.6}
          transparent
          opacity={opacity}
        />
      </mesh>
      
      {/* Blind effect overlay */}
      {player.blindTimer > 0 && (
        <mesh position={[0, 2.2, 0.5]}>
          <planeGeometry args={[1.5, 0.5]} />
          <meshBasicMaterial color="#000000" />
        </mesh>
      )}
      
      {/* Eyes */}
      <mesh position={[0.15, 2.25, 0.3]}>
        <sphereGeometry args={[0.08, 8, 8]} />
        <meshBasicMaterial color={player.blindTimer > 0 ? "#333333" : "#ffffff"} />
      </mesh>
      <mesh position={[-0.15, 2.25, 0.3]}>
        <sphereGeometry args={[0.08, 8, 8]} />
        <meshBasicMaterial color={player.blindTimer > 0 ? "#333333" : "#ffffff"} />
      </mesh>
      
      {/* Arms */}
      <mesh position={[0.7, 1.2, 0]} rotation={[0, 0, -0.3]} castShadow>
        <capsuleGeometry args={[0.15, 0.6, 4, 8]} />
        <meshStandardMaterial color={displayColor} transparent opacity={opacity} />
      </mesh>
      <mesh position={[-0.7, 1.2, 0]} rotation={[0, 0, 0.3]} castShadow>
        <capsuleGeometry args={[0.15, 0.6, 4, 8]} />
        <meshStandardMaterial color={displayColor} transparent opacity={opacity} />
      </mesh>
      
      {/* Extra arms for Four Arms form */}
      {player.currentForm === 'fourarms' && (
        <>
          <mesh position={[0.5, 0.8, 0]} rotation={[0, 0, -0.5]} castShadow>
            <capsuleGeometry args={[0.12, 0.5, 4, 8]} />
            <meshStandardMaterial color="#FF4500" />
          </mesh>
          <mesh position={[-0.5, 0.8, 0]} rotation={[0, 0, 0.5]} castShadow>
            <capsuleGeometry args={[0.12, 0.5, 4, 8]} />
            <meshStandardMaterial color="#FF4500" />
          </mesh>
        </>
      )}
      
      {/* Legs */}
      <mesh position={[0.25, 0.3, 0]} castShadow>
        <capsuleGeometry args={[0.18, 0.5, 4, 8]} />
        <meshStandardMaterial color={character.secondaryColor} transparent opacity={opacity} />
      </mesh>
      <mesh position={[-0.25, 0.3, 0]} castShadow>
        <capsuleGeometry args={[0.18, 0.5, 4, 8]} />
        <meshStandardMaterial color={character.secondaryColor} transparent opacity={opacity} />
      </mesh>
      
      {/* Player indicator - Azul/Verde para time 1, Vermelho para time 2 */}
      <mesh position={[0, 3, 0]}>
        <coneGeometry args={[0.2, 0.4, 4]} />
        <meshBasicMaterial color={
          player.id === 1 ? '#3b82f6' : // Player 1 - Azul
          player.team === 1 ? '#22c55e' : // Time 1 (aliados) - Verde
          '#ef4444' // Time 2 (inimigos) - Vermelho
        } />
      </mesh>
      
      {/* Combo counter display */}
      {player.comboCount > 0 && (
        <mesh position={[0.8, 2.5, 0]}>
          <sphereGeometry args={[0.15 + player.comboCount * 0.05, 8, 8]} />
          <meshBasicMaterial 
            color={player.comboCount === 3 ? '#FFD700' : '#ffffff'} 
            transparent 
            opacity={0.8}
          />
        </mesh>
      )}
      
      {/* Special bar indicator when full */}
      {player.specialBar >= 100 && (
        <mesh position={[0, 0.1, 0]} rotation={[-Math.PI / 2, 0, animationTime.current * 2]}>
          <ringGeometry args={[0.8, 1, 6]} />
          <meshBasicMaterial color="#00FF00" transparent opacity={0.6} />
        </mesh>
      )}
      
      {/* Blocking shield */}
      {player.isBlocking && (
        <mesh position={[0, 1, 0.8]}>
          <sphereGeometry args={[1.2, 16, 16, 0, Math.PI]} />
          <meshStandardMaterial 
            color="#60a5fa"
            transparent
            opacity={0.4}
            emissive="#60a5fa"
            emissiveIntensity={0.5}
          />
        </mesh>
      )}
      
      {/* Super Armor indicator (Tank) */}
      {player.superArmor && (
        <mesh position={[0, 1, 0]}>
          <torusGeometry args={[0.8, 0.05, 8, 16]} />
          <meshBasicMaterial color="#FFD700" />
        </mesh>
      )}
      
      {/* Attack glow */}
      {player.isAttacking && (
        <pointLight position={[0, 1, 1]} color={character.secondaryColor} intensity={3} distance={5} />
      )}
      
      {/* Damage boost aura */}
      {player.damageBoost > 0 && (
        <mesh position={[0, 1, 0]}>
          <sphereGeometry args={[1.5, 16, 16]} />
          <meshBasicMaterial color="#FF0000" transparent opacity={0.2} />
        </mesh>
      )}
    </group>
  );
}
