import { useGameStore, CHARACTERS, CharacterId } from '../store/gameStore';

export function GameHUD() {
  const { player1, player2, player3, player4, round, team1Wins, team2Wins, roundTime, gameState, gameMode, bossState } = useGameStore();
  const player1Wins = team1Wins;
  const player2Wins = team2Wins;
  
  if (gameState !== 'fighting') return null;
  
  // Verificar se Player 1 está morto no modo 2v2 (modo espectador)
  const isSpectating = gameMode === '2v2' && (!player1.isAlive || player1.health <= 0);
  
  const char1 = CHARACTERS[player1.characterId];
  const char2 = CHARACTERS[player2.characterId];
  const char3 = player3 ? CHARACTERS[player3.characterId] : null;
  const char4 = player4 ? CHARACTERS[player4.characterId] : null;
  
  const is2v2 = gameMode === '2v2';
  const isBoss = gameMode === 'boss';
  
  return (
    <div className="absolute inset-0 pointer-events-none">
      {/* Top Bar */}
      <div className="absolute top-0 left-0 right-0 p-4">
        <div className="flex items-center justify-between gap-4">
          {/* Team 1 / Player 1 Info */}
          <div className="flex-1">
            <PlayerHUD 
              name={char1.name}
              health={player1.health}
              maxHealth={char1.maxHealth}
              stamina={player1.stamina}
              maxStamina={char1.maxStamina}
              blast={player1.blast}
              specialBar={player1.specialBar}
              comboCount={player1.comboCount}
              color={char1.color}
              isPlayer1={true}
              isInvisible={player1.isInvisible}
              label="P1"
            />
            {is2v2 && player3 && char3 && (
              <div className="mt-2 opacity-80">
                <PlayerHUD 
                  name={char3.name}
                  health={player3.health}
                  maxHealth={char3.maxHealth}
                  stamina={player3.stamina}
                  maxStamina={char3.maxStamina}
                  blast={player3.blast}
                  specialBar={player3.specialBar}
                  comboCount={player3.comboCount}
                  color={char3.color}
                  isPlayer1={true}
                  isInvisible={player3.isInvisible}
                  label="P3 (AI)"
                  isCompact
                />
              </div>
            )}
          </div>
          
          {/* Center - Round Info */}
          <div className="flex flex-col items-center">
            <div className="text-4xl font-bold text-white tabular-nums">
              {Math.ceil(roundTime)}
            </div>
            <div className="text-sm text-gray-400">
              {isBoss ? `BOSS FIGHT` : `Round ${round}`}
            </div>
            <div className="flex gap-2 mt-1">
              {[...Array(3)].map((_, i) => (
                <div
                  key={`p1-${i}`}
                  className={`w-3 h-3 rounded-full ${i < player1Wins ? 'bg-blue-500' : 'bg-gray-700'}`}
                />
              ))}
              <div className="w-px bg-gray-600 mx-1" />
              {[...Array(3)].map((_, i) => (
                <div
                  key={`p2-${i}`}
                  className={`w-3 h-3 rounded-full ${i < player2Wins ? 'bg-red-500' : 'bg-gray-700'}`}
                />
              ))}
            </div>
            {gameMode === 'pve' && (
              <div className="text-xs text-yellow-400 mt-1">VS CPU</div>
            )}
            {is2v2 && (
              <div className="text-xs text-green-400 mt-1">2v2 TAG BATTLE</div>
            )}
            {isBoss && bossState.currentBoss && (
              <div className="text-xs text-red-400 mt-1">
                PHASE {bossState.currentPhase}/{bossState.maxPhases}
              </div>
            )}
            {isSpectating && (
              <div className="text-sm text-yellow-400 mt-2 animate-pulse font-bold">
                👁️ SPECTATING - You are K.O.!
              </div>
            )}
          </div>
          
          {/* Team 2 / Player 2 Info */}
          <div className="flex-1">
            <PlayerHUD 
              name={isBoss ? '👹 ' + char2.name : char2.name}
              health={player2.health}
              maxHealth={isBoss ? CHARACTERS[player2.characterId].maxHealth * 5 : char2.maxHealth}
              stamina={player2.stamina}
              maxStamina={char2.maxStamina}
              blast={player2.blast}
              specialBar={player2.specialBar}
              comboCount={player2.comboCount}
              color={isBoss ? '#ff0000' : char2.color}
              isPlayer1={false}
              isInvisible={player2.isInvisible}
              label={isBoss ? 'BOSS' : 'P2'}
            />
            {is2v2 && player4 && char4 && (
              <div className="mt-2 opacity-80">
                <PlayerHUD 
                  name={char4.name}
                  health={player4.health}
                  maxHealth={char4.maxHealth}
                  stamina={player4.stamina}
                  maxStamina={char4.maxStamina}
                  blast={player4.blast}
                  specialBar={player4.specialBar}
                  comboCount={player4.comboCount}
                  color={char4.color}
                  isPlayer1={false}
                  isInvisible={player4.isInvisible}
                  label="P4 (AI)"
                  isCompact
                />
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Bottom - Controls */}
      <div className="absolute bottom-4 left-4 right-4 flex justify-between">
        {!isSpectating && (
          <ControlsDisplay player={1} character={char1} cooldowns={player1.cooldowns} blast={player1.blast} specialBar={player1.specialBar} />
        )}
        {gameMode === 'pvp' && (
          <ControlsDisplay player={2} character={char2} cooldowns={player2.cooldowns} blast={player2.blast} specialBar={player2.specialBar} />
        )}
      </div>
      
      {/* Spectator mode message */}
      {isSpectating && player3 && (
        <div className="absolute bottom-20 left-1/2 -translate-x-1/2 text-center">
          <div className="bg-black/80 backdrop-blur-sm px-6 py-4 rounded-lg border-2 border-yellow-500">
            <div className="text-2xl font-bold text-red-500 mb-2">💀 YOU ARE K.O.!</div>
            <div className="text-white">
              Now spectating <span className="text-green-400 font-bold">{CHARACTERS[player3.characterId].name}</span> (your ally)
            </div>
            <div className="text-gray-400 text-sm mt-2">Your ally is still fighting!</div>
          </div>
        </div>
      )}
      
      {/* K.O. indicators for 2v2 */}
      {is2v2 && (
        <div className="absolute top-1/2 left-4 right-4 flex justify-between -translate-y-1/2">
          {player1.health <= 0 && (
            <div className="bg-red-900/80 px-3 py-1 rounded text-white font-bold animate-pulse">
              P1 K.O.
            </div>
          )}
          {player2.health <= 0 && (
            <div className="bg-red-900/80 px-3 py-1 rounded text-white font-bold animate-pulse ml-auto">
              P2 K.O.
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function PlayerHUD({ 
  name, 
  health, 
  maxHealth, 
  stamina, 
  maxStamina, 
  blast, 
  specialBar,
  comboCount,
  color,
  isPlayer1,
  isInvisible,
  label,
  isCompact,
}: { 
  name: string;
  health: number;
  maxHealth: number;
  stamina: number;
  maxStamina: number;
  blast: number;
  specialBar: number;
  comboCount: number;
  color: string;
  isPlayer1: boolean;
  isInvisible: boolean;
  label?: string;
  isCompact?: boolean;
}) {
  const healthPercent = (health / maxHealth) * 100;
  const staminaPercent = (stamina / maxStamina) * 100;
  const blastPercent = blast;
  const specialPercent = specialBar;
  const displayLabel = label || (isPlayer1 ? 'P1' : 'P2');
  
  if (isCompact) {
    return (
      <div className={`flex items-center gap-2 ${isPlayer1 ? '' : 'flex-row-reverse'}`}>
        <div 
          className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold text-white ${isInvisible ? 'opacity-30' : ''}`}
          style={{ backgroundColor: color }}
        >
          {name.charAt(0)}
        </div>
        <div className="flex-1">
          <div className={`text-xs text-gray-400 ${isPlayer1 ? '' : 'text-right'}`}>{displayLabel}: {name}</div>
          <div className={`w-32 h-2 bg-gray-800 rounded-full overflow-hidden`}>
            <div 
              className="h-full transition-all"
              style={{ 
                width: `${healthPercent}%`,
                backgroundColor: healthPercent > 30 ? '#22c55e' : '#ef4444',
              }}
            />
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className={`flex flex-col ${isPlayer1 ? '' : 'items-end'}`}>
      {/* Name */}
      <div className={`flex items-center gap-2 mb-1 ${isPlayer1 ? '' : 'flex-row-reverse'}`}>
        <div 
          className={`w-10 h-10 rounded-full border-2 flex items-center justify-center font-bold text-white ${isInvisible ? 'opacity-30' : ''}`}
          style={{ backgroundColor: color, borderColor: isPlayer1 ? '#3b82f6' : '#ef4444' }}
        >
          {name.charAt(0)}
        </div>
        <span className={`text-white font-semibold text-lg ${isInvisible ? 'opacity-50' : ''}`}>
          {name}
          {isInvisible && <span className="text-xs text-purple-400 ml-2">(INVISIBLE)</span>}
        </span>
        <span className={`text-xs px-2 py-0.5 rounded ${isPlayer1 ? 'bg-blue-600' : 'bg-red-600'}`}>
          {displayLabel}
        </span>
      </div>
      
      {/* Health Bar */}
      <div className={`w-full max-w-md h-6 bg-gray-800 rounded-full overflow-hidden border-2 ${isPlayer1 ? 'border-blue-500' : 'border-red-500'}`}>
        <div 
          className={`h-full transition-all duration-200 ${isPlayer1 ? '' : 'ml-auto'}`}
          style={{ 
            width: `${healthPercent}%`,
            background: healthPercent > 30 
              ? 'linear-gradient(to bottom, #22c55e, #16a34a)' 
              : 'linear-gradient(to bottom, #ef4444, #b91c1c)',
          }}
        />
      </div>
      <div className={`text-xs text-gray-400 mt-0.5 ${isPlayer1 ? '' : 'text-right'}`}>
        {Math.ceil(health)} / {maxHealth} HP
      </div>
      
      {/* Stamina Bar */}
      <div className="w-full max-w-md h-2 bg-gray-800 rounded-full overflow-hidden mt-1">
        <div 
          className={`h-full transition-all duration-100 ${isPlayer1 ? '' : 'ml-auto'}`}
          style={{ 
            width: `${staminaPercent}%`,
            background: 'linear-gradient(to bottom, #fbbf24, #d97706)',
          }}
        />
      </div>
      
      {/* Blast Meter (Ultimate) */}
      <div className="w-full max-w-md h-3 bg-gray-800 rounded-full overflow-hidden mt-1 border border-purple-500">
        <div 
          className={`h-full transition-all duration-100 ${isPlayer1 ? '' : 'ml-auto'} ${blastPercent >= 100 ? 'animate-pulse' : ''}`}
          style={{ 
            width: `${blastPercent}%`,
            background: blastPercent >= 100 
              ? 'linear-gradient(to right, #a855f7, #ec4899, #a855f7)' 
              : 'linear-gradient(to bottom, #8b5cf6, #6d28d9)',
          }}
        />
      </div>
      {blastPercent >= 100 && (
        <div className={`text-xs text-purple-400 font-bold mt-0.5 animate-pulse ${isPlayer1 ? '' : 'text-right'}`}>
          ⚡ ULTIMATE READY! (R)
        </div>
      )}
      
      {/* Special Bar (G Attack) */}
      <div className="w-full max-w-md h-2 bg-gray-800 rounded-full overflow-hidden mt-1 border border-green-500">
        <div 
          className={`h-full transition-all duration-100 ${isPlayer1 ? '' : 'ml-auto'} ${specialPercent >= 100 ? 'animate-pulse' : ''}`}
          style={{ 
            width: `${specialPercent}%`,
            background: specialPercent >= 100 
              ? 'linear-gradient(to right, #00ff00, #00cc00)' 
              : 'linear-gradient(to bottom, #22c55e, #16a34a)',
          }}
        />
      </div>
      {specialPercent >= 100 && (
        <div className={`text-xs text-green-400 font-bold mt-0.5 animate-pulse ${isPlayer1 ? '' : 'text-right'}`}>
          ✨ MINI-ULT READY! (G)
        </div>
      )}
      
      {/* Combo Counter */}
      {comboCount > 0 && (
        <div className={`flex items-center gap-1 mt-1 ${isPlayer1 ? '' : 'justify-end'}`}>
          <span className="text-xs text-gray-400">PUNCH COMBO:</span>
          {[1, 2, 3, 4].map((i) => (
            <div
              key={i}
              className={`w-5 h-5 rounded-full flex items-center justify-center text-xs font-bold transition-all ${
                i <= comboCount 
                  ? i === 4 ? 'bg-yellow-500 text-black scale-125' : 'bg-white text-black' 
                  : 'bg-gray-700 text-gray-500'
              }`}
            >
              {i}
            </div>
          ))}
          {comboCount === 3 && (
            <span className="text-xs text-yellow-400 animate-pulse ml-1">→ POWER HIT NEXT!</span>
          )}
        </div>
      )}
    </div>
  );
}

function ControlsDisplay({ 
  player, 
  character, 
  cooldowns,
  blast,
  specialBar 
}: { 
  player: 1 | 2;
  character: typeof CHARACTERS[CharacterId];
  cooldowns: { skill1: number; skill2: number; ultimate: number };
  blast: number;
  specialBar: number;
}) {
  // NUMBERED SKILL LABELS as requested
  const controls = player === 1
    ? { 
        move: 'WASD', 
        jump: 'SPACE', 
        skill1Key: 'Q',
        skill1Label: 'Skill 1',
        skill2Key: 'E',
        skill2Label: 'Skill 2',
        ultimateKey: 'R',
        ultimateLabel: 'Ultimate',
        block: 'F', 
        punch: 'CLICK',
        punchLabel: 'Punch',
        specialKey: 'G',
        specialLabel: 'Mini-Ult',
      }
    : { 
        move: '↑↓←→', 
        jump: 'Num0', 
        skill1Key: 'Num1',
        skill1Label: 'Skill 1',
        skill2Key: 'Num2',
        skill2Label: 'Skill 2',
        ultimateKey: 'Num3',
        ultimateLabel: 'Ultimate',
        block: 'Num4', 
        punch: 'Num6',
        punchLabel: 'Punch',
        specialKey: 'Num5',
        specialLabel: 'Mini-Ult',
      };
  
  return (
    <div className={`bg-black/60 backdrop-blur-sm rounded-lg p-3 ${player === 2 ? 'text-right' : ''}`}>
      <div className="text-xs text-gray-400 mb-2">
        Move: <span className="text-white">{controls.move}</span> | 
        Jump: <span className="text-white">{controls.jump}</span> | 
        Block: <span className="text-white">{controls.block}</span>
      </div>
      <div className={`flex gap-2 ${player === 2 ? 'flex-row-reverse' : ''}`}>
        <SkillButton 
          keyLabel={controls.punch}
          skillNumber="Punch"
          name={`${controls.punchLabel} (x4=Power Hit)`}
          cooldown={0}
          maxCooldown={1}
          color="#ffffff"
        />
        <SkillButton 
          keyLabel={controls.skill1Key}
          skillNumber="1"
          name={character.skill1Name}
          cooldown={cooldowns.skill1}
          maxCooldown={character.skill1Cooldown}
          color="#3b82f6"
        />
        <SkillButton 
          keyLabel={controls.skill2Key}
          skillNumber="2"
          name={character.skill2Name}
          cooldown={cooldowns.skill2}
          maxCooldown={character.skill2Cooldown}
          color="#f97316"
        />
        <SkillButton 
          keyLabel={controls.specialKey}
          skillNumber="★"
          name={`Mini-Ult: ${character.specialName}`}
          cooldown={specialBar < 100 ? 1 : 0}
          maxCooldown={1}
          color="#22c55e"
          isSpecial
        />
        <SkillButton 
          keyLabel={controls.ultimateKey}
          skillNumber="ULT"
          name={`Ultimate: ${character.ultimateName}`}
          cooldown={blast < 100 ? 1 : 0}
          maxCooldown={1}
          color="#a855f7"
          isUltimate
        />
      </div>
    </div>
  );
}

function SkillButton({ 
  keyLabel, 
  skillNumber,
  name, 
  cooldown, 
  maxCooldown, 
  color,
  isUltimate,
  isSpecial,
}: { 
  keyLabel: string;
  skillNumber: string;
  name: string;
  cooldown: number;
  maxCooldown: number;
  color: string;
  isUltimate?: boolean;
  isSpecial?: boolean;
}) {
  const isReady = cooldown <= 0;
  const cooldownPercent = (cooldown / maxCooldown) * 100;
  
  return (
    <div className="relative group pointer-events-auto">
      <div 
        className={`w-14 h-14 rounded-lg border-2 flex flex-col items-center justify-center font-bold text-white transition-all ${
          isReady ? 'opacity-100' : 'opacity-50'
        } ${(isUltimate || isSpecial) && isReady ? 'animate-pulse' : ''}`}
        style={{ 
          borderColor: color,
          backgroundColor: isReady ? color + '40' : '#1f2937',
        }}
      >
        {/* Skill Number/Type at top */}
        <span className="text-[10px] opacity-70">{skillNumber === 'Punch' ? '👊' : `Skill ${skillNumber}`}</span>
        {/* Key binding at bottom */}
        <span className="text-xs mt-0.5">{keyLabel}</span>
        
        {!isReady && (
          <div 
            className="absolute inset-0 bg-black/60 rounded-lg"
            style={{ 
              clipPath: `inset(${100 - cooldownPercent}% 0 0 0)`,
            }}
          />
        )}
      </div>
      
      {/* Tooltip */}
      <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50">
        <div className="bg-black/95 text-white text-xs px-3 py-2 rounded whitespace-nowrap border border-gray-600">
          <div className="font-bold" style={{ color }}>{name}</div>
          <div className="text-gray-400 text-[10px] mt-1">
            Press <span className="text-white font-bold">{keyLabel}</span> to use
          </div>
        </div>
      </div>
    </div>
  );
}

export function UltimateOverlay() {
  const { isUltimateActive, ultimateOwner, player1, player2 } = useGameStore();
  
  if (!isUltimateActive || !ultimateOwner) return null;
  
  const player = ultimateOwner === 1 ? player1 : player2;
  const character = CHARACTERS[player.characterId];
  
  return (
    <div className="absolute inset-0 pointer-events-none z-50">
      {/* Darkened background */}
      <div className="absolute inset-0 bg-black/80" />
      
      {/* Cinematic bars */}
      <div className="absolute top-0 left-0 right-0 h-20 bg-black" />
      <div className="absolute bottom-0 left-0 right-0 h-20 bg-black" />
      
      {/* Ultimate name */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center">
          <div 
            className="text-7xl font-black tracking-wider animate-pulse"
            style={{ 
              color: character.secondaryColor,
              textShadow: `0 0 30px ${character.secondaryColor}, 0 0 60px ${character.secondaryColor}, 0 0 90px ${character.secondaryColor}`,
            }}
          >
            {character.ultimateName.toUpperCase()}
          </div>
          <div className="text-3xl text-white mt-4 font-bold">{character.name}</div>
          <div className="text-lg text-gray-400 mt-2">{character.ultimateDescription}</div>
        </div>
      </div>
      
      {/* Energy lines */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className="absolute h-1 animate-ping"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${20 + Math.random() * 60}%`,
              width: `${100 + Math.random() * 300}px`,
              backgroundColor: character.secondaryColor,
              transform: `rotate(${Math.random() * 360}deg)`,
              animationDelay: `${i * 0.08}s`,
              opacity: 0.7,
            }}
          />
        ))}
      </div>
    </div>
  );
}
