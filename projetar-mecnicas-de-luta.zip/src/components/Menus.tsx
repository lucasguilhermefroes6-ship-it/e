import { useState } from 'react';
import { useGameStore, CHARACTERS, CharacterId, BOSSES } from '../store/gameStore';

// ============== MOVELIST MENU ==============
function MovelistMenu({ onClose }: { onClose: () => void }) {
  const [selectedChar, setSelectedChar] = useState<CharacterId>('seiya');
  const characters = Object.values(CHARACTERS);
  const char = CHARACTERS[selectedChar];
  
  return (
    <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-indigo-900 to-gray-900 flex flex-col z-50">
      {/* Header */}
      <div className="flex justify-between items-center p-4 bg-black/50">
        <h1 className="text-3xl font-bold text-white">📖 MOVELIST</h1>
        <button
          onClick={onClose}
          className="px-6 py-2 bg-red-600 hover:bg-red-500 text-white font-bold rounded-lg"
        >
          ✕ CLOSE
        </button>
      </div>
      
      <div className="flex flex-1 overflow-hidden">
        {/* Character List */}
        <div className="w-64 bg-black/30 overflow-y-auto p-2">
          <div className="text-sm text-gray-400 mb-2 px-2">SELECT CHARACTER</div>
          {characters.map((c) => (
            <button
              key={c.id}
              onClick={() => setSelectedChar(c.id)}
              className={`w-full flex items-center gap-3 p-2 rounded-lg mb-1 transition-all ${
                selectedChar === c.id 
                  ? 'bg-gradient-to-r from-purple-600 to-blue-600' 
                  : 'hover:bg-white/10'
              }`}
            >
              <div
                className="w-10 h-10 rounded-full flex items-center justify-center text-lg font-bold text-white"
                style={{ backgroundColor: c.color }}
              >
                {c.name.charAt(0)}
              </div>
              <div className="text-left">
                <div className="text-white font-bold text-sm">{c.name}</div>
                <div className="text-gray-400 text-xs">{c.style}</div>
              </div>
            </button>
          ))}
        </div>
        
        {/* Move Details */}
        <div className="flex-1 overflow-y-auto p-6">
          {/* Character Header */}
          <div className="flex items-center gap-4 mb-6 pb-4 border-b border-white/20">
            <div
              className="w-20 h-20 rounded-full flex items-center justify-center text-4xl font-bold text-white"
              style={{ backgroundColor: char.color }}
            >
              {char.name.charAt(0)}
            </div>
            <div>
              <h2 className="text-3xl font-bold text-white">{char.name}</h2>
              <div className="text-lg text-purple-400">{char.style}</div>
              <div className="flex gap-4 mt-2 text-sm">
                <span className="text-green-400">HP: {char.maxHealth}</span>
                <span className="text-blue-400">SPD: {(char.speed * 100).toFixed(0)}</span>
                <span className="text-yellow-400">WGT: {char.weight}</span>
              </div>
            </div>
          </div>
          
          {/* Passive */}
          <div className="bg-purple-900/30 rounded-lg p-4 mb-4 border border-purple-500/50">
            <div className="flex items-center gap-2 mb-2">
              <span className="text-2xl">⭐</span>
              <span className="text-purple-300 font-bold text-lg">PASSIVE: {char.passiveName}</span>
            </div>
            <p className="text-gray-300">{char.passiveDescription}</p>
          </div>
          
          {/* Skills Grid */}
          <div className="grid grid-cols-2 gap-4">
            {/* Skill 1 */}
            <div className="bg-blue-900/30 rounded-lg p-4 border border-blue-500/50">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="bg-blue-500 text-white text-xs font-bold px-2 py-1 rounded">SKILL 1</span>
                  <span className="text-xs text-gray-400">[Q]</span>
                </div>
                <span className="text-blue-300 text-sm">Cost: {char.skill1Cost} | CD: {(char.skill1Cooldown/1000).toFixed(1)}s</span>
              </div>
              <h3 className="text-xl font-bold text-white mb-2">{char.skill1Name}</h3>
              <p className="text-gray-300 text-sm mb-2">{char.skill1Description}</p>
              <div className="text-yellow-400 text-sm">Damage: {char.skill1Damage}</div>
            </div>
            
            {/* Skill 2 */}
            <div className="bg-orange-900/30 rounded-lg p-4 border border-orange-500/50">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="bg-orange-500 text-white text-xs font-bold px-2 py-1 rounded">SKILL 2</span>
                  <span className="text-xs text-gray-400">[E]</span>
                </div>
                <span className="text-orange-300 text-sm">Cost: {char.skill2Cost} | CD: {(char.skill2Cooldown/1000).toFixed(1)}s</span>
              </div>
              <h3 className="text-xl font-bold text-white mb-2">{char.skill2Name}</h3>
              <p className="text-gray-300 text-sm mb-2">{char.skill2Description}</p>
              <div className="text-yellow-400 text-sm">Damage: {char.skill2Damage}</div>
            </div>
            
            {/* Special Attack */}
            <div className="bg-green-900/30 rounded-lg p-4 border border-green-500/50">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="bg-green-500 text-white text-xs font-bold px-2 py-1 rounded">SPECIAL</span>
                  <span className="text-xs text-gray-400">[G] (Bar Full)</span>
                </div>
              </div>
              <h3 className="text-xl font-bold text-white mb-2">{char.specialName}</h3>
              <p className="text-gray-300 text-sm mb-2">{char.specialDescription}</p>
              <div className="text-yellow-400 text-sm">Damage: {char.specialDamage}</div>
            </div>
            
            {/* Ultimate */}
            <div className="bg-gradient-to-br from-red-900/50 to-purple-900/50 rounded-lg p-4 border border-red-500/50">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="bg-gradient-to-r from-red-500 to-purple-500 text-white text-xs font-bold px-2 py-1 rounded">ULTIMATE</span>
                  <span className="text-xs text-gray-400">[R] (Blast 100%)</span>
                </div>
              </div>
              <h3 className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-red-400 to-purple-400 mb-2">
                {char.ultimateName}
              </h3>
              <p className="text-gray-300 text-sm mb-2">{char.ultimateDescription}</p>
              <div className="text-yellow-400 text-sm">Damage: {char.ultimateDamage}</div>
            </div>
          </div>
          
          {/* Controls Reference */}
          <div className="mt-6 bg-gray-900/50 rounded-lg p-4">
            <h3 className="text-lg font-bold text-white mb-3">🎮 CONTROLS</h3>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <div className="text-blue-400 font-bold mb-2">PLAYER 1</div>
                <div className="space-y-1 text-gray-300">
                  <div><span className="text-white">WASD</span> - Move</div>
                  <div><span className="text-white">SPACE</span> - Jump</div>
                  <div><span className="text-white">Q</span> - Skill 1</div>
                  <div><span className="text-white">E</span> - Skill 2</div>
                  <div><span className="text-white">G</span> - Special (bar full)</div>
                  <div><span className="text-white">R</span> - Ultimate (blast full)</div>
                  <div><span className="text-white">F</span> - Block</div>
                  <div><span className="text-white">CLICK</span> - Punch Combo</div>
                </div>
              </div>
              <div>
                <div className="text-red-400 font-bold mb-2">PLAYER 2 (PvP)</div>
                <div className="space-y-1 text-gray-300">
                  <div><span className="text-white">ARROWS</span> - Move</div>
                  <div><span className="text-white">NUM0</span> - Jump</div>
                  <div><span className="text-white">NUM1</span> - Skill 1</div>
                  <div><span className="text-white">NUM2</span> - Skill 2</div>
                  <div><span className="text-white">NUM5</span> - Special</div>
                  <div><span className="text-white">NUM3</span> - Ultimate</div>
                  <div><span className="text-white">NUM4</span> - Block</div>
                  <div><span className="text-white">NUM6</span> - Punch Combo</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function MainMenu() {
  const { gameState, startGame, setGameMode, setSelectedBoss } = useGameStore();
  const [showMovelist, setShowMovelist] = useState(false);
  
  if (gameState !== 'menu') return null;
  
  if (showMovelist) {
    return <MovelistMenu onClose={() => setShowMovelist(false)} />;
  }
  
  return (
    <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 flex flex-col items-center justify-center z-50">
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full opacity-20 animate-pulse"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              width: `${50 + Math.random() * 100}px`,
              height: `${50 + Math.random() * 100}px`,
              backgroundColor: ['#6366f1', '#f97316', '#22c55e', '#a855f7'][Math.floor(Math.random() * 4)],
              animationDelay: `${i * 0.2}s`,
              animationDuration: `${2 + Math.random() * 3}s`,
            }}
          />
        ))}
      </div>
      
      {/* Title */}
      <div className="relative z-10 text-center mb-12">
        <h1 className="text-7xl font-black text-transparent bg-clip-text bg-gradient-to-r from-orange-500 via-purple-500 to-cyan-500 mb-2">
          OMNIVERSE CHAOS
        </h1>
        <h2 className="text-4xl font-bold text-white tracking-widest">
          ARENA
        </h2>
        <div className="mt-4 text-gray-400 text-lg">
          14 Fighters • 3 Bosses • Infinite Battles • Ultimate Chaos
        </div>
      </div>
      
      {/* Menu Options */}
      <div className="relative z-10 flex flex-col gap-4">
        <button
          onClick={() => {
            setGameMode('pvp');
            startGame();
          }}
          className="px-12 py-4 bg-gradient-to-r from-orange-500 to-red-500 text-white text-2xl font-bold rounded-lg hover:scale-105 transition-transform shadow-lg shadow-orange-500/50"
        >
          🎮 VERSUS MODE (PvP)
        </button>
        
        <button
          onClick={() => {
            setGameMode('pve');
            startGame();
          }}
          className="px-12 py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white text-xl font-bold rounded-lg hover:scale-105 transition-transform shadow-lg shadow-purple-500/50"
        >
          🤖 VS BOT (PvE)
        </button>
        
        <button
          onClick={() => {
            setGameMode('2v2');
            startGame();
          }}
          className="px-12 py-4 bg-gradient-to-r from-green-600 to-teal-600 text-white text-xl font-bold rounded-lg hover:scale-105 transition-transform shadow-lg shadow-green-500/50"
        >
          👥 2v2 TAG BATTLE
        </button>
        
        <button
          onClick={() => {
            setGameMode('boss');
            setSelectedBoss(null);
            startGame();
          }}
          className="px-12 py-4 bg-gradient-to-r from-red-700 to-yellow-600 text-white text-xl font-bold rounded-lg hover:scale-105 transition-transform shadow-lg shadow-red-500/50"
        >
          👹 BOSS BATTLE
        </button>
        
        <div className="h-4" />
        
        <button
          onClick={() => setShowMovelist(true)}
          className="px-12 py-4 bg-gradient-to-r from-cyan-600 to-blue-600 text-white text-xl font-bold rounded-lg hover:scale-105 transition-transform shadow-lg shadow-cyan-500/50"
        >
          📖 MOVELIST
        </button>
      </div>
      
      {/* Footer */}
      <div className="absolute bottom-4 text-gray-500 text-sm">
        Press ENTER or click to start • A Fan Project
      </div>
    </div>
  );
}

export function CharacterSelect() {
  const { gameState, gameMode, selectCharacter, startRound, player1, player2, player3, player4, selectedBoss, setSelectedBoss, startBossFight } = useGameStore();
  const [selectedP1, setSelectedP1] = useState<CharacterId>(player1.characterId);
  const [selectedP2, setSelectedP2] = useState<CharacterId>(player2.characterId);
  const [selectedP3, setSelectedP3] = useState<CharacterId>(player3?.characterId || 'yuji');
  const [selectedP4, setSelectedP4] = useState<CharacterId>(player4?.characterId || 'harry');
  const [confirmedP1, setConfirmedP1] = useState(false);
  const [confirmedP2, setConfirmedP2] = useState(false);
  const [confirmedP3, setConfirmedP3] = useState(false);
  const [confirmedP4, setConfirmedP4] = useState(false);
  const [selectedBossId, setSelectedBossId] = useState<string | null>(selectedBoss);
  
  if (gameState !== 'character-select') return null;
  
  const characters = Object.values(CHARACTERS);
  const bosses = Object.entries(BOSSES);
  const is2v2 = gameMode === '2v2';
  const isBossMode = gameMode === 'boss';
  
  const handleConfirm = (player: 1 | 2 | 3 | 4) => {
    if (player === 1) {
      selectCharacter(1, selectedP1);
      setConfirmedP1(true);
    } else if (player === 2) {
      selectCharacter(2, selectedP2);
      setConfirmedP2(true);
    } else if (player === 3) {
      selectCharacter(3, selectedP3);
      setConfirmedP3(true);
    } else if (player === 4) {
      selectCharacter(4, selectedP4);
      setConfirmedP4(true);
    }
  };
  
  const handleStart = () => {
    if (isBossMode) {
      if (confirmedP1 && selectedBossId) {
        setSelectedBoss(selectedBossId);
        startBossFight();
      }
    } else if (is2v2) {
      if (confirmedP1 && confirmedP2 && confirmedP3 && confirmedP4) {
        startRound();
      }
    } else {
      if (confirmedP1 && confirmedP2) {
        startRound();
      }
    }
  };
  
  const canStart = isBossMode 
    ? confirmedP1 && selectedBossId
    : is2v2 
      ? confirmedP1 && confirmedP2 && confirmedP3 && confirmedP4
      : confirmedP1 && confirmedP2;
  
  return (
    <div className="absolute inset-0 bg-gradient-to-br from-gray-900 via-indigo-900 to-gray-900 flex flex-col z-50">
      {/* Header */}
      <div className="text-center py-4">
        <h1 className="text-3xl font-bold text-white">
          {isBossMode ? '⚔️ SELECT CHALLENGER & BOSS' : is2v2 ? '👥 SELECT YOUR TEAMS' : 'SELECT YOUR FIGHTER'}
        </h1>
        <div className="text-sm text-gray-400 mt-1">
          {isBossMode ? 'Choose your fighter and face a powerful boss!' : is2v2 ? 'Team 1 (Blue) vs Team 2 (Red)' : 'Player 1 vs Player 2'}
        </div>
      </div>
      
      {/* Character Grid */}
      <div className="flex-1 flex flex-col items-center px-4 overflow-auto">
        {/* Boss Selection for Boss Mode */}
        {isBossMode && (
          <div className="mb-6">
            <h2 className="text-xl font-bold text-red-400 text-center mb-3">👹 SELECT BOSS</h2>
            <div className="flex gap-4 justify-center">
              {bosses.map(([bossId, boss]) => (
                <div
                  key={bossId}
                  className={`cursor-pointer transition-all hover:scale-105 ${selectedBossId === bossId ? 'scale-110' : ''}`}
                  onClick={() => setSelectedBossId(bossId)}
                >
                  <div
                    className={`w-32 h-40 rounded-lg flex flex-col items-center justify-center p-3 border-4 transition-all ${
                      selectedBossId === bossId
                        ? 'border-red-500 shadow-lg shadow-red-500/50'
                        : 'border-gray-600 hover:border-gray-400'
                    }`}
                    style={{ backgroundColor: boss.color + '40' }}
                  >
                    <div
                      className="w-16 h-16 rounded-full mb-2 flex items-center justify-center text-3xl font-bold text-white"
                      style={{ backgroundColor: boss.color }}
                    >
                      👹
                    </div>
                    <div className="text-sm text-white text-center font-bold">{boss.bossName}</div>
                    <div className="text-xs text-gray-400 text-center mt-1">HP x{boss.healthMultiplier}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        
        <div className="grid grid-cols-7 gap-3 max-w-5xl">
          {characters.map((char) => {
            const isP1Selected = selectedP1 === char.id;
            const isP2Selected = !isBossMode && selectedP2 === char.id;
            const isP3Selected = is2v2 && selectedP3 === char.id;
            const isP4Selected = is2v2 && selectedP4 === char.id;
            
            return (
              <div
                key={char.id}
                className={`relative cursor-pointer transition-all hover:scale-110 ${
                  isP1Selected || isP2Selected || isP3Selected || isP4Selected ? 'scale-105' : ''
                }`}
              >
                <div
                  className={`w-20 h-24 rounded-lg flex flex-col items-center justify-center p-2 border-2 transition-all ${
                    isP1Selected && isP2Selected
                      ? 'border-purple-500 shadow-lg shadow-purple-500/50'
                      : isP1Selected || isP3Selected
                      ? 'border-blue-500 shadow-lg shadow-blue-500/50'
                      : isP2Selected || isP4Selected
                      ? 'border-red-500 shadow-lg shadow-red-500/50'
                      : 'border-gray-600 hover:border-gray-400'
                  }`}
                  style={{ backgroundColor: char.color + '40' }}
                  onClick={() => {
                    if (!confirmedP1) setSelectedP1(char.id);
                    if (!confirmedP2 && !isBossMode) setSelectedP2(char.id);
                    if (is2v2 && !confirmedP3) setSelectedP3(char.id);
                    if (is2v2 && !confirmedP4) setSelectedP4(char.id);
                  }}
                >
                  <div
                    className="w-12 h-12 rounded-full mb-1 flex items-center justify-center text-2xl font-bold text-white"
                    style={{ backgroundColor: char.color }}
                  >
                    {char.name.charAt(0)}
                  </div>
                  <div className="text-xs text-white text-center truncate w-full">
                    {char.name}
                  </div>
                </div>
                
                {/* Selection indicators */}
                {isP1Selected && (
                  <div className="absolute -top-2 -left-2 w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center text-xs font-bold text-white">
                    P1
                  </div>
                )}
                {isP2Selected && (
                  <div className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center text-xs font-bold text-white">
                    P2
                  </div>
                )}
                {isP3Selected && (
                  <div className="absolute -bottom-2 -left-2 w-6 h-6 bg-blue-400 rounded-full flex items-center justify-center text-xs font-bold text-white">
                    P3
                  </div>
                )}
                {isP4Selected && (
                  <div className="absolute -bottom-2 -right-2 w-6 h-6 bg-red-400 rounded-full flex items-center justify-center text-xs font-bold text-white">
                    P4
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
      
      {/* Bottom Panel */}
      <div className="bg-black/50 p-4">
        <div className="max-w-5xl mx-auto">
          {is2v2 ? (
            <div className="flex justify-between items-end">
              {/* Team 1 */}
              <div className="flex gap-4">
                <CharacterPreview 
                  character={CHARACTERS[selectedP1]} 
                  player={1}
                  label="P1"
                  confirmed={confirmedP1}
                  onConfirm={() => handleConfirm(1)}
                  onCancel={() => setConfirmedP1(false)}
                  teamColor="blue"
                />
                <CharacterPreview 
                  character={CHARACTERS[selectedP3]} 
                  player={3}
                  label="P3 (AI)"
                  confirmed={confirmedP3}
                  onConfirm={() => handleConfirm(3)}
                  onCancel={() => setConfirmedP3(false)}
                  teamColor="blue"
                />
              </div>
              
              {/* VS */}
              <div className="text-center">
                <div className="text-4xl font-black text-white mb-4">VS</div>
                {canStart && (
                  <button
                    onClick={handleStart}
                    className="px-8 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-lg hover:scale-105 transition-transform animate-pulse"
                  >
                    START BATTLE!
                  </button>
                )}
              </div>
              
              {/* Team 2 */}
              <div className="flex gap-4">
                <CharacterPreview 
                  character={CHARACTERS[selectedP2]} 
                  player={2}
                  label="P2 (AI)"
                  confirmed={confirmedP2}
                  onConfirm={() => handleConfirm(2)}
                  onCancel={() => setConfirmedP2(false)}
                  teamColor="red"
                />
                <CharacterPreview 
                  character={CHARACTERS[selectedP4]} 
                  player={4}
                  label="P4 (AI)"
                  confirmed={confirmedP4}
                  onConfirm={() => handleConfirm(4)}
                  onCancel={() => setConfirmedP4(false)}
                  teamColor="red"
                />
              </div>
            </div>
          ) : isBossMode ? (
            <div className="flex justify-between items-end">
              <CharacterPreview 
                character={CHARACTERS[selectedP1]} 
                player={1}
                label="CHALLENGER"
                confirmed={confirmedP1}
                onConfirm={() => handleConfirm(1)}
                onCancel={() => setConfirmedP1(false)}
                teamColor="blue"
              />
              
              <div className="text-center">
                <div className="text-4xl font-black text-white mb-4">VS</div>
                {canStart && (
                  <button
                    onClick={handleStart}
                    className="px-8 py-3 bg-gradient-to-r from-red-500 to-orange-500 text-white font-bold rounded-lg hover:scale-105 transition-transform animate-pulse"
                  >
                    CHALLENGE BOSS!
                  </button>
                )}
              </div>
              
              {selectedBossId && (
                <div className="w-64 text-right">
                  <div className="text-2xl font-bold text-red-400">{BOSSES[selectedBossId].bossName}</div>
                  <div className="text-sm text-gray-400">{BOSSES[selectedBossId].bossDescription}</div>
                  <div className="text-xs text-yellow-400 mt-2">
                    ⚠️ HP x{BOSSES[selectedBossId].healthMultiplier} | DMG x{BOSSES[selectedBossId].damageMultiplier}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="flex justify-between items-end">
              <CharacterPreview 
                character={CHARACTERS[selectedP1]} 
                player={1}
                confirmed={confirmedP1}
                onConfirm={() => handleConfirm(1)}
                onCancel={() => setConfirmedP1(false)}
              />
              
              <div className="text-center">
                <div className="text-4xl font-black text-white mb-4">VS</div>
                {canStart && (
                  <button
                    onClick={handleStart}
                    className="px-8 py-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white font-bold rounded-lg hover:scale-105 transition-transform animate-pulse"
                  >
                    START BATTLE!
                  </button>
                )}
              </div>
              
              <CharacterPreview 
                character={CHARACTERS[selectedP2]} 
                player={2}
                confirmed={confirmedP2}
                onConfirm={() => handleConfirm(2)}
                onCancel={() => setConfirmedP2(false)}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function CharacterPreview({ 
  character, 
  player, 
  label,
  confirmed,
  onConfirm,
  onCancel,
  teamColor,
}: { 
  character: typeof CHARACTERS[CharacterId];
  player: 1 | 2 | 3 | 4;
  label?: string;
  confirmed: boolean;
  onConfirm: () => void;
  onCancel: () => void;
  teamColor?: 'blue' | 'red';
}) {
  const isRight = player === 2 || player === 4;
  const displayLabel = label || `P${player}`;
  const borderColor = teamColor === 'blue' ? '#3b82f6' : teamColor === 'red' ? '#ef4444' : (player === 1 || player === 3 ? '#3b82f6' : '#ef4444');
  
  return (
    <div className={`w-48 ${isRight ? 'text-right' : ''}`}>
      <div className={`flex items-center gap-2 mb-2 ${isRight ? 'flex-row-reverse' : ''}`}>
        <div
          className="w-12 h-12 rounded-full flex items-center justify-center text-xl font-bold text-white border-3"
          style={{ 
            backgroundColor: character.color,
            borderColor: borderColor,
            borderWidth: '3px',
          }}
        >
          {character.name.charAt(0)}
        </div>
        <div>
          <div className="text-sm font-bold text-white">{character.name}</div>
          <div className="text-xs text-gray-400">{displayLabel}</div>
        </div>
      </div>
      
      {/* Mini Stats */}
      <div className="space-y-1 mb-2">
        <StatBar label="HP" value={character.maxHealth} max={180} color="#22c55e" />
        <StatBar label="SPD" value={character.speed * 500} max={110} color="#3b82f6" />
      </div>
      
      {/* Confirm Button */}
      <div>
        {!confirmed ? (
          <button
            onClick={onConfirm}
            className="w-full py-1.5 text-sm font-bold rounded-lg transition-all"
            style={{ backgroundColor: borderColor }}
          >
            CONFIRM
          </button>
        ) : (
          <button
            onClick={onCancel}
            className="w-full py-1.5 bg-gray-600 hover:bg-gray-500 text-white text-sm font-bold rounded-lg"
          >
            ✓ LOCKED
          </button>
        )}
      </div>
    </div>
  );
}

function StatBar({ label, value, max, color }: { label: string; value: number; max: number; color: string }) {
  const percent = Math.min(100, (value / max) * 100);
  
  return (
    <div className="flex items-center gap-2">
      <span className="text-xs text-gray-400 w-8">{label}</span>
      <div className="flex-1 h-1.5 bg-gray-700 rounded-full overflow-hidden">
        <div 
          className="h-full rounded-full"
          style={{ width: `${percent}%`, backgroundColor: color }}
        />
      </div>
    </div>
  );
}

export function RoundEnd() {
  const { gameState, round, startRound, team1Wins, team2Wins } = useGameStore();
  
  if (gameState !== 'round-end') return null;
  
  const lastWinner = team1Wins > team2Wins ? 1 : 2;
  
  return (
    <div className="absolute inset-0 bg-black/80 flex items-center justify-center z-50">
      <div className="text-center">
        <div className="text-6xl font-black text-white mb-4">
          ROUND {round - 1} COMPLETE
        </div>
        <div className={`text-4xl font-bold mb-8 ${lastWinner === 1 ? 'text-blue-400' : 'text-red-400'}`}>
          TEAM {lastWinner} WINS!
        </div>
        <div className="flex justify-center gap-8 mb-8">
          <div className="text-center">
            <div className="text-2xl text-blue-400">TEAM 1</div>
            <div className="text-5xl font-bold text-white">{team1Wins}</div>
          </div>
          <div className="text-4xl text-gray-500">-</div>
          <div className="text-center">
            <div className="text-2xl text-red-400">TEAM 2</div>
            <div className="text-5xl font-bold text-white">{team2Wins}</div>
          </div>
        </div>
        <button
          onClick={startRound}
          className="px-12 py-4 bg-gradient-to-r from-purple-600 to-blue-600 text-white text-2xl font-bold rounded-lg hover:scale-105 transition-transform"
        >
          NEXT ROUND
        </button>
      </div>
    </div>
  );
}

export function GameOver() {
  const { gameState, team1Wins, team2Wins, resetGame, player1, player2, gameMode } = useGameStore();
  
  if (gameState !== 'game-over') return null;
  
  const winner = team1Wins > team2Wins ? 1 : 2;
  const winnerChar = CHARACTERS[winner === 1 ? player1.characterId : player2.characterId];
  const isBossMode = gameMode === 'boss';
  const bossDefeated = isBossMode && winner === 1;
  
  return (
    <div className="absolute inset-0 bg-black/90 flex items-center justify-center z-50">
      <div className="text-center">
        {isBossMode ? (
          <>
            <div 
              className="text-8xl font-black mb-4"
              style={{ 
                color: bossDefeated ? '#FFD700' : '#ff0000',
                textShadow: `0 0 30px ${bossDefeated ? '#FFD700' : '#ff0000'}`,
              }}
            >
              {bossDefeated ? 'BOSS DEFEATED!' : 'BOSS WINS!'}
            </div>
            <div className="text-4xl font-bold text-white mb-8">
              {bossDefeated ? `${winnerChar.name} is victorious!` : 'The challenger has fallen...'}
            </div>
          </>
        ) : (
          <>
            <div 
              className="text-8xl font-black mb-4"
              style={{ 
                color: winnerChar.secondaryColor,
                textShadow: `0 0 30px ${winnerChar.secondaryColor}`,
              }}
            >
              {winnerChar.name.toUpperCase()}
            </div>
            <div className="text-4xl font-bold text-white mb-8">
              TEAM {winner} WINS THE MATCH!
            </div>
          </>
        )}
        
        <div className="flex justify-center gap-8 mb-8">
          <div className="text-center">
            <div className="text-2xl text-blue-400">{isBossMode ? 'PLAYER' : 'TEAM 1'}</div>
            <div className="text-5xl font-bold text-white">{team1Wins}</div>
          </div>
          <div className="text-4xl text-gray-500">-</div>
          <div className="text-center">
            <div className="text-2xl text-red-400">{isBossMode ? 'BOSS' : 'TEAM 2'}</div>
            <div className="text-5xl font-bold text-white">{team2Wins}</div>
          </div>
        </div>
        
        <div className="flex gap-4 justify-center">
          <button
            onClick={() => {
              resetGame();
              useGameStore.getState().startGame();
            }}
            className="px-8 py-4 bg-gradient-to-r from-green-600 to-emerald-600 text-white text-xl font-bold rounded-lg hover:scale-105 transition-transform"
          >
            REMATCH
          </button>
          <button
            onClick={resetGame}
            className="px-8 py-4 bg-gradient-to-r from-gray-600 to-gray-500 text-white text-xl font-bold rounded-lg hover:scale-105 transition-transform"
          >
            MAIN MENU
          </button>
        </div>
      </div>
    </div>
  );
}

export function PauseMenu() {
  const { gameState, setGameState, resetGame } = useGameStore();
  
  if (gameState !== 'paused') return null;
  
  return (
    <div className="absolute inset-0 bg-black/80 flex items-center justify-center z-50">
      <div className="text-center">
        <div className="text-5xl font-bold text-white mb-8">PAUSED</div>
        <div className="flex flex-col gap-4">
          <button
            onClick={() => setGameState('fighting')}
            className="px-12 py-4 bg-gradient-to-r from-green-600 to-emerald-600 text-white text-xl font-bold rounded-lg hover:scale-105 transition-transform"
          >
            RESUME
          </button>
          <button
            onClick={resetGame}
            className="px-12 py-4 bg-gradient-to-r from-red-600 to-red-500 text-white text-xl font-bold rounded-lg hover:scale-105 transition-transform"
          >
            QUIT TO MENU
          </button>
        </div>
      </div>
    </div>
  );
}
