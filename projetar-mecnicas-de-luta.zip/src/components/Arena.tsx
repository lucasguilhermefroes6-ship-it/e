import { useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { Mesh } from 'three';

export function Arena() {
  const platformRef = useRef<Mesh>(null);
  
  useFrame((state) => {
    // Subtle floating animation for the arena
    if (platformRef.current) {
      platformRef.current.position.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.05 - 0.5;
    }
  });

  return (
    <group>
      {/* Main Platform */}
      <mesh ref={platformRef} position={[0, -0.5, 0]} receiveShadow>
        <cylinderGeometry args={[18, 20, 1, 32]} />
        <meshStandardMaterial color="#2a2a3e" metalness={0.6} roughness={0.3} />
      </mesh>
      
      {/* Inner Ring */}
      <mesh position={[0, -0.48, 0]}>
        <cylinderGeometry args={[15, 15, 0.1, 32]} />
        <meshStandardMaterial color="#4a4a6e" metalness={0.8} roughness={0.2} emissive="#3a3a5e" emissiveIntensity={0.3} />
      </mesh>
      
      {/* Center Circle */}
      <mesh position={[0, -0.45, 0]}>
        <cylinderGeometry args={[3, 3, 0.1, 32]} />
        <meshStandardMaterial color="#6366f1" metalness={0.9} roughness={0.1} emissive="#6366f1" emissiveIntensity={0.5} />
      </mesh>
      
      {/* Corner Pillars */}
      {[0, 1, 2, 3].map((i) => {
        const angle = (i * Math.PI * 2) / 4 + Math.PI / 4;
        const x = Math.cos(angle) * 17;
        const z = Math.sin(angle) * 17;
        return (
          <group key={i} position={[x, 0, z]}>
            <mesh position={[0, 2, 0]} castShadow>
              <boxGeometry args={[1.5, 5, 1.5]} />
              <meshStandardMaterial color="#1a1a2e" metalness={0.7} roughness={0.3} />
            </mesh>
            {/* Glowing top */}
            <mesh position={[0, 4.8, 0]}>
              <boxGeometry args={[1.8, 0.4, 1.8]} />
              <meshStandardMaterial 
                color="#f97316" 
                emissive="#f97316" 
                emissiveIntensity={2} 
              />
            </mesh>
            {/* Point light */}
            <pointLight position={[0, 5, 0]} color="#f97316" intensity={2} distance={8} />
          </group>
        );
      })}
      
      {/* Barrier Energy Ring */}
      <mesh position={[0, 3, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <torusGeometry args={[19, 0.1, 16, 100]} />
        <meshStandardMaterial 
          color="#06b6d4" 
          emissive="#06b6d4" 
          emissiveIntensity={1} 
          transparent 
          opacity={0.6} 
        />
      </mesh>
      
      {/* Ground decorations - grid lines */}
      {[-12, -6, 0, 6, 12].map((pos) => (
        <group key={`grid-${pos}`}>
          <mesh position={[pos, -0.44, 0]} rotation={[0, 0, 0]}>
            <boxGeometry args={[0.05, 0.02, 30]} />
            <meshStandardMaterial color="#6366f1" emissive="#6366f1" emissiveIntensity={0.3} transparent opacity={0.5} />
          </mesh>
          <mesh position={[0, -0.44, pos]} rotation={[0, 0, 0]}>
            <boxGeometry args={[30, 0.02, 0.05]} />
            <meshStandardMaterial color="#6366f1" emissive="#6366f1" emissiveIntensity={0.3} transparent opacity={0.5} />
          </mesh>
        </group>
      ))}
    </group>
  );
}

export function Skybox() {
  return (
    <>
      {/* Ambient skybox color */}
      <mesh scale={[-1, 1, 1]}>
        <sphereGeometry args={[100, 32, 32]} />
        <meshBasicMaterial color="#0a0a1a" side={2} />
      </mesh>
      
      {/* Stars */}
      {Array.from({ length: 200 }).map((_, i) => {
        const theta = Math.random() * Math.PI * 2;
        const phi = Math.random() * Math.PI;
        const r = 90;
        return (
          <mesh
            key={i}
            position={[
              r * Math.sin(phi) * Math.cos(theta),
              r * Math.cos(phi),
              r * Math.sin(phi) * Math.sin(theta),
            ]}
          >
            <sphereGeometry args={[0.1 + Math.random() * 0.2, 8, 8]} />
            <meshBasicMaterial color="#ffffff" />
          </mesh>
        );
      })}
      
      {/* Nebula effect - colored spheres */}
      <mesh position={[40, 30, -50]}>
        <sphereGeometry args={[15, 16, 16]} />
        <meshBasicMaterial color="#6366f1" transparent opacity={0.1} />
      </mesh>
      <mesh position={[-50, 20, -40]}>
        <sphereGeometry args={[12, 16, 16]} />
        <meshBasicMaterial color="#f97316" transparent opacity={0.08} />
      </mesh>
    </>
  );
}
