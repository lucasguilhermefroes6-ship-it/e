import { useRef, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import { Mesh, Group } from 'three';
import { useGameStore, CHARACTERS } from '../store/gameStore';

// Limite máximo de efeitos para performance
const MAX_EFFECTS = 30;
const MAX_PROJECTILES = 20;

export function Projectiles() {
  const { projectiles, removeProjectile, updateProjectiles, player1, player2, player3, player4, updatePlayer, addEffect, setCameraShake, summons, updateSummons, gameMode } = useGameStore();
  
  useFrame((_, delta) => {
    updateProjectiles(delta);
    updateSummons(delta);
    
    // Check projectile collisions - suporta 4 jogadores
    const limitedProjectiles = projectiles.slice(0, MAX_PROJECTILES);
    
    // Coletar todos os alvos possíveis
    const allTargets = [player1, player2];
    if (gameMode === '2v2' && player3) allTargets.push(player3);
    if (gameMode === '2v2' && player4) allTargets.push(player4);
    
    limitedProjectiles.forEach((proj) => {
      // Encontrar alvos válidos (inimigos do dono do projétil)
      const ownerTeam = proj.owner === 1 || proj.owner === 3 ? 1 : 2;
      
      for (const target of allTargets) {
        // Não atingir a si mesmo ou aliados
        if (target.id === proj.owner) continue;
        if (target.team === ownerTeam) continue;
        
        // Não atingir alvos mortos ou invencíveis
        if (!target.isAlive || target.health <= 0 || target.isInvincible) continue;
        
        const targetChar = CHARACTERS[target.characterId];
        
        const dx = proj.position.x - target.position.x;
        const dy = proj.position.y - (target.position.y + 1);
        const dz = proj.position.z - target.position.z;
        const distance = Math.sqrt(dx * dx + dy * dy + dz * dz);
        
        if (distance < 1.3) {
          removeProjectile(proj.id);
          
          // Vapor passive check
          if (target.passiveStacks > 0 && targetChar.id === 'vapor') {
            updatePlayer(target.id, { passiveStacks: target.passiveStacks - 1 });
            return;
          }
          
          let damageMultiplier = target.isBlocking ? 0.2 : 1;
          if (proj.effect?.ignoreDefense) {
            damageMultiplier = target.isBlocking ? 0.5 : 1;
          }
          
          // Shrek passive
          if (targetChar.id === 'shrek') {
            const healthPercent = target.health / targetChar.maxHealth;
            if (healthPercent < 0.3) damageMultiplier *= 0.85;
            else if (healthPercent < 0.5) damageMultiplier *= 0.90;
          }
          
          const damage = proj.damage * damageMultiplier;
          const knockbackMult = proj.effect?.knockbackMultiplier || 1;
          let knockback = target.isBlocking ? 0.1 : (0.3 / targetChar.weight) * knockbackMult;
          
          if (target.superArmor) knockback = 0;
          
          // Limitar stun para evitar stun infinito
          let newStunned = target.isBlocking ? 0.1 : 0.3;
          let newBlindTimer = target.blindTimer;
          let newSlowTimer = target.slowTimer;
          
          if (proj.effect) {
            // Limitar stunDuration máximo aplicado
            if (proj.effect.stunDuration) {
              newStunned = Math.min(1.5, Math.max(newStunned, proj.effect.stunDuration));
            }
            if (proj.effect.blindDuration) {
              newBlindTimer = Math.min(3, Math.max(newBlindTimer, proj.effect.blindDuration));
            }
            if (proj.effect.slowPercent) {
              newSlowTimer = Math.min(3, Math.max(newSlowTimer, 2));
            }
          }
          
          updatePlayer(target.id, {
            health: Math.max(0, target.health - damage),
            stunned: newStunned,
            blast: Math.min(100, target.blast + damage * 0.3),
            specialBar: Math.min(100, target.specialBar + damage * 0.25),
            blindTimer: newBlindTimer,
            slowTimer: newSlowTimer,
            position: {
              x: Math.max(-17, Math.min(17, target.position.x - (dx / distance) * knockback * 3)),
              y: target.position.y,
              z: Math.max(-17, Math.min(17, target.position.z - (dz / distance) * knockback * 3)),
            },
          });
          
          addEffect({
            type: target.isBlocking ? 'block' : 'hit',
            position: { x: proj.position.x, y: proj.position.y, z: proj.position.z },
            lifetime: 0.3,
            color: target.isBlocking ? '#60a5fa' : proj.color,
            scale: target.isBlocking ? 1.5 : 2,
          });
          
          if (!target.isBlocking && !target.superArmor) {
            setCameraShake(0.2 * knockbackMult);
          }
          
          // Sair do loop após atingir um alvo
          break;
        }
      }
    });
    
    // Summon collisions são tratadas no gameStore.updateSummons
    // NÃO duplicar lógica aqui para evitar stun duplo
  });
  
  // Limitar quantidade renderizada
  const limitedProjectiles = projectiles.slice(0, MAX_PROJECTILES);
  const limitedSummons = summons.slice(0, 10);
  
  return (
    <>
      {limitedProjectiles.map((proj) => (
        <ProjectileMesh key={proj.id} projectile={proj} />
      ))}
      {limitedSummons.map((summon) => (
        <SummonMesh key={summon.id} summon={summon} />
      ))}
    </>
  );
}

function SummonMesh({ summon }: { summon: { type: string; position: { x: number; y: number; z: number }; owner: 1 | 2 | 3 | 4; behavior?: string; speed: number } }) {
  const groupRef = useRef<Group>(null);
  const meshRef = useRef<Mesh>(null);
  
  useFrame((state) => {
    if (meshRef.current && groupRef.current) {
      const isTrap = summon.behavior === 'trap' || summon.speed === 0;
      
      if (isTrap) {
        const pulse = 1 + Math.sin(state.clock.elapsedTime * 4) * 0.1;
        meshRef.current.scale.setScalar(pulse);
      } else {
        meshRef.current.rotation.y += 0.08;
        groupRef.current.position.y = summon.position.y + Math.sin(state.clock.elapsedTime * 5) * 0.1;
      }
    }
  });
  
  const color = useMemo(() => {
    if (summon.type.includes('searcher')) return '#1a1a1a';
    if (summon.type.includes('skull')) return '#8B0000';
    if (summon.type.includes('tape')) return '#C0C0C0';
    return '#FF69B4';
  }, [summon.type]);
  
  const isTrap = summon.behavior === 'trap' || summon.speed === 0;
  
  return (
    <group ref={groupRef} position={[summon.position.x, summon.position.y, summon.position.z]}>
      {isTrap ? (
        <mesh ref={meshRef} rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0]}>
          <circleGeometry args={[1.5, 12]} />
          <meshStandardMaterial
            color={color}
            emissive={color}
            emissiveIntensity={0.5}
            transparent
            opacity={0.7}
          />
        </mesh>
      ) : summon.type.includes('skull') ? (
        <>
          <mesh ref={meshRef}>
            <dodecahedronGeometry args={[0.4]} />
            <meshStandardMaterial color={color} emissive={'#ff0000'} emissiveIntensity={1.5} />
          </mesh>
          <pointLight color="#ff0000" intensity={1.5} distance={3} />
        </>
      ) : (
        <>
          <mesh ref={meshRef}>
            <capsuleGeometry args={[0.25, 0.5, 4, 6]} />
            <meshStandardMaterial color={color} emissive={'#FFD700'} emissiveIntensity={0.3} />
          </mesh>
          <pointLight color="#FFD700" intensity={0.8} distance={2} />
        </>
      )}
    </group>
  );
}

function ProjectileMesh({ projectile }: { projectile: { position: { x: number; y: number; z: number }; velocity: { x: number; y: number; z: number }; color: string; size: number; visualType?: string; skillType?: string } }) {
  const groupRef = useRef<Group>(null);
  const meshRef = useRef<Mesh>(null);
  
  useFrame((_, delta) => {
    if (meshRef.current) {
      meshRef.current.rotation.x += delta * 8;
      meshRef.current.rotation.y += delta * 12;
    }
  });
  
  const speed = Math.sqrt(projectile.velocity.x ** 2 + projectile.velocity.z ** 2);
  const rotation = speed > 0.1 ? Math.atan2(projectile.velocity.x, projectile.velocity.z) : 0;
  
  // Geometria simplificada baseada no tipo
  const geometry = useMemo(() => {
    const skillType = projectile.skillType || '';
    
    if (skillType.includes('concrete') || skillType.includes('boulder')) {
      return <boxGeometry args={[projectile.size * 1.4, projectile.size, projectile.size]} />;
    }
    if (skillType.includes('bomb') || skillType.includes('onion')) {
      return <sphereGeometry args={[projectile.size, 8, 8]} />;
    }
    if (skillType.includes('crescent') || skillType.includes('blade')) {
      return <torusGeometry args={[projectile.size, projectile.size * 0.3, 6, 12, Math.PI]} />;
    }
    
    return <octahedronGeometry args={[projectile.size]} />;
  }, [projectile.skillType, projectile.size]);
  
  const emissiveIntensity = useMemo(() => {
    const visualType = projectile.visualType || 'default';
    if (visualType === 'electric') return 2.5;
    if (visualType === 'fire') return 2;
    if (visualType === 'cosmic') return 1.8;
    return 1.2;
  }, [projectile.visualType]);
  
  return (
    <group 
      ref={groupRef}
      position={[projectile.position.x, projectile.position.y, projectile.position.z]}
      rotation={[0, rotation, 0]}
    >
      <mesh ref={meshRef}>
        {geometry}
        <meshStandardMaterial
          color={projectile.color}
          emissive={projectile.color}
          emissiveIntensity={emissiveIntensity}
        />
      </mesh>
      
      {/* Glow simplificado */}
      <mesh scale={1.2}>
        <sphereGeometry args={[projectile.size, 6, 6]} />
        <meshBasicMaterial color={projectile.color} transparent opacity={0.25} />
      </mesh>
      
      {/* Luz otimizada */}
      <pointLight color={projectile.color} intensity={2} distance={4} />
    </group>
  );
}

export function Effects() {
  const { effects, updateEffects } = useGameStore();
  
  useFrame((_, delta) => {
    updateEffects(delta);
  });
  
  // Limitar quantidade de efeitos
  const limitedEffects = effects.slice(0, MAX_EFFECTS);
  
  return (
    <>
      {limitedEffects.map((effect) => (
        <EffectMesh key={effect.id} effect={effect} />
      ))}
    </>
  );
}

function EffectMesh({ effect }: { effect: { type: string; position: { x: number; y: number; z: number }; lifetime: number; color: string; scale?: number } }) {
  const groupRef = useRef<Group>(null);
  const meshRef = useRef<Mesh>(null);
  
  useFrame((state) => {
    if (groupRef.current) {
      if (effect.type.includes('rotating') || effect.type.includes('stars')) {
        groupRef.current.rotation.y += 0.12;
      }
      if (effect.type.includes('expanding') || effect.type.includes('wave') || effect.type.includes('ring')) {
        const expansion = (1 - effect.lifetime) * 1.5;
        groupRef.current.scale.setScalar(1 + expansion);
      }
      if (effect.type.includes('rising') || effect.type.includes('heal')) {
        groupRef.current.position.y = effect.position.y + (1 - effect.lifetime) * 1.2;
      }
    }
    if (meshRef.current) {
      if (effect.type.includes('pulse') || effect.type.includes('aura')) {
        const pulse = 1 + Math.sin(state.clock.elapsedTime * 8) * 0.15;
        meshRef.current.scale.setScalar(pulse);
      }
    }
  });
  
  const baseScale = effect.scale || 1;
  const opacity = Math.min(1, effect.lifetime * 2);
  
  // Renderização simplificada baseada no tipo
  const visual = useMemo(() => {
    const type = effect.type.toLowerCase();
    
    // Impactos e explosões
    if (type.includes('impact') || type.includes('hit') || type.includes('explosion') || type.includes('burst')) {
      return (
        <>
          <mesh scale={baseScale * (1.5 - effect.lifetime)}>
            <sphereGeometry args={[1, 8, 8]} />
            <meshBasicMaterial color={effect.color} transparent opacity={opacity * 0.6} />
          </mesh>
          <mesh scale={baseScale * (2 - effect.lifetime * 1.5)}>
            <ringGeometry args={[0.8, 1, 12]} />
            <meshBasicMaterial color={effect.color} transparent opacity={opacity * 0.4} />
          </mesh>
        </>
      );
    }
    
    // Poças e armadilhas
    if (type.includes('puddle') || type.includes('trap') || type.includes('ink')) {
      return (
        <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.02, 0]}>
          <circleGeometry args={[baseScale, 12]} />
          <meshStandardMaterial 
            color={effect.color}
            emissive={effect.color}
            emissiveIntensity={0.3}
            transparent 
            opacity={opacity * 0.8} 
          />
        </mesh>
      );
    }
    
    // Fumaça e nuvens
    if (type.includes('smoke') || type.includes('dust') || type.includes('cloud')) {
      return (
        <mesh scale={baseScale * (1 + (1 - effect.lifetime) * 0.3)}>
          <sphereGeometry args={[1, 6, 6]} />
          <meshBasicMaterial color={effect.color} transparent opacity={opacity * 0.4} />
        </mesh>
      );
    }
    
    // Flash e brilho
    if (type.includes('flash') || type.includes('glow')) {
      return (
        <mesh scale={baseScale * (2 - effect.lifetime)}>
          <sphereGeometry args={[1, 12, 12]} />
          <meshBasicMaterial color={effect.color} transparent opacity={opacity * 0.7} />
        </mesh>
      );
    }
    
    // Anéis e ondas
    if (type.includes('ring') || type.includes('wave') || type.includes('voice') || type.includes('divine')) {
      const ringScale = baseScale * (1 + (1 - effect.lifetime) * 2);
      return (
        <mesh rotation={[-Math.PI / 2, 0, 0]} scale={ringScale}>
          <ringGeometry args={[0.8, 1, 16]} />
          <meshBasicMaterial color={effect.color} transparent opacity={opacity * 0.6} />
        </mesh>
      );
    }
    
    // Auras
    if (type.includes('aura') || type.includes('charge') || type.includes('stance')) {
      return (
        <mesh ref={meshRef} scale={baseScale}>
          <sphereGeometry args={[1, 12, 12]} />
          <meshBasicMaterial color={effect.color} transparent opacity={opacity * 0.35} />
        </mesh>
      );
    }
    
    // Estrelas de stun
    if (type.includes('star') || type.includes('stun')) {
      return (
        <>
          {[0, 1, 2, 3].map((i) => (
            <mesh key={i} position={[Math.cos(i * 1.57) * 0.4, Math.sin(i * 1.57) * 0.4, 0]} scale={0.15 * baseScale}>
              <octahedronGeometry args={[1]} />
              <meshBasicMaterial color="#FFFF00" transparent opacity={opacity} />
            </mesh>
          ))}
        </>
      );
    }
    
    // Raios
    if (type.includes('lightning') || type.includes('electric') || type.includes('bolt')) {
      return (
        <>
          <mesh scale={[baseScale * 0.2, baseScale * 2.5, baseScale * 0.2]}>
            <cylinderGeometry args={[0.1, 0.1, 1, 6]} />
            <meshBasicMaterial color="#FFFF00" transparent opacity={opacity} />
          </mesh>
          <pointLight color="#FFFF00" intensity={8 * opacity} distance={6} />
        </>
      );
    }
    
    // Cura
    if (type.includes('heal') || type.includes('cross')) {
      return (
        <>
          <mesh scale={baseScale}>
            <boxGeometry args={[0.25, 0.8, 0.25]} />
            <meshBasicMaterial color="#00FF00" transparent opacity={opacity} />
          </mesh>
          <mesh scale={baseScale}>
            <boxGeometry args={[0.8, 0.25, 0.25]} />
            <meshBasicMaterial color="#00FF00" transparent opacity={opacity} />
          </mesh>
        </>
      );
    }
    
    // Velocidade/Trail
    if (type.includes('speed') || type.includes('trail') || type.includes('dash')) {
      return (
        <mesh scale={[baseScale * 0.3, 1, baseScale * 2]}>
          <boxGeometry args={[1, 0.5, 1]} />
          <meshBasicMaterial color={effect.color} transparent opacity={opacity * 0.5} />
        </mesh>
      );
    }
    
    // Texto/indicador (simplificado como esfera)
    if (type.includes('text') || type.includes('indicator')) {
      return (
        <mesh scale={baseScale * 0.5}>
          <sphereGeometry args={[1, 8, 8]} />
          <meshBasicMaterial color={effect.color} transparent opacity={opacity * 0.8} />
        </mesh>
      );
    }
    
    // Default - esfera simples
    return (
      <mesh scale={baseScale * (1.3 - effect.lifetime * 0.3)}>
        <sphereGeometry args={[1, 8, 8]} />
        <meshBasicMaterial color={effect.color} transparent opacity={opacity * 0.6} />
      </mesh>
    );
  }, [effect.type, baseScale, effect.lifetime, effect.color, opacity]);
  
  return (
    <group ref={groupRef} position={[effect.position.x, effect.position.y, effect.position.z]}>
      {visual}
      <pointLight color={effect.color} intensity={2 * opacity} distance={4} />
    </group>
  );
}
