import { useEffect, useState } from 'react';
import { useGameStore, CHARACTERS } from '../store/gameStore';

// Ultimate cutscene data for each character
const ULTIMATE_CUTSCENES: Record<string, {
  name: string;
  phases: {
    duration: number;
    text?: string;
    effect?: 'flash' | 'shake' | 'invert' | 'static' | 'darkness' | 'sepia' | 'cosmic' | 'minecraft' | 'jumpscare' | 'glitch';
    bgColor?: string;
    textColor?: string;
    sound?: string;
  }[];
}> = {
  'ink-demon': {
    name: 'THE CYCLE ENDS',
    phases: [
      { duration: 0.5, effect: 'sepia', text: '...' },
      { duration: 0.8, effect: 'darkness', text: 'THE INK RISES' },
      { duration: 0.6, effect: 'shake', text: '**BEAST BENDY EMERGES**' },
      { duration: 0.8, effect: 'flash', text: '💀 CRUSHED BY THE INK MACHINE 💀', bgColor: '#000' },
    ],
  },
  'vapor': {
    name: 'POV: YOU DIED',
    phases: [
      { duration: 0.4, text: '*footsteps behind you*' },
      { duration: 0.3, text: '...' },
      { duration: 0.2, effect: 'jumpscare', text: '', bgColor: '#ff0000' },
      { duration: 0.5, effect: 'static', text: 'CONNECTION LOST', bgColor: '#000' },
    ],
  },
  'pilgor': {
    name: 'RITUAL OF THE GOAT',
    phases: [
      { duration: 0.5, text: '🐐 *draws pentagram*' },
      { duration: 0.4, effect: 'glitch', text: 'PHYSICS ERROR' },
      { duration: 0.6, effect: 'shake', text: 'GRAVITY.EXE HAS STOPPED WORKING' },
      { duration: 0.5, effect: 'flash', text: '💥 GAME BROKE 💥' },
    ],
  },
  'shrek': {
    name: 'GET OUT OF MY SWAMP!',
    phases: [
      { duration: 0.5, text: '*whistles*', bgColor: '#228B22' },
      { duration: 0.6, text: '🐉 DRAGON INCOMING! 🐉' },
      { duration: 0.5, effect: 'flash', text: '🔥🔥🔥 FIRE BREATH 🔥🔥🔥', bgColor: '#ff4500' },
      { duration: 0.6, effect: 'shake', text: '👊 OGRE PUNCH 👊' },
    ],
  },
  'waluigi': {
    name: 'NEGATIVE ZONE SHOWTIME',
    phases: [
      { duration: 0.5, effect: 'invert', text: '🌹 *roses fall* 🌹' },
      { duration: 0.6, effect: 'invert', text: '*tap dancing intensifies*' },
      { duration: 0.4, text: 'ENEMY BURIED TO WAIST', bgColor: '#4B0082' },
      { duration: 0.7, effect: 'flash', text: '⚽ WAAAAAH! ⚽' },
    ],
  },
  'seiya': {
    name: 'SAGITTARIUS GOLD ARROW',
    phases: [
      { duration: 0.5, effect: 'cosmic', text: '✨ GOLD CLOTH AWAKENS ✨' },
      { duration: 0.6, text: '🏹 *draws golden bow* 🏹', bgColor: '#FFD700' },
      { duration: 0.5, text: 'COSMO BURNS AT MAXIMUM', textColor: '#FFD700' },
      { duration: 0.8, effect: 'flash', text: '☀️ BIG BANG ARROW ☀️' },
    ],
  },
  'man-from-fog': {
    name: 'MIDNIGHT EVENT',
    phases: [
      { duration: 0.4, effect: 'minecraft', text: 'THE SKY DARKENS...' },
      { duration: 0.5, effect: 'darkness', text: '*square moon rises*' },
      { duration: 0.4, effect: 'jumpscare', text: '👁️ 👁️', bgColor: '#000' },
      { duration: 0.5, effect: 'glitch', text: 'MINECRAFT HAS CRASHED' },
    ],
  },
  'dandy': {
    name: 'TWISTED FORM REVEAL',
    phases: [
      { duration: 0.4, text: '*petals wither and fall*' },
      { duration: 0.5, effect: 'darkness', text: 'SOMETHING IS WRONG...' },
      { duration: 0.5, effect: 'glitch', text: '🌸➡️💀 TWISTED DANDY 💀', bgColor: '#8B0000' },
      { duration: 0.6, effect: 'flash', text: '👄 *BITE* 👄' },
    ],
  },
  'yuji': {
    name: 'ZONE: BROTHER\'S MEMORY',
    phases: [
      { duration: 0.5, text: '*reality distorts*', bgColor: '#FF6B6B' },
      { duration: 0.4, effect: 'glitch', text: '"We were... friends?"' },
      { duration: 0.4, effect: 'flash', text: '⚫ BLACK FLASH x1 ⚫' },
      { duration: 0.3, effect: 'flash', text: '⚫ BLACK FLASH x2 ⚫' },
      { duration: 0.3, effect: 'flash', text: '⚫ BLACK FLASH x3 ⚫' },
      { duration: 0.4, effect: 'shake', text: '💥 BLACK FLASH x4 💥' },
    ],
  },
  'harry': {
    name: 'EXPECTO PATRONUM CHARGE',
    phases: [
      { duration: 0.5, effect: 'darkness', text: '*dementors approach*' },
      { duration: 0.5, text: '"EXPECTO PATRONUM!"', bgColor: '#1a1a2e' },
      { duration: 0.6, effect: 'flash', text: '🦌 PRONGS CHARGES 🦌', bgColor: '#ffffff' },
      { duration: 0.5, text: '⚔️ SECTUMSEMPRA ⚔️', bgColor: '#722F37' },
    ],
  },
  'ben10': {
    name: 'ALIEN X: MOTION DENIED',
    phases: [
      { duration: 0.5, effect: 'cosmic', text: '*transforms into Alien X*' },
      { duration: 0.6, effect: 'cosmic', text: '🌌 TIME STOPS 🌌', bgColor: '#000033' },
      { duration: 0.5, text: '*Alien X waves hand*' },
      { duration: 0.8, effect: 'flash', text: '✨ ERASED FROM EXISTENCE ✨' },
    ],
  },
  'tank': {
    name: 'THE HORDE CALLING',
    phases: [
      { duration: 0.5, effect: 'shake', text: '*TANK ROARS*', bgColor: '#8B4513' },
      { duration: 0.6, text: '🧟 ZOMBIES SWARM 🧟' },
      { duration: 0.5, text: '*picks up car*' },
      { duration: 0.8, effect: 'shake', text: '🚗💥 CRUSHED 💥🚗' },
    ],
  },
  'arceus': {
    name: 'JUDGMENT',
    phases: [
      { duration: 0.5, effect: 'cosmic', text: '*ascends to stratosphere*', bgColor: '#FFD700' },
      { duration: 0.6, text: '✨ THE CREATOR JUDGES ✨' },
      { duration: 0.5, effect: 'flash', text: '☀️ DIVINE LIGHT DESCENDS ☀️', bgColor: '#ffffff' },
      { duration: 0.7, effect: 'shake', text: '💀 HP → 1 💀' },
    ],
  },
  'scp4975': {
    name: 'YOUR TIME IS UP',
    phases: [
      { duration: 0.4, effect: 'darkness', text: 'tick... tick... tick...' },
      { duration: 0.4, effect: 'darkness', text: 'TICK TICK TICK TICK' },
      { duration: 0.3, effect: 'shake', text: '*camera spins frantically*' },
      { duration: 0.3, effect: 'jumpscare', text: '🦅', bgColor: '#000' },
      { duration: 0.4, text: '..........', bgColor: '#000' },
    ],
  },
};

export function UltimateCutscene() {
  const { isUltimateActive, ultimateOwner, player1, player2 } = useGameStore();
  const [currentPhase, setCurrentPhase] = useState(0);
  const [phaseProgress, setPhaseProgress] = useState(0);
  
  const player = ultimateOwner === 1 ? player1 : player2;
  const cutscene = player ? ULTIMATE_CUTSCENES[player.characterId] : null;
  const character = player ? CHARACTERS[player.characterId] : null;
  
  useEffect(() => {
    if (!isUltimateActive || !cutscene) {
      setCurrentPhase(0);
      setPhaseProgress(0);
      return;
    }
    
    let elapsed = 0;
    let phaseIndex = 0;
    
    const interval = setInterval(() => {
      elapsed += 0.05;
      
      // Calculate which phase we're in
      let totalTime = 0;
      for (let i = 0; i < cutscene.phases.length; i++) {
        totalTime += cutscene.phases[i].duration;
        if (elapsed < totalTime) {
          phaseIndex = i;
          const phaseStart = totalTime - cutscene.phases[i].duration;
          setPhaseProgress((elapsed - phaseStart) / cutscene.phases[i].duration);
          break;
        }
      }
      
      setCurrentPhase(phaseIndex);
    }, 50);
    
    return () => clearInterval(interval);
  }, [isUltimateActive, cutscene]);
  
  if (!isUltimateActive || !cutscene || !character) return null;
  
  const phase = cutscene.phases[currentPhase];
  
  // Get effect styles
  const getEffectStyles = () => {
    const styles: React.CSSProperties = {
      backgroundColor: phase.bgColor || 'rgba(0,0,0,0.85)',
    };
    
    switch (phase.effect) {
      case 'flash':
        styles.animation = 'flash 0.1s infinite';
        break;
      case 'shake':
        styles.animation = 'shake 0.1s infinite';
        break;
      case 'invert':
        styles.filter = 'invert(1)';
        styles.backgroundColor = '#ffffff';
        break;
      case 'static':
        styles.backgroundImage = 'url("data:image/svg+xml,%3Csvg viewBox=\'0 0 200 200\' xmlns=\'http://www.w3.org/2000/svg\'%3E%3Cfilter id=\'noise\'%3E%3CfeTurbulence type=\'fractalNoise\' baseFrequency=\'0.9\' numOctaves=\'3\' stitchTiles=\'stitch\'/%3E%3C/filter%3E%3Crect width=\'100%25\' height=\'100%25\' filter=\'url(%23noise)\'/%3E%3C/svg%3E")';
        break;
      case 'darkness':
        styles.backgroundColor = '#000000';
        break;
      case 'sepia':
        styles.filter = 'sepia(1)';
        styles.backgroundColor = '#3d3000';
        break;
      case 'cosmic':
        styles.background = 'radial-gradient(ellipse at center, #0a0a2e 0%, #000000 100%)';
        break;
      case 'minecraft':
        styles.backgroundColor = '#1a1a2e';
        styles.backgroundImage = 'linear-gradient(#1a1a2e 50%, #000 50%)';
        styles.backgroundSize = '10px 10px';
        break;
      case 'jumpscare':
        styles.backgroundColor = '#ff0000';
        break;
      case 'glitch':
        styles.animation = 'glitch 0.05s infinite';
        break;
    }
    
    return styles;
  };
  
  return (
    <div 
      className="absolute inset-0 z-[100] flex items-center justify-center overflow-hidden transition-all duration-100"
      style={getEffectStyles()}
    >
      <style>{`
        @keyframes flash {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.3; }
        }
        @keyframes shake {
          0%, 100% { transform: translate(0, 0); }
          25% { transform: translate(-5px, 5px); }
          50% { transform: translate(5px, -5px); }
          75% { transform: translate(-5px, -5px); }
        }
        @keyframes glitch {
          0% { transform: translate(0); filter: hue-rotate(0deg); }
          20% { transform: translate(-5px, 5px); filter: hue-rotate(90deg); }
          40% { transform: translate(5px, -5px); filter: hue-rotate(180deg); }
          60% { transform: translate(-3px, 3px); filter: hue-rotate(270deg); }
          80% { transform: translate(3px, -3px); filter: hue-rotate(360deg); }
          100% { transform: translate(0); }
        }
        @keyframes pulse-glow {
          0%, 100% { text-shadow: 0 0 20px currentColor, 0 0 40px currentColor; }
          50% { text-shadow: 0 0 40px currentColor, 0 0 80px currentColor; }
        }
      `}</style>
      
      {/* Stars for cosmic effect */}
      {phase.effect === 'cosmic' && (
        <div className="absolute inset-0 overflow-hidden">
          {[...Array(50)].map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-white rounded-full animate-pulse"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
              }}
            />
          ))}
        </div>
      )}
      
      {/* Jumpscare face */}
      {phase.effect === 'jumpscare' && (
        <div 
          className="absolute text-[200px] animate-pulse"
          style={{
            textShadow: '0 0 50px #ff0000',
          }}
        >
          {character.id === 'vapor' ? '💀' : 
           character.id === 'man-from-fog' ? '👁️' :
           character.id === 'scp4975' ? '🦅' : '👹'}
        </div>
      )}
      
      {/* Content */}
      <div className="relative z-10 text-center max-w-4xl px-8">
        {/* Ultimate Name */}
        <div 
          className="text-6xl md:text-8xl font-black mb-8 tracking-wider"
          style={{ 
            color: phase.textColor || character.secondaryColor,
            textShadow: `0 0 30px ${character.secondaryColor}, 0 0 60px ${character.secondaryColor}`,
            animation: 'pulse-glow 0.5s infinite',
          }}
        >
          {cutscene.name}
        </div>
        
        {/* Phase Text */}
        {phase.text && (
          <div 
            className="text-3xl md:text-4xl font-bold text-white"
            style={{
              opacity: 0.7 + phaseProgress * 0.3,
              transform: `scale(${0.9 + phaseProgress * 0.1})`,
            }}
          >
            {phase.text}
          </div>
        )}
        
        {/* Character Name */}
        <div className="mt-8 text-2xl text-gray-300">
          {character.name}
        </div>
        
        {/* Progress Bar */}
        <div className="mt-4 w-full max-w-md mx-auto h-1 bg-gray-800 rounded-full overflow-hidden">
          <div 
            className="h-full transition-all duration-100"
            style={{ 
              width: `${((currentPhase + phaseProgress) / cutscene.phases.length) * 100}%`,
              backgroundColor: character.secondaryColor,
            }}
          />
        </div>
      </div>
      
      {/* Energy particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-ping"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              width: `${20 + Math.random() * 40}px`,
              height: `${20 + Math.random() * 40}px`,
              backgroundColor: character.secondaryColor,
              borderRadius: '50%',
              opacity: 0.3,
              animationDelay: `${i * 0.1}s`,
              animationDuration: `${0.5 + Math.random() * 1}s`,
            }}
          />
        ))}
      </div>
    </div>
  );
}
