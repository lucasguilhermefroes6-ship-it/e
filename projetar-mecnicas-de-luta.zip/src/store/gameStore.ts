import { create } from 'zustand';

export type CharacterId = 
  | 'ink-demon' | 'vapor' | 'pilgor' | 'shrek' | 'waluigi' 
  | 'seiya' | 'man-from-fog' | 'dandy' | 'yuji' | 'harry' 
  | 'ben10' | 'tank' | 'arceus' | 'scp4975';

export type GameMode = 'pvp' | 'pve' | '2v2' | 'boss';

export interface SkillEffect {
  type?: string;
  projectileCount?: number;
  projectileSpeed?: number;
  projectileSize?: number;
  aoeRadius?: number;
  duration?: number;
  dotDamage?: number;
  dotDuration?: number;
  stunDuration?: number;
  slowPercent?: number;
  knockbackMultiplier?: number;
  healAmount?: number;
  invisibility?: boolean;
  confuseControls?: boolean;
  ignoreDefense?: boolean;
  multiHit?: number;
  summonCount?: number;
  transformTo?: string;
  blindDuration?: number;
}

export interface CharacterData {
  id: CharacterId;
  name: string;
  style: string;
  color: string;
  secondaryColor: string;
  speed: number;
  weight: number;
  maxHealth: number;
  maxStamina: number;
  maxBlast: number;
  passiveName: string;
  passiveDescription: string;
  skill1Name: string;
  skill1Description: string;
  skill1Cost: number;
  skill1Damage: number;
  skill1Cooldown: number;
  skill1Effect: SkillEffect;
  skill2Name: string;
  skill2Description: string;
  skill2Cost: number;
  skill2Damage: number;
  skill2Cooldown: number;
  skill2Effect: SkillEffect;
  ultimateName: string;
  ultimateDescription: string;
  ultimateDamage: number;
  ultimateEffect: SkillEffect;
  specialName: string;
  specialDescription: string;
  specialDamage: number;
}

export const CHARACTERS: Record<CharacterId, CharacterData> = {
  'ink-demon': {
    id: 'ink-demon',
    name: 'Ink Demon',
    style: 'Assassin/Stealth',
    color: '#1a1a1a',
    secondaryColor: '#FFD700',
    speed: 0.12,
    weight: 1.2,
    maxHealth: 100,
    maxStamina: 100,
    maxBlast: 100,
    passiveName: 'Dissolução em Tinta',
    passiveDescription: 'Pode se dissolver no chão (segurar SHIFT) para ficar invisível e evitar ataques por 3s.',
    skill1Name: 'Ink Flow',
    skill1Description: 'Se dissolve em tinta e desliza rapidamente. Invencível durante o movimento.',
    skill1Cost: 15,
    skill1Damage: 8,
    skill1Cooldown: 1500,
    skill1Effect: { type: 'mobility', invisibility: true, duration: 0.5 },
    skill2Name: 'Searcher Ambush',
    skill2Description: 'Cria uma poça de tinta que prende inimigos.',
    skill2Cost: 30,
    skill2Damage: 12,
    skill2Cooldown: 4000,
    skill2Effect: { type: 'trap', stunDuration: 2, duration: 8 },
    ultimateName: 'The Cycle Ends',
    ultimateDescription: 'Transforma em Beast Bendy e tritura o oponente na máquina de tinta.',
    ultimateDamage: 50,
    ultimateEffect: { type: 'grab', stunDuration: 2 },
    specialName: 'Crescent Cutter',
    specialDescription: 'Lâmina de tinta que atravessa cenário.',
    specialDamage: 25,
  },
  'vapor': {
    id: 'vapor',
    name: 'Vapor',
    style: 'Hit-and-Run',
    color: '#2d2d2d',
    secondaryColor: '#ff0000',
    speed: 0.18,
    weight: 0.8,
    maxHealth: 85,
    maxStamina: 120,
    maxBlast: 100,
    passiveName: 'Forma Intangível',
    passiveDescription: 'A cada 20s, o próximo ataque recebido é ignorado.',
    skill1Name: 'Smoke Cloak',
    skill1Description: 'Libera fumaça densa. Remove lock-on inimigo por 3s.',
    skill1Cost: 15,
    skill1Damage: 0,
    skill1Cooldown: 1200,
    skill1Effect: { type: 'stealth', invisibility: true, duration: 3, blindDuration: 3 },
    skill2Name: 'Skull Barrage',
    skill2Description: '3 crânios espectrais que perseguem o inimigo.',
    skill2Cost: 25,
    skill2Damage: 5,
    skill2Cooldown: 5000,
    skill2Effect: { type: 'summon', summonCount: 3 },
    ultimateName: 'POV: You Died',
    ultimateDescription: 'Jumpscare cinematográfico com visão em primeira pessoa.',
    ultimateDamage: 50,
    ultimateEffect: { type: 'grab', stunDuration: 1.5 },
    specialName: 'Spider Crawl',
    specialDescription: 'Corre em velocidade sobrenatural e morde.',
    specialDamage: 22,
  },
  'pilgor': {
    id: 'pilgor',
    name: 'Pilgor',
    style: 'Joke/Physics',
    color: '#f5f5dc',
    secondaryColor: '#8B4513',
    speed: 0.14,
    weight: 0.6,
    maxHealth: 80,
    maxStamina: 130,
    maxBlast: 100,
    passiveName: 'Ragdoll Physics',
    passiveDescription: 'Quando derrubado, causa dano aleatório em área.',
    skill1Name: 'Lick Grapple',
    skill1Description: 'Língua estica e puxa o inimigo até você.',
    skill1Cost: 12,
    skill1Damage: 10,
    skill1Cooldown: 1000,
    skill1Effect: { type: 'grab', stunDuration: 1.2 },
    skill2Name: 'Headbutt',
    skill2Description: 'Cabeçada com knockback extremo.',
    skill2Cost: 20,
    skill2Damage: 15,
    skill2Cooldown: 2500,
    skill2Effect: { type: 'knockback', knockbackMultiplier: 4 },
    ultimateName: 'Ritual of the Goat',
    ultimateDescription: 'Vira Demon Goat! Física "quebra" e oponente explode.',
    ultimateDamage: 55,
    ultimateEffect: { type: 'transform', knockbackMultiplier: 5 },
    specialName: 'Jetpack Malfunction',
    specialDescription: 'Jetpack ativa e gira descontroladamente.',
    specialDamage: 22,
  },
  'shrek': {
    id: 'shrek',
    name: 'Shrek',
    style: 'Tank/Brawler',
    color: '#7CFC00',
    secondaryColor: '#8B4513',
    speed: 0.09,
    weight: 1.8,
    maxHealth: 150,
    maxStamina: 80,
    maxBlast: 100,
    passiveName: 'Camadas de Cebola',
    passiveDescription: 'Ganha redução de dano (5%/10%/15%) quanto menos HP tiver.',
    skill1Name: 'Do The Roar!',
    skill1Description: 'Grito que atordoa em área e empurra inimigos.',
    skill1Cost: 20,
    skill1Damage: 8,
    skill1Cooldown: 2500,
    skill1Effect: { type: 'aoe', aoeRadius: 5, stunDuration: 1.5 },
    skill2Name: 'Onion Grenade',
    skill2Description: 'Cebola que explode em gás que drena stamina.',
    skill2Cost: 25,
    skill2Damage: 14,
    skill2Cooldown: 3000,
    skill2Effect: { type: 'projectile', aoeRadius: 4, slowPercent: 30 },
    ultimateName: 'Get Out of My Swamp!',
    ultimateDescription: 'Dragão cospe fogo + soco devastador.',
    ultimateDamage: 60,
    ultimateEffect: { type: 'multi', multiHit: 5 },
    specialName: 'Wrestling Slam',
    specialDescription: 'Agarra, gira e joga no chão.',
    specialDamage: 28,
  },
  'waluigi': {
    id: 'waluigi',
    name: 'Waluigi',
    style: 'Technical/Trickster',
    color: '#4B0082',
    secondaryColor: '#FFD700',
    speed: 0.15,
    weight: 1.0,
    maxHealth: 95,
    maxStamina: 110,
    maxBlast: 100,
    passiveName: 'Número 1 Injustiçado',
    passiveDescription: 'Após 3 hits seguidos, ganha contra-ataque automático grátis.',
    skill1Name: 'Technical Return',
    skill1Description: 'Rebate projéteis com 2x dano. Contra melee = golpe rápido.',
    skill1Cost: 15,
    skill1Damage: 7,
    skill1Cooldown: 800,
    skill1Effect: { type: 'reflect' },
    skill2Name: 'Rose Whip',
    skill2Description: 'Chicote de rosas com espinhos. Múltiplos hits.',
    skill2Cost: 22,
    skill2Damage: 3,
    skill2Cooldown: 2000,
    skill2Effect: { type: 'multi', multiHit: 5, stunDuration: 1 },
    ultimateName: 'Negative Zone Showtime',
    ultimateDescription: 'Cores invertem, dança sapateado, chute flamejante.',
    ultimateDamage: 40,
    ultimateEffect: { type: 'debuff', confuseControls: true, duration: 4, stunDuration: 1 },
    specialName: 'Bob-omb Serve',
    specialDescription: 'Saca uma bomba que quica.',
    specialDamage: 24,
  },
  'seiya': {
    id: 'seiya',
    name: 'Seiya de Pégaso',
    style: 'Rushdown',
    color: '#C0C0C0',
    secondaryColor: '#FFD700',
    speed: 0.22,
    weight: 0.9,
    maxHealth: 90,
    maxStamina: 100,
    maxBlast: 100,
    passiveName: 'Cosmo Ardente',
    passiveDescription: 'Combos 5+ hits = +2% dano por hit adicional.',
    skill1Name: 'Pegasus Rolling Crush',
    skill1Description: 'Agarra no ar, gira e cai de cabeça no chão.',
    skill1Cost: 18,
    skill1Damage: 18,
    skill1Cooldown: 1500,
    skill1Effect: { type: 'grab', stunDuration: 0.8 },
    skill2Name: 'Pegasus Meteor Fist',
    skill2Description: 'Centenas de projéteis de luz em rajada.',
    skill2Cost: 30,
    skill2Damage: 1,
    skill2Cooldown: 2500,
    skill2Effect: { type: 'multi', multiHit: 30, projectileSpeed: 30 },
    ultimateName: 'Sagittarius Gold Arrow',
    ultimateDescription: 'Armadura de Ouro de Sagitário + Flecha Dourada.',
    ultimateDamage: 65,
    ultimateEffect: { type: 'transform', duration: 3 },
    specialName: 'Pegasus Comet Fist',
    specialDescription: 'Meteoros concentrados em um só ponto.',
    specialDamage: 30,
  },
  'man-from-fog': {
    id: 'man-from-fog',
    name: 'Man From The Fog',
    style: 'Horror',
    color: '#1a1a2e',
    secondaryColor: '#ff0000',
    speed: 0.16,
    weight: 1.1,
    maxHealth: 100,
    maxStamina: 100,
    maxBlast: 100,
    passiveName: 'Tick-Tock',
    passiveDescription: 'Som de relógio aumenta perto do inimigo. -10% dano recebido.',
    skill1Name: 'Glitch Stalk',
    skill1Description: 'Teleporta atrás do oponente com efeito de glitch.',
    skill1Cost: 15,
    skill1Damage: 8,
    skill1Cooldown: 1500,
    skill1Effect: { type: 'teleport' },
    skill2Name: 'Lightning Smite',
    skill2Description: 'Raio do céu. Impossível bloquear, apenas esquivar.',
    skill2Cost: 25,
    skill2Damage: 20,
    skill2Cooldown: 5000,
    skill2Effect: { type: 'aoe', ignoreDefense: true },
    ultimateName: 'Midnight Event',
    ultimateDescription: 'Céu vira noite, olhos brilham, jumpscare de crash.',
    ultimateDamage: 55,
    ultimateEffect: { type: 'multi', multiHit: 8, stunDuration: 2 },
    specialName: 'Fear Aura',
    specialDescription: 'Grito que reduz velocidade do oponente.',
    specialDamage: 15,
  },
  'dandy': {
    id: 'dandy',
    name: 'Dandy',
    style: 'Item User/RNG',
    color: '#FF69B4',
    secondaryColor: '#4169E1',
    speed: 0.13,
    weight: 1.0,
    maxHealth: 95,
    maxStamina: 105,
    maxBlast: 100,
    passiveName: 'Loja Ambulante',
    passiveDescription: 'A cada 15s ganha item aleatório (máx 3).',
    skill1Name: 'Random Stock',
    skill1Description: 'Item aleatório: Medkit, Bomba, Fita, Banana ou Nada.',
    skill1Cost: 10,
    skill1Damage: 12,
    skill1Cooldown: 2000,
    skill1Effect: { type: 'random' },
    skill2Name: 'Tape Restraint',
    skill2Description: '3 armadilhas invisíveis de fita adesiva.',
    skill2Cost: 28,
    skill2Damage: 8,
    skill2Cooldown: 4000,
    skill2Effect: { type: 'trap', summonCount: 3, stunDuration: 1.8 },
    ultimateName: 'Twisted Form Reveal',
    ultimateDescription: 'Transforma em Twisted Dandy monstruoso.',
    ultimateDamage: 45,
    ultimateEffect: { type: 'transform', healAmount: 20, duration: 5 },
    specialName: 'Ichor Spill',
    specialDescription: 'Balde de líquido preto que causa dano contínuo.',
    specialDamage: 20,
  },
  'yuji': {
    id: 'yuji',
    name: 'Yuji Itadori',
    style: 'Striker',
    color: '#FF6B6B',
    secondaryColor: '#1a1a1a',
    speed: 0.19,
    weight: 1.0,
    maxHealth: 100,
    maxStamina: 110,
    maxBlast: 100,
    passiveName: 'Força Sobre-Humana',
    passiveDescription: 'Ataques básicos têm 15% chance de knockdown.',
    skill1Name: 'Manji Kick',
    skill1Description: 'Postura defensiva. Se atacado, contra-ataca.',
    skill1Cost: 15,
    skill1Damage: 18,
    skill1Cooldown: 1200,
    skill1Effect: { type: 'counter' },
    skill2Name: 'Divergent Fist',
    skill2Description: 'Soco com impacto atrasado. Dano duplo!',
    skill2Cost: 22,
    skill2Damage: 8,
    skill2Cooldown: 2500,
    skill2Effect: { type: 'multi', multiHit: 2 },
    ultimateName: 'Zone: Brothers Memory',
    ultimateDescription: '4 Black Flashes consecutivos com distorção espacial.',
    ultimateDamage: 70,
    ultimateEffect: { type: 'multi', multiHit: 4 },
    specialName: 'Black Flash',
    specialDescription: 'Soco com faíscas pretas e vermelhas.',
    specialDamage: 28,
  },
  'harry': {
    id: 'harry',
    name: 'Harry Potter',
    style: 'Zoner',
    color: '#722F37',
    secondaryColor: '#FFD700',
    speed: 0.14,
    weight: 0.9,
    maxHealth: 85,
    maxStamina: 120,
    maxBlast: 100,
    passiveName: 'Voo de Vassoura',
    passiveDescription: 'Firebolt para mobilidade extrema.',
    skill1Name: 'Expelliarmus',
    skill1Description: 'Cancela ataques do oponente e causa knockback.',
    skill1Cost: 12,
    skill1Damage: 5,
    skill1Cooldown: 1000,
    skill1Effect: { type: 'reflect' },
    skill2Name: 'Stupefy + Incendio',
    skill2Description: 'Combo: atordoa e depois queima.',
    skill2Cost: 25,
    skill2Damage: 18,
    skill2Cooldown: 2500,
    skill2Effect: { type: 'multi', multiHit: 2, stunDuration: 1, aoeRadius: 3 },
    ultimateName: 'Expecto Patronum Charge',
    ultimateDescription: 'Cervo patrono atropela + luz cegante.',
    ultimateDamage: 55,
    ultimateEffect: { type: 'summon', summonCount: 1, knockbackMultiplier: 3 },
    specialName: 'Confringo',
    specialDescription: 'Feitiço explosivo que joga para cima.',
    specialDamage: 25,
  },
  'ben10': {
    id: 'ben10',
    name: 'Ben 10',
    style: 'Stance Switcher',
    color: '#00FF00',
    secondaryColor: '#1a1a1a',
    speed: 0.15,
    weight: 1.0,
    maxHealth: 100,
    maxStamina: 100,
    maxBlast: 100,
    passiveName: 'Omnitrix',
    passiveDescription: 'Troca entre formas alienígenas.',
    skill1Name: 'XLR8 Dash',
    skill1Description: 'Transforma em XLR8, corre através do inimigo.',
    skill1Cost: 18,
    skill1Damage: 12,
    skill1Cooldown: 1500,
    skill1Effect: { type: 'transform', transformTo: 'xlr8', multiHit: 5 },
    skill2Name: 'Four Arms Smash',
    skill2Description: 'Transforma em Quatro Braços, smash devastador.',
    skill2Cost: 28,
    skill2Damage: 28,
    skill2Cooldown: 3500,
    skill2Effect: { type: 'transform', transformTo: 'fourarms', knockbackMultiplier: 2 },
    ultimateName: 'Alien X: Motion Denied',
    ultimateDescription: 'Alien X apaga a existência do inimigo.',
    ultimateDamage: 80,
    ultimateEffect: { type: 'transform', transformTo: 'alienx', duration: 3 },
    specialName: 'Diamondhead Shield',
    specialDescription: 'Parede de espinhos de cristal.',
    specialDamage: 26,
  },
  'tank': {
    id: 'tank',
    name: 'Tank',
    style: 'Juggernaut',
    color: '#8B4513',
    secondaryColor: '#696969',
    speed: 0.08,
    weight: 2.5,
    maxHealth: 180,
    maxStamina: 70,
    maxBlast: 100,
    passiveName: 'Super Armadura',
    passiveDescription: 'Não pode ser interrompido. Imune a stun e knockback leve.',
    skill1Name: 'Concrete Rip',
    skill1Description: 'Arranca concreto e arremessa. Não pode ser bloqueado.',
    skill1Cost: 15,
    skill1Damage: 18,
    skill1Cooldown: 2000,
    skill1Effect: { type: 'projectile', projectileSize: 2, knockbackMultiplier: 2.5, ignoreDefense: true },
    skill2Name: 'Bull Rush',
    skill2Description: 'Investida imparável que esmaga na parede.',
    skill2Cost: 30,
    skill2Damage: 28,
    skill2Cooldown: 4000,
    skill2Effect: { type: 'charge', aoeRadius: 3 },
    ultimateName: 'The Horde Calling',
    ultimateDescription: 'Zumbis seguram, Tank esmaga com carro.',
    ultimateDamage: 65,
    ultimateEffect: { type: 'summon', summonCount: 5, stunDuration: 2 },
    specialName: 'Ground Pound',
    specialDescription: 'Soco no chão com onda sísmica.',
    specialDamage: 30,
  },
  'arceus': {
    id: 'arceus',
    name: 'Arceus',
    style: 'Boss/Zoner',
    color: '#FFFFFF',
    secondaryColor: '#FFD700',
    speed: 0.12,
    weight: 1.5,
    maxHealth: 130,
    maxStamina: 90,
    maxBlast: 100,
    passiveName: 'Criador',
    passiveDescription: 'Imune a efeitos de controle por mais de 1s.',
    skill1Name: 'Plate Change',
    skill1Description: 'Muda de tipo e ganha resistência ao último dano.',
    skill1Cost: 20,
    skill1Damage: 0,
    skill1Cooldown: 2500,
    skill1Effect: { type: 'buff', duration: 10 },
    skill2Name: 'Hyper Voice',
    skill2Description: 'Onda de som que reflete projéteis e empurra.',
    skill2Cost: 15,
    skill2Damage: 10,
    skill2Cooldown: 3000,
    skill2Effect: { type: 'aoe', aoeRadius: 6 },
    ultimateName: 'Judgment',
    ultimateDescription: 'Feixe de luz colossal do céu.',
    ultimateDamage: 70,
    ultimateEffect: { type: 'aoe', aoeRadius: 8 },
    specialName: 'Draco Meteor',
    specialDescription: 'Meteoros caem aleatoriamente na arena.',
    specialDamage: 32,
  },
  'scp4975': {
    id: 'scp4975',
    name: 'SCP-4975',
    style: 'Assassin',
    color: '#2F4F4F',
    secondaryColor: '#FF4500',
    speed: 0.17,
    weight: 1.1,
    maxHealth: 95,
    maxStamina: 105,
    maxBlast: 100,
    passiveName: "Time's Up",
    passiveDescription: 'A cada 10s perto do inimigo, +10% dano no próximo ataque.',
    skill1Name: 'Temporal Camouflage',
    skill1Description: '90% invisível. Próximo ataque = dano crítico.',
    skill1Cost: 12,
    skill1Damage: 0,
    skill1Cooldown: 900,
    skill1Effect: { type: 'buff', invisibility: true, duration: 10 },
    skill2Name: 'Beak Pierce',
    skill2Description: 'Bicada rápida que ignora defesa e causa sangramento.',
    skill2Cost: 25,
    skill2Damage: 15,
    skill2Cooldown: 5000,
    skill2Effect: { type: 'projectile', ignoreDefense: true, dotDamage: 3, dotDuration: 4 },
    ultimateName: 'Your Time is Up',
    ultimateDescription: 'Tick-tock ensurdecedor, ataque fatal no pescoço.',
    ultimateDamage: 58,
    ultimateEffect: { type: 'grab', stunDuration: 3 },
    specialName: 'Paralysis Click',
    specialDescription: 'Estala o pescoço, inimigo trava de medo.',
    specialDamage: 20,
  },
};

// Boss data - versões gigantes e fortes de alguns personagens
export interface BossData extends CharacterData {
  bossName: string;
  bossDescription: string;
  healthMultiplier: number;
  damageMultiplier: number;
  sizeMultiplier: number;
  phases: number;
  specialMechanics: string[];
}

export const BOSSES: Record<string, BossData> = {
  'arceus-boss': {
    ...CHARACTERS['arceus'],
    id: 'arceus',
    bossName: 'ARCEUS - O CRIADOR',
    bossDescription: 'O Deus Pokémon em sua forma verdadeira. Controla todas as dimensões.',
    healthMultiplier: 5,
    damageMultiplier: 1.5,
    sizeMultiplier: 2.5,
    phases: 3,
    specialMechanics: ['Troca de tipo a cada fase', 'Cura parcial entre fases', 'Judgment em área total na fase 3'],
  },
  'tank-boss': {
    ...CHARACTERS['tank'],
    id: 'tank',
    bossName: 'MEGA TANK',
    bossDescription: 'O Tank mais poderoso já visto. Lidera um exército de infectados.',
    healthMultiplier: 6,
    damageMultiplier: 2,
    sizeMultiplier: 2,
    phases: 2,
    specialMechanics: ['Invoca hordas constantemente', 'Arremessa carros em vez de pedras', 'Rage mode abaixo de 30% HP'],
  },
  'ink-demon-boss': {
    ...CHARACTERS['ink-demon'],
    id: 'ink-demon',
    bossName: 'BEAST BENDY',
    bossDescription: 'A forma final do Ink Demon. O estúdio inteiro é seu território.',
    healthMultiplier: 4,
    damageMultiplier: 1.8,
    sizeMultiplier: 3,
    phases: 3,
    specialMechanics: ['Arena fica coberta de tinta', 'Searchers infinitos na fase 2', 'Teleporte constante na fase 3'],
  },
};

// Player state interface - agora suporta até 4 jogadores
export interface Player {
  id: 1 | 2 | 3 | 4;
  team: 1 | 2; // Para modo 2v2
  characterId: CharacterId;
  health: number;
  stamina: number;
  blast: number;
  specialBar: number;
  position: { x: number; y: number; z: number };
  rotation: number;
  velocity: { x: number; y: number; z: number };
  isGrounded: boolean;
  isBlocking: boolean;
  isAttacking: boolean;
  currentAnimation: string;
  cooldowns: { skill1: number; skill2: number; ultimate: number };
  comboCount: number;
  punchComboTimer: number;
  stunned: number;
  isInvincible: boolean;
  isInvisible: boolean;
  isConfused: boolean;
  confusedTimer: number;
  blindTimer: number;
  slowTimer: number;
  damageBoost: number;
  damageBoostTimer: number;
  superArmor: boolean;
  passiveTimer: number;
  passiveStacks: number;
  consecutiveHits: number;
  currentForm: string;
  formTimer: number;
  isAlive: boolean; // Para modos com múltiplos jogadores
  isAI: boolean; // Para controle por IA
  isGrabbed: boolean; // Quando está sendo agarrado por um ataque
  isRagdoll: boolean; // Quando está no estado ragdoll (ex: puxado pela língua do Pilgor)
  ragdollTimer: number; // Timer para o ragdoll acabar
}

// Projectile interface
interface Projectile {
  id: string;
  owner: 1 | 2 | 3 | 4;
  team?: 1 | 2;
  position: { x: number; y: number; z: number };
  velocity: { x: number; y: number; z: number };
  damage: number;
  lifetime: number;
  color: string;
  size: number;
  effect?: SkillEffect;
  isHoming?: boolean;
  targetId?: 1 | 2 | 3 | 4;
  skillType?: string;
  visualType?: 'default' | 'ink' | 'fire' | 'ice' | 'electric' | 'magic' | 'cosmic' | 'dark' | 'holy';
}

// Effect interface
interface Effect {
  id: string;
  type: string;
  position: { x: number; y: number; z: number };
  lifetime: number;
  color: string;
  scale?: number;
  particleCount?: number;
  effectStyle?: string;
}

// Summon interface
interface Summon {
  id: string;
  owner: 1 | 2 | 3 | 4;
  team?: 1 | 2;
  type: string;
  position: { x: number; y: number; z: number };
  targetId: 1 | 2 | 3 | 4;
  damage: number;
  lifetime: number;
  speed: number;
  behavior?: 'chase' | 'orbit' | 'trap' | 'shoot' | 'guard';
}

// Boss state
interface BossState {
  currentBoss: string | null;
  currentPhase: number;
  maxPhases: number;
  phaseHealth: number[];
  enraged: boolean;
  specialAttackTimer: number;
  mechanicTimer: number;
}

type GameState = 'menu' | 'character-select' | 'fighting' | 'paused' | 'round-end' | 'game-over';

interface AIState {
  lastAction: number;
  actionCooldown: number;
  targetPosition: { x: number; z: number };
  aggression: number;
  currentBehavior: 'attack' | 'defend' | 'chase' | 'retreat' | 'skill';
  targetPlayerId: 1 | 2 | 3 | 4;
}

interface GameStore {
  gameState: GameState;
  gameMode: GameMode;
  setGameState: (state: GameState) => void;
  setGameMode: (mode: GameMode) => void;
  
  // Suporte a 4 jogadores
  player1: Player;
  player2: Player;
  player3: Player | null;
  player4: Player | null;
  updatePlayer: (id: 1 | 2 | 3 | 4, updates: Partial<Player>) => void;
  getActivePlayers: () => Player[];
  getEnemyPlayers: (playerId: 1 | 2 | 3 | 4) => Player[];
  
  // Boss state
  bossState: BossState;
  setBossState: (updates: Partial<BossState>) => void;
  
  projectiles: Projectile[];
  addProjectile: (projectile: Omit<Projectile, 'id'>) => void;
  removeProjectile: (id: string) => void;
  updateProjectiles: (delta: number) => void;
  
  effects: Effect[];
  addEffect: (effect: Omit<Effect, 'id'>) => void;
  updateEffects: (delta: number) => void;
  
  summons: Summon[];
  addSummon: (summon: Omit<Summon, 'id'>) => void;
  removeSummon: (id: string) => void;
  updateSummons: (delta: number) => void;
  
  round: number;
  team1Wins: number;
  team2Wins: number;
  roundTime: number;
  maxRounds: number;
  
  startGame: () => void;
  selectCharacter: (player: 1 | 2 | 3 | 4, characterId: CharacterId) => void;
  startRound: () => void;
  endRound: (winner: 1 | 2 | 'draw') => void;
  resetGame: () => void;
  
  // Boss mode
  selectedBoss: string | null;
  setSelectedBoss: (bossId: string | null) => void;
  startBossFight: () => void;
  
  keys: Record<string, boolean>;
  setKey: (key: string, pressed: boolean) => void;
  mouseDown: boolean;
  setMouseDown: (down: boolean) => void;
  
  isUltimateActive: boolean;
  ultimateOwner: 1 | 2 | 3 | 4 | null;
  setUltimateActive: (active: boolean, owner?: 1 | 2 | 3 | 4) => void;
  
  cameraShake: number;
  setCameraShake: (intensity: number) => void;
  
  timeScale: number;
  setTimeScale: (scale: number) => void;
  
  // AI State - agora suporta múltiplos AIs
  aiStates: Record<number, AIState>;
  updateAI: (playerId: 2 | 3 | 4, delta: number) => void;
  updateAllAI: (delta: number) => void;
}

const createDefaultPlayer = (id: 1 | 2 | 3 | 4, characterId: CharacterId, team: 1 | 2, isAI: boolean = false): Player => {
  const positions: Record<number, { x: number; z: number; rotation: number }> = {
    1: { x: -5, z: -3, rotation: 0 },
    2: { x: 5, z: -3, rotation: Math.PI },
    3: { x: -5, z: 3, rotation: 0 },
    4: { x: 5, z: 3, rotation: Math.PI },
  };
  
  const pos = positions[id];
  
  return {
    id,
    team,
    characterId,
    health: CHARACTERS[characterId].maxHealth,
    stamina: CHARACTERS[characterId].maxStamina,
    blast: 0,
    specialBar: 0,
    position: { x: pos.x, y: 0, z: pos.z },
    rotation: pos.rotation,
    velocity: { x: 0, y: 0, z: 0 },
    isGrounded: true,
    isBlocking: false,
    isAttacking: false,
    currentAnimation: 'idle',
    cooldowns: { skill1: 0, skill2: 0, ultimate: 0 },
    comboCount: 0,
    punchComboTimer: 0,
    stunned: 0,
    isInvincible: false,
    isInvisible: false,
    isConfused: false,
    confusedTimer: 0,
    blindTimer: 0,
    slowTimer: 0,
    damageBoost: 0,
    damageBoostTimer: 0,
    superArmor: CHARACTERS[characterId].id === 'tank',
    passiveTimer: 0,
    passiveStacks: 0,
    consecutiveHits: 0,
    currentForm: 'base',
    formTimer: 0,
    isAlive: true,
    isAI,
    isGrabbed: false,
    isRagdoll: false,
    ragdollTimer: 0,
  };
};

const createDefaultAIState = (targetId: 1 | 2 | 3 | 4): AIState => ({
  lastAction: Date.now(),
  actionCooldown: 0.2 + Math.random() * 0.3, // Pequeno cooldown inicial para stagger
  targetPosition: { x: 0, z: 0 },
  aggression: 0.5 + Math.random() * 0.4,
  currentBehavior: 'chase',
  targetPlayerId: targetId,
});

export const useGameStore = create<GameStore>((set, get) => ({
  gameState: 'menu',
  gameMode: 'pvp',
  setGameState: (state) => set({ gameState: state }),
  setGameMode: (mode) => set({ gameMode: mode }),
  
  player1: createDefaultPlayer(1, 'seiya', 1, false),
  player2: createDefaultPlayer(2, 'shrek', 2, false),
  player3: null,
  player4: null,
  
  updatePlayer: (id, updates) => set((state) => {
    // Limitar stun máximo para evitar stun infinito
    const MAX_STUN = 2.0; // Máximo 2 segundos de stun
    if (updates.stunned !== undefined) {
      updates.stunned = Math.min(updates.stunned, MAX_STUN);
    }
    
    // Limitar slowTimer máximo
    const MAX_SLOW = 3.0;
    if (updates.slowTimer !== undefined) {
      updates.slowTimer = Math.min(updates.slowTimer, MAX_SLOW);
    }
    
    // Limitar blindTimer máximo
    const MAX_BLIND = 3.0;
    if (updates.blindTimer !== undefined) {
      updates.blindTimer = Math.min(updates.blindTimer, MAX_BLIND);
    }
    
    if (id === 1) return { player1: { ...state.player1, ...updates } };
    if (id === 2) return { player2: { ...state.player2, ...updates } };
    if (id === 3 && state.player3) return { player3: { ...state.player3, ...updates } };
    if (id === 4 && state.player4) return { player4: { ...state.player4, ...updates } };
    return {};
  }),
  
  getActivePlayers: () => {
    const state = get();
    const players: Player[] = [state.player1, state.player2];
    if (state.player3) players.push(state.player3);
    if (state.player4) players.push(state.player4);
    return players.filter(p => p.isAlive);
  },
  
  getEnemyPlayers: (playerId) => {
    const state = get();
    const player = playerId === 1 ? state.player1 : 
                   playerId === 2 ? state.player2 :
                   playerId === 3 ? state.player3 :
                   state.player4;
    if (!player) return [];
    
    const allPlayers = state.getActivePlayers();
    return allPlayers.filter(p => p.team !== player.team && p.isAlive);
  },
  
  bossState: {
    currentBoss: null,
    currentPhase: 1,
    maxPhases: 3,
    phaseHealth: [100, 100, 100],
    enraged: false,
    specialAttackTimer: 0,
    mechanicTimer: 0,
  },
  
  setBossState: (updates) => set((state) => ({
    bossState: { ...state.bossState, ...updates },
  })),
  
  projectiles: [],
  addProjectile: (projectile) => set((state) => {
    const newProjectiles = [...state.projectiles, { ...projectile, id: `proj-${Date.now()}-${Math.random()}` }];
    return { projectiles: newProjectiles.slice(-30) };
  }),
  removeProjectile: (id) => set((state) => ({
    projectiles: state.projectiles.filter((p) => p.id !== id),
  })),
  updateProjectiles: (delta) => set((state) => ({
    projectiles: state.projectiles
      .map((p) => {
        let newPos = {
          x: p.position.x + p.velocity.x * delta,
          y: p.position.y + p.velocity.y * delta,
          z: p.position.z + p.velocity.z * delta,
        };
        
        // Homing projectiles - apenas seguir alvos vivos
        if (p.isHoming && p.targetId) {
          const target = p.targetId === 1 ? state.player1 : 
                         p.targetId === 2 ? state.player2 :
                         p.targetId === 3 ? state.player3 :
                         state.player4;
          if (target && target.isAlive && target.health > 0) {
            const dx = target.position.x - p.position.x;
            const dy = (target.position.y + 1) - p.position.y;
            const dz = target.position.z - p.position.z;
            const dist = Math.sqrt(dx*dx + dy*dy + dz*dz);
            if (dist > 0.1) {
              const speed = Math.sqrt(p.velocity.x**2 + p.velocity.y**2 + p.velocity.z**2);
              p.velocity.x = (dx/dist) * speed;
              p.velocity.y = (dy/dist) * speed;
              p.velocity.z = (dz/dist) * speed;
            }
          }
        }
        
        return {
          ...p,
          position: newPos,
          lifetime: p.lifetime - delta,
        };
      })
      .filter((p) => p.lifetime > 0 && Math.abs(p.position.x) < 35 && Math.abs(p.position.z) < 35),
  })),
  
  effects: [],
  addEffect: (effect) => set((state) => {
    const newEffects = [...state.effects, { ...effect, id: `effect-${Date.now()}-${Math.random()}` }];
    return { effects: newEffects.slice(-40) };
  }),
  updateEffects: (delta) => set((state) => ({
    effects: state.effects
      .map((e) => ({ ...e, lifetime: e.lifetime - delta }))
      .filter((e) => e.lifetime > 0),
  })),
  
  summons: [],
  addSummon: (summon) => set((state) => {
    const newSummons = [...state.summons, { ...summon, id: `summon-${Date.now()}-${Math.random()}` }];
    return { summons: newSummons.slice(-15) };
  }),
  removeSummon: (id) => set((state) => ({
    summons: state.summons.filter((s) => s.id !== id),
  })),
  updateSummons: (delta) => set((state) => {
    const newSummons: Summon[] = [];
    
    for (const s of state.summons) {
      const target = s.targetId === 1 ? state.player1 : 
                     s.targetId === 2 ? state.player2 :
                     s.targetId === 3 ? state.player3 :
                     state.player4;
      
      if (!target) continue;
      
      // Não atacar alvos mortos
      if (!target.isAlive || target.health <= 0) continue;
      
      const dx = target.position.x - s.position.x;
      const dz = target.position.z - s.position.z;
      const dist = Math.sqrt(dx*dx + dz*dz);
      
      if (s.behavior === 'trap' || s.speed === 0) {
        if (dist < 2.5) {
          setTimeout(() => {
            const currentState = useGameStore.getState();
            const currentTarget = currentState[`player${s.targetId}` as keyof typeof currentState] as Player | null;
            if (currentTarget && currentTarget.isAlive) {
              currentState.updatePlayer(s.targetId, {
                health: Math.max(0, currentTarget.health - s.damage),
                stunned: Math.min(1.0, (currentTarget.stunned || 0) + 1.0), // Máximo 1s
                slowTimer: 1.5,
              });
            }
            currentState.addEffect({
              type: 'trap-activate',
              position: { x: s.position.x, y: 0.5, z: s.position.z },
              lifetime: 0.6,
              color: '#ff0000',
              scale: 3,
            });
            currentState.setCameraShake(0.5);
          }, 0);
          continue;
        }
        newSummons.push({ ...s, lifetime: s.lifetime - delta });
      } else {
        if (dist < 1.5) {
          setTimeout(() => {
            const currentState = useGameStore.getState();
            const currentTarget = currentState[`player${s.targetId}` as keyof typeof currentState] as Player | null;
            if (currentTarget && currentTarget.isAlive) {
              currentState.updatePlayer(s.targetId, {
                health: Math.max(0, currentTarget.health - s.damage),
                stunned: Math.min(0.5, (currentTarget.stunned || 0) + 0.3), // Máximo 0.5s
              });
            }
            currentState.addEffect({
              type: 'summon-hit',
              position: { x: s.position.x, y: 1, z: s.position.z },
              lifetime: 0.4,
              color: '#ff0000',
              scale: 1.5,
            });
          }, 0);
          continue;
        }
        
        const newPos = {
          x: s.position.x + (dx/dist) * s.speed * delta,
          y: 0.5,
          z: s.position.z + (dz/dist) * s.speed * delta,
        };
        
        newSummons.push({
          ...s,
          position: newPos,
          lifetime: s.lifetime - delta,
        });
      }
    }
    
    return { summons: newSummons.filter((s) => s.lifetime > 0) };
  }),
  
  round: 1,
  team1Wins: 0,
  team2Wins: 0,
  roundTime: 99,
  maxRounds: 3,
  
  startGame: () => set({ gameState: 'character-select' }),
  
  selectCharacter: (player, characterId) => {
    const state = get();
    const team = player <= 2 ? (player === 1 ? 1 : 2) : (player === 3 ? 1 : 2);
    const isAI = state.gameMode === 'pve' && player >= 2;
    const newPlayer = createDefaultPlayer(player, characterId, team, isAI);
    
    if (player === 1) set({ player1: newPlayer });
    else if (player === 2) set({ player2: newPlayer });
    else if (player === 3) set({ player3: newPlayer });
    else if (player === 4) set({ player4: newPlayer });
  },
  
  startRound: () => {
    const state = get();
    const mode = state.gameMode;
    
    // P1 é sempre controlado pelo jogador humano
    let p1 = createDefaultPlayer(1, state.player1.characterId, 1, false);
    
    // P2 é AI em todos os modos exceto PvP
    const p2IsAI = mode === 'pve' || mode === 'boss' || mode === '2v2';
    let p2 = createDefaultPlayer(2, state.player2.characterId, 2, p2IsAI);
    
    let p3: Player | null = null;
    let p4: Player | null = null;
    
    if (mode === '2v2') {
      // No modo 2v2: P1 e P3 são Time 1, P2 e P4 são Time 2
      // P3 é AI aliada, P4 é AI inimiga
      p3 = createDefaultPlayer(3, state.player3?.characterId || 'yuji', 1, true);
      p4 = createDefaultPlayer(4, state.player4?.characterId || 'harry', 2, true);
    }
    
    if (mode === 'boss' && state.selectedBoss) {
      const boss = BOSSES[state.selectedBoss];
      if (boss) {
        p2 = {
          ...createDefaultPlayer(2, boss.id, 2, true),
          health: boss.maxHealth * boss.healthMultiplier,
          damageBoost: (boss.damageMultiplier - 1) * 100,
        };
      }
    }
    
    // Configurar AI states para todos os jogadores controlados por IA
    const newAIStates: Record<number, AIState> = {};
    
    // P2 AI sempre ataca P1 (o jogador)
    if (p2.isAI) {
      newAIStates[2] = createDefaultAIState(1);
      console.log('P2 AI criada - modo:', mode);
    }
    
    // P3 AI (aliada) ataca inimigos do time 2 (começa com P2)
    if (p3?.isAI) {
      newAIStates[3] = createDefaultAIState(2);
      console.log('P3 AI criada');
    }
    
    // P4 AI (inimiga) ataca aliados do time 1 (começa com P1)
    if (p4?.isAI) {
      newAIStates[4] = createDefaultAIState(1);
      console.log('P4 AI criada');
    }
    
    set({
      gameState: 'fighting',
      roundTime: 99,
      player1: p1,
      player2: p2,
      player3: p3,
      player4: p4,
      projectiles: [],
      effects: [],
      summons: [],
      aiStates: newAIStates,
    });
  },
  
  endRound: (winner) => {
    const { round, maxRounds, team1Wins, team2Wins } = get();
    
    let newT1Wins = team1Wins;
    let newT2Wins = team2Wins;
    
    if (winner === 1) newT1Wins++;
    else if (winner === 2) newT2Wins++;
    
    const winsNeeded = Math.ceil(maxRounds / 2);
    
    if (newT1Wins >= winsNeeded || newT2Wins >= winsNeeded) {
      set({ gameState: 'game-over', team1Wins: newT1Wins, team2Wins: newT2Wins });
    } else {
      set({ 
        gameState: 'round-end', 
        round: round + 1,
        team1Wins: newT1Wins,
        team2Wins: newT2Wins,
      });
    }
  },
  
  resetGame: () => set({
    gameState: 'menu',
    round: 1,
    team1Wins: 0,
    team2Wins: 0,
    player1: createDefaultPlayer(1, 'seiya', 1, false),
    player2: createDefaultPlayer(2, 'shrek', 2, false),
    player3: null,
    player4: null,
    projectiles: [],
    effects: [],
    summons: [],
    selectedBoss: null,
    bossState: {
      currentBoss: null,
      currentPhase: 1,
      maxPhases: 3,
      phaseHealth: [100, 100, 100],
      enraged: false,
      specialAttackTimer: 0,
      mechanicTimer: 0,
    },
  }),
  
  selectedBoss: null,
  setSelectedBoss: (bossId) => set({ selectedBoss: bossId }),
  
  startBossFight: () => {
    const state = get();
    if (!state.selectedBoss) return;
    
    const boss = BOSSES[state.selectedBoss];
    if (!boss) return;
    
    set({
      bossState: {
        currentBoss: state.selectedBoss,
        currentPhase: 1,
        maxPhases: boss.phases,
        phaseHealth: Array(boss.phases).fill(100),
        enraged: false,
        specialAttackTimer: 5,
        mechanicTimer: 10,
      },
    });
    
    state.startRound();
  },
  
  keys: {},
  setKey: (key, pressed) => set((state) => ({
    keys: { ...state.keys, [key]: pressed },
  })),
  
  mouseDown: false,
  setMouseDown: (down) => set({ mouseDown: down }),
  
  isUltimateActive: false,
  ultimateOwner: null,
  setUltimateActive: (active, owner) => set({ 
    isUltimateActive: active, 
    ultimateOwner: owner ?? null 
  }),
  
  cameraShake: 0,
  setCameraShake: (intensity) => set({ cameraShake: intensity }),
  
  timeScale: 1,
  setTimeScale: (scale) => set({ timeScale: scale }),
  
  aiStates: {},
  
  // Importação síncrona do SkillSystem para evitar problemas com async
  _skillSystemLoaded: false,
  _skillSystem: null as any,
  
  updateAI: (playerId, delta) => {
    const state = get();
    if (state.gameState !== 'fighting') return;
    
    // Obter o jogador AI
    const aiPlayer = playerId === 2 ? state.player2 : 
                     playerId === 3 ? state.player3 :
                     state.player4;
    
    // Verificações básicas
    if (!aiPlayer) return;
    if (!aiPlayer.isAI) return;
    if (!aiPlayer.isAlive || aiPlayer.health <= 0) return;
    
    // Mesmo stunned, a IA deve continuar existindo e preparando próximas ações
    const isStunned = aiPlayer.stunned > 0;
    
    // Obter ou criar AIState
    let aiState = state.aiStates[playerId];
    if (!aiState) {
      const defaultTarget = aiPlayer.team === 1 ? 2 : 1;
      aiState = {
        lastAction: Date.now(),
        actionCooldown: 0.3, // Cooldown inicial curto
        targetPosition: { x: 0, z: 0 },
        aggression: 0.5 + Math.random() * 0.4,
        currentBehavior: 'chase',
        targetPlayerId: defaultTarget as 1 | 2 | 3 | 4,
      };
      set({ aiStates: { ...state.aiStates, [playerId]: aiState } });
      return; // Retorna para o próximo frame aplicar o estado
    }
    
    const char = CHARACTERS[aiPlayer.characterId];
    
    // Filtrar apenas inimigos vivos
    const allPlayers = [state.player1, state.player2, state.player3, state.player4].filter(p => p !== null) as Player[];
    const aliveEnemies = allPlayers.filter(p => 
      p && 
      p.isAlive && 
      p.health > 0 && 
      p.team !== aiPlayer.team && 
      p.id !== playerId
    );
    
    // Se não há inimigos vivos, apenas ficar parado
    if (aliveEnemies.length === 0) {
      return;
    }
    
    // Escolher alvo mais próximo
    let closestEnemy = aliveEnemies[0];
    let closestDist = Infinity;
    for (const enemy of aliveEnemies) {
      const edx = enemy.position.x - aiPlayer.position.x;
      const edz = enemy.position.z - aiPlayer.position.z;
      const dist = Math.sqrt(edx * edx + edz * edz);
      if (dist < closestDist) {
        closestDist = dist;
        closestEnemy = enemy;
      }
    }
    
    const dx = closestEnemy.position.x - aiPlayer.position.x;
    const dz = closestEnemy.position.z - aiPlayer.position.z;
    const distance = Math.max(0.01, closestDist); // Evitar divisão por zero
    
    // Direção normalizada para o inimigo
    const dirX = dx / distance;
    const dirZ = dz / distance;
    
    // Sempre olhar para o inimigo
    const newRotation = Math.atan2(dx, dz);
    
    // Se stunned, apenas atualizar rotação e retornar
    if (isStunned) {
      state.updatePlayer(playerId, { rotation: newRotation });
      return;
    }
    
    // Decrementar cooldown - nunca maior que 2 segundos
    const rawCooldown = Math.max(0, aiState.actionCooldown - delta);
    const newCooldown = Math.min(rawCooldown, 2.0);
    
    // Configurações baseadas no tipo de jogo
    const isBoss = state.gameMode === 'boss' && playerId === 2;
    const healthPercent = aiPlayer.health / char.maxHealth;
    
    // Velocidade de movimento
    const baseSpeed = char.speed * (isBoss ? 0.8 : 1);
    const moveSpeed = baseSpeed * (aiPlayer.slowTimer > 0 ? 0.5 : 1);
    
    // Variáveis de movimento
    let moveX = 0;
    let moveZ = 0;
    let newBehavior = aiState.currentBehavior;
    let updatedCooldown = newCooldown;
    
    // Decidir novo comportamento apenas quando cooldown acabar
    if (newCooldown <= 0) {
      const rand = Math.random();
      const aggression = aiState.aggression + (isBoss ? 0.3 : 0);
      
      if (healthPercent < 0.2 && rand > aggression) {
        newBehavior = 'retreat';
      } else if (distance > 8) {
        newBehavior = 'chase';
      } else if (distance < 2) {
        newBehavior = rand > 0.25 ? 'attack' : (rand > 0.1 ? 'defend' : 'skill');
      } else if (distance < 5) {
        newBehavior = rand > 0.4 ? 'attack' : 'skill';
      } else {
        newBehavior = 'chase';
      }
    }
    
    // Executar comportamento
    switch (newBehavior) {
      case 'chase':
        // Sempre mover em direção ao inimigo se longe
        moveX = dirX * moveSpeed;
        moveZ = dirZ * moveSpeed;
        
        // Se chegou perto, trocar para attack
        if (distance < 3) {
          newBehavior = 'attack';
        }
        break;
        
      case 'retreat':
        // Fugir do inimigo
        moveX = -dirX * moveSpeed * 0.7;
        moveZ = -dirZ * moveSpeed * 0.7;
        
        // Adicionar movimento lateral aleatório para evitar
        const lateralDir = Math.random() > 0.5 ? 1 : -1;
        moveX += -dirZ * lateralDir * moveSpeed * 0.3;
        moveZ += dirX * lateralDir * moveSpeed * 0.3;
        
        // Se afastou o suficiente, voltar a atacar
        if (distance > 12) {
          newBehavior = 'chase';
        }
        break;
        
      case 'attack':
        // Aproximar se ainda não está perto o suficiente
        if (distance > 2.5) {
          moveX = dirX * moveSpeed;
          moveZ = dirZ * moveSpeed;
        }
        
        // Atacar se cooldown permitir
        if (newCooldown <= 0 && distance < 4) {
          const canUseSkill1 = aiPlayer.cooldowns.skill1 <= 0 && aiPlayer.stamina >= char.skill1Cost;
          const useSkill = canUseSkill1 && Math.random() > 0.4;
          
          if (useSkill) {
            // Usar Skill 1
            const skillDamage = char.skill1Damage;
            const currentEnemy = closestEnemy.id === 1 ? get().player1 :
                                 closestEnemy.id === 2 ? get().player2 :
                                 closestEnemy.id === 3 ? get().player3 :
                                 get().player4;
            
            if (currentEnemy && currentEnemy.isAlive) {
              state.updatePlayer(closestEnemy.id, {
                health: Math.max(0, currentEnemy.health - skillDamage),
                stunned: 0.4,
              });
            }
            
            state.updatePlayer(playerId, {
              stamina: aiPlayer.stamina - char.skill1Cost,
              cooldowns: { ...aiPlayer.cooldowns, skill1: char.skill1Cooldown },
              blast: Math.min(100, aiPlayer.blast + 8),
              isAttacking: true,
            });
            
            state.addEffect({
              type: 'skill1-hit',
              position: { x: closestEnemy.position.x, y: 1.2, z: closestEnemy.position.z },
              lifetime: 0.5,
              color: char.color,
              scale: 2,
            });
            
            state.setCameraShake(0.4);
            updatedCooldown = 0.7 + Math.random() * 0.4;
            
            // Reset attacking after delay
            setTimeout(() => {
              get().updatePlayer(playerId, { isAttacking: false });
            }, 300);
          } else if (distance < 2.5) {
            // Soco básico
            const currentEnemy = closestEnemy.id === 1 ? get().player1 :
                                 closestEnemy.id === 2 ? get().player2 :
                                 closestEnemy.id === 3 ? get().player3 :
                                 get().player4;
            
            if (currentEnemy && currentEnemy.isAlive) {
              const baseDamage = 5 + Math.random() * 3;
              state.updatePlayer(closestEnemy.id, {
                health: Math.max(0, currentEnemy.health - baseDamage),
              });
            }
            
            state.updatePlayer(playerId, {
              blast: Math.min(100, aiPlayer.blast + 3),
              isAttacking: true,
            });
            
            state.addEffect({
              type: 'punch',
              position: { x: closestEnemy.position.x, y: 1.2, z: closestEnemy.position.z },
              lifetime: 0.3,
              color: '#ffffff',
              scale: 1,
            });
            
            updatedCooldown = 0.35 + Math.random() * 0.2;
            
            setTimeout(() => {
              get().updatePlayer(playerId, { isAttacking: false });
            }, 200);
          }
        }
        break;
        
      case 'skill':
        // Movimento leve em direção ao inimigo
        if (distance > 4) {
          moveX = dirX * moveSpeed * 0.6;
          moveZ = dirZ * moveSpeed * 0.6;
        }
        
        if (newCooldown <= 0) {
          const canUseSkill2 = aiPlayer.cooldowns.skill2 <= 0 && aiPlayer.stamina >= char.skill2Cost;
          const canUseUltimate = aiPlayer.blast >= 100;
          
          if (canUseUltimate && Math.random() > 0.3 && distance < 10) {
            // Usar Ultimate
            const ultDamage = char.ultimateDamage;
            const currentEnemy = closestEnemy.id === 1 ? get().player1 :
                                 closestEnemy.id === 2 ? get().player2 :
                                 closestEnemy.id === 3 ? get().player3 :
                                 get().player4;
            
            if (currentEnemy && currentEnemy.isAlive) {
              state.updatePlayer(closestEnemy.id, {
                health: Math.max(0, currentEnemy.health - ultDamage),
                stunned: 2,
              });
            }
            
            state.updatePlayer(playerId, {
              blast: 0,
              isAttacking: true,
            });
            
            state.addEffect({
              type: 'ultimate-explosion',
              position: { x: closestEnemy.position.x, y: 0.5, z: closestEnemy.position.z },
              lifetime: 1.5,
              color: char.color,
              scale: 5,
            });
            
            state.setCameraShake(1.5);
            updatedCooldown = 2;
            
            setTimeout(() => {
              get().updatePlayer(playerId, { isAttacking: false });
            }, 500);
          } else if (canUseSkill2 && distance < 10) {
            // Usar Skill 2 - Lançar projétil
            state.addProjectile({
              owner: playerId,
              team: aiPlayer.team,
              position: { 
                x: aiPlayer.position.x + dirX * 1.2, 
                y: 1, 
                z: aiPlayer.position.z + dirZ * 1.2 
              },
              velocity: { x: dirX * 18, y: 0, z: dirZ * 18 },
              damage: char.skill2Damage,
              lifetime: 2.5,
              color: char.secondaryColor,
              size: 0.7,
              isHoming: Math.random() > 0.6,
              targetId: closestEnemy.id,
            });
            
            state.updatePlayer(playerId, {
              stamina: aiPlayer.stamina - char.skill2Cost,
              cooldowns: { ...aiPlayer.cooldowns, skill2: char.skill2Cooldown },
              blast: Math.min(100, aiPlayer.blast + 10),
              isAttacking: true,
            });
            
            state.addEffect({
              type: 'skill-cast',
              position: { x: aiPlayer.position.x, y: 1.5, z: aiPlayer.position.z },
              lifetime: 0.5,
              color: char.secondaryColor,
              scale: 2.5,
            });
            
            updatedCooldown = 1 + Math.random() * 0.5;
            
            setTimeout(() => {
              get().updatePlayer(playerId, { isAttacking: false });
            }, 300);
          } else {
            // Não conseguiu usar skill, voltar para chase/attack
            newBehavior = distance > 4 ? 'chase' : 'attack';
          }
        }
        break;
        
      case 'defend':
        // Ficar parado e bloquear
        const currentlyBlocking = aiPlayer.isBlocking;
        
        if (newCooldown <= 0 && !currentlyBlocking) {
          state.updatePlayer(playerId, { isBlocking: true });
          
          // Parar de bloquear após um tempo
          const blockDuration = 300 + Math.random() * 400;
          const pid = playerId; // Capturar em closure
          setTimeout(() => {
            const currentState = get();
            const currentPlayer = pid === 2 ? currentState.player2 :
                                   pid === 3 ? currentState.player3 :
                                   currentState.player4;
            if (currentPlayer) {
              currentState.updatePlayer(pid, { isBlocking: false });
            }
          }, blockDuration);
          
          updatedCooldown = 0.6 + Math.random() * 0.3;
        }
        
        // Sair do modo defend se o inimigo está longe
        if (distance > 5) {
          newBehavior = 'chase';
        }
        break;
        
      default:
        // Fallback: sempre perseguir
        newBehavior = 'chase';
        moveX = dirX * moveSpeed;
        moveZ = dirZ * moveSpeed;
        break;
    }
    
    // Se não há movimento e não está bloqueando, forçar perseguição
    if (moveX === 0 && moveZ === 0 && !aiPlayer.isBlocking && distance > 2) {
      moveX = dirX * moveSpeed * 0.5;
      moveZ = dirZ * moveSpeed * 0.5;
    }
    
    // Aplicar movimento - SEMPRE se não está bloqueando
    if (!aiPlayer.isBlocking) {
      const newPos = {
        x: Math.max(-18, Math.min(18, aiPlayer.position.x + moveX)),
        y: 0, // Sempre no chão
        z: Math.max(-18, Math.min(18, aiPlayer.position.z + moveZ)),
      };
      
      state.updatePlayer(playerId, {
        position: newPos,
        rotation: newRotation,
        velocity: { x: 0, y: 0, z: 0 },
        isGrounded: true,
      });
    } else {
      // Mesmo bloqueando, atualizar rotação para olhar para o inimigo
      state.updatePlayer(playerId, {
        rotation: newRotation,
      });
    }
    
    // Atualizar AI state com novo comportamento e cooldown
    set({ 
      aiStates: { 
        ...get().aiStates, 
        [playerId]: { 
          ...aiState, 
          actionCooldown: updatedCooldown,
          currentBehavior: newBehavior,
          targetPlayerId: closestEnemy.id,
          lastAction: Date.now(),
        } 
      } 
    });
  },
  
  updateAllAI: (delta) => {
    const state = get();
    if (state.gameState !== 'fighting') return;
    
    // Lista de jogadores AI para atualizar
    const aiPlayersToUpdate: (2 | 3 | 4)[] = [];
    
    // Verificar cada jogador AI
    if (state.player2) {
      if (state.player2.isAI && state.player2.isAlive && state.player2.health > 0) {
        aiPlayersToUpdate.push(2);
      }
    }
    
    if (state.player3) {
      if (state.player3.isAI && state.player3.isAlive && state.player3.health > 0) {
        aiPlayersToUpdate.push(3);
      }
    }
    
    if (state.player4) {
      if (state.player4.isAI && state.player4.isAlive && state.player4.health > 0) {
        aiPlayersToUpdate.push(4);
      }
    }
    
    // Atualizar cada AI
    for (const playerId of aiPlayersToUpdate) {
      try {
        state.updateAI(playerId, delta);
      } catch (e) {
        console.error(`Erro ao atualizar AI ${playerId}:`, e);
      }
    }
  },
}));
