/**
 * OMNIVERSE CHAOS: ARENA
 * Sistema de Habilidades OTIMIZADO - Versão 4.0
 * 
 * OTIMIZAÇÕES:
 * - Menos partículas mantendo impacto visual
 * - Menos setTimeout em loops
 * - Efeitos combinados em vez de múltiplos individuais
 * - Performance melhorada sem perder qualidade
 */

import { useGameStore, CharacterId, Player, CHARACTERS } from '../store/gameStore';

// ============== TIPOS ==============

export interface SkillContext {
  player: Player;
  opponent: Player;
  direction: { x: number; y: number; z: number };
  targetRotation: number;
  addProjectile: (proj: ProjectileData) => void;
  addEffect: (effect: EffectData) => void;
  addSummon: (summon: SummonData) => void;
  updatePlayer: (id: 1 | 2 | 3 | 4, updates: Partial<Player>) => void;
  setCameraShake: (intensity: number) => void;
}

export interface ProjectileData {
  owner: 1 | 2 | 3 | 4;
  position: { x: number; y: number; z: number };
  velocity: { x: number; y: number; z: number };
  damage: number;
  lifetime: number;
  color: string;
  size: number;
  effect?: SkillEffect;
  isHoming?: boolean;
  targetId?: 1 | 2 | 3 | 4;
  skillType?: string;
  visualType?: 'default' | 'ink' | 'fire' | 'ice' | 'electric' | 'magic' | 'cosmic' | 'dark' | 'holy';
}

export interface EffectData {
  type: string;
  position: { x: number; y: number; z: number };
  lifetime: number;
  color: string;
  scale?: number;
  particleCount?: number;
  effectStyle?: string;
}

export interface SummonData {
  owner: 1 | 2 | 3 | 4;
  type: string;
  position: { x: number; y: number; z: number };
  targetId: 1 | 2 | 3 | 4;
  damage: number;
  lifetime: number;
  speed: number;
  behavior?: 'chase' | 'orbit' | 'trap' | 'shoot' | 'guard';
}

export interface SkillEffect {
  type?: string;
  knockbackMultiplier?: number;
  stunDuration?: number;
  slowPercent?: number;
  blindDuration?: number;
  dotDamage?: number;
  dotDuration?: number;
  healAmount?: number;
  ignoreDefense?: boolean;
  aoeRadius?: number;
  confuseControls?: boolean;
}

// ============== FUNÇÕES AUXILIARES ==============

function clampPosition(x: number, z: number): { x: number; z: number } {
  return {
    x: Math.max(-17, Math.min(17, x)),
    z: Math.max(-17, Math.min(17, z)),
  };
}

function getDistance(p1: { x: number; z: number }, p2: { x: number; z: number }): number {
  return Math.sqrt((p1.x - p2.x) ** 2 + (p1.z - p2.z) ** 2);
}

function normalizeDirection(dx: number, dz: number): { x: number; z: number } {
  const dist = Math.sqrt(dx * dx + dz * dz);
  if (dist === 0) return { x: 0, z: 1 };
  return { x: dx / dist, z: dz / dist };
}

// ============== SKILL 1: HABILIDADES PRIMÁRIAS ==============

export const executeSkill1 = (characterId: CharacterId, ctx: SkillContext): void => {
  const { player, opponent, direction, addProjectile, addEffect, updatePlayer, setCameraShake } = ctx;
  
  switch (characterId) {
    
    // INK DEMON - INK FLOW (Dissolução com i-frames)
    case 'ink-demon': {
      const playerId = player.id;
      const startPos = { ...player.position };
      
      // Ficar invencível e invisível
      updatePlayer(playerId, { isInvincible: true, isInvisible: true });
      
      // Efeito de dissolução
      addEffect({
        type: 'ink-dissolve',
        position: { x: startPos.x, y: 0.3, z: startPos.z },
        lifetime: 0.6,
        color: '#000000',
        scale: 3,
      });
      
      // Poça no chão
      addEffect({
        type: 'ink-puddle',
        position: { x: startPos.x, y: 0.02, z: startPos.z },
        lifetime: 2,
        color: '#000000',
        scale: 3,
      });
      
      // Movimento
      const travelDist = 10;
      const dest = clampPosition(
        startPos.x + direction.x * travelDist,
        startPos.z + direction.z * travelDist
      );
      
      // Emergir após 200ms
      setTimeout(() => {
        const state = useGameStore.getState();
        state.updatePlayer(playerId, {
          position: { x: dest.x, y: 0, z: dest.z },
        });
        
        state.addEffect({
          type: 'ink-emerge',
          position: { x: dest.x, y: 0.1, z: dest.z },
          lifetime: 0.5,
          color: '#FFD700',
          scale: 2.5,
        });
      }, 200);
      
      // Voltar ao normal
      setTimeout(() => {
        useGameStore.getState().updatePlayer(playerId, {
          isInvincible: false,
          isInvisible: false,
        });
      }, 500);
      
      setCameraShake(0.2);
      break;
    }
    
    // VAPOR - SMOKE CLOAK
    case 'vapor': {
      const playerId = player.id;
      const oppId = opponent.id;
      
      // Explosão de fumaça
      addEffect({
        type: 'smoke-explosion',
        position: { x: player.position.x, y: 1, z: player.position.z },
        lifetime: 1,
        color: '#3a3a3a',
        scale: 5,
      });
      
      // Invisibilidade
      updatePlayer(playerId, {
        isInvisible: true,
        damageBoost: 25,
        damageBoostTimer: 4,
      });
      
      // Cegar oponente
      updatePlayer(oppId, { blindTimer: 3 });
      
      // Remover invisibilidade após 4s
      setTimeout(() => {
        useGameStore.getState().updatePlayer(playerId, { isInvisible: false });
      }, 4000);
      
      setCameraShake(0.3);
      break;
    }
    
    // PILGOR - LICK GRAPPLE (Língua que puxa lentamente - estilo Goat Simulator)
    case 'pilgor': {
      const oppId = opponent.id;
      const playerId = player.id;
      const tongueRange = 14;
      const distToEnemy = getDistance(player.position, opponent.position);
      
      // Efeito visual da língua se estendendo
      const tongueLength = Math.min(distToEnemy, tongueRange);
      addEffect({
        type: 'tongue-extend',
        position: {
          x: player.position.x + direction.x * tongueLength * 0.5,
          y: 1.2,
          z: player.position.z + direction.z * tongueLength * 0.5,
        },
        lifetime: 0.6,
        color: '#FF69B4',
        scale: tongueLength,
      });
      
      if (distToEnemy <= tongueRange) {
        // LÍNGUA CONECTOU! Inimigo entra em modo ragdoll
        updatePlayer(oppId, {
          isRagdoll: true,
          ragdollTimer: 5.0, // Duração máxima de 5 segundos
          stunned: 5.5, // Não pode agir enquanto é puxado
          health: Math.max(0, opponent.health - 10),
          velocity: { x: 0, y: 0, z: 0 },
        });
        
        // Efeito de conexão
        addEffect({
          type: 'tongue-hit',
          position: { x: opponent.position.x, y: 1.2, z: opponent.position.z },
          lifetime: 0.4,
          color: '#FFFF00',
          scale: 2,
        });
        
        // Sistema de puxar lentamente - a cada 100ms atualiza a posição
        const pullSpeed = 4; // Unidades por segundo
        const pullDuration = 5000; // 5 segundos máximo
        let elapsedTime = 0;
        
        const pullInterval = setInterval(() => {
          elapsedTime += 100;
          const state = useGameStore.getState();
          
          // Obter posições atuais
          const currentPilgor = state[`player${playerId}` as keyof typeof state] as Player;
          const currentOpp = state[`player${oppId}` as keyof typeof state] as Player;
          
          if (!currentPilgor || !currentOpp || !currentOpp.isAlive) {
            clearInterval(pullInterval);
            return;
          }
          
          // Calcular distância atual
          const dx = currentPilgor.position.x - currentOpp.position.x;
          const dz = currentPilgor.position.z - currentOpp.position.z;
          const currentDist = Math.sqrt(dx * dx + dz * dz);
          
          // Se chegou perto o suficiente ou tempo acabou, terminar
          if (currentDist < 2.5 || elapsedTime >= pullDuration) {
            clearInterval(pullInterval);
            
            // Soltar o inimigo - ele volta a ficar em pé
            state.updatePlayer(oppId, {
              isRagdoll: false,
              ragdollTimer: 0,
              stunned: 0.8, // Pequeno stun após soltar
              velocity: { x: 0, y: 0, z: 0 },
            });
            
            // Efeito de soltar
            state.addEffect({
              type: 'tongue-release',
              position: { x: currentOpp.position.x, y: 1, z: currentOpp.position.z },
              lifetime: 0.5,
              color: '#FFFF00',
              scale: 2,
            });
            
            if (currentDist < 2.5) {
              // Bônus de dano por puxar completamente
              state.updatePlayer(oppId, {
                health: Math.max(0, currentOpp.health - 5),
                stunned: 1.2,
              });
              
              state.addEffect({
                type: 'pull-complete',
                position: { x: currentOpp.position.x, y: 1.5, z: currentOpp.position.z },
                lifetime: 0.6,
                color: '#00FF00',
                scale: 2.5,
              });
              
              state.setCameraShake(0.6);
            }
            return;
          }
          
          // Puxar lentamente em direção à posição ATUAL do Pilgor
          const dirX = dx / currentDist;
          const dirZ = dz / currentDist;
          const pullStep = pullSpeed * 0.1; // 0.1s por tick
          
          const newX = currentOpp.position.x + dirX * pullStep;
          const newZ = currentOpp.position.z + dirZ * pullStep;
          const newPos = clampPosition(newX, newZ);
          
          // Atualizar posição do inimigo (deitado/ragdoll)
          state.updatePlayer(oppId, {
            position: { x: newPos.x, y: 0, z: newPos.z },
            velocity: { x: 0, y: 0, z: 0 },
            ragdollTimer: currentOpp.ragdollTimer - 0.1,
          });
          
          // Efeito visual da língua conectada
          state.addEffect({
            type: 'tongue-line',
            position: {
              x: (currentPilgor.position.x + currentOpp.position.x) / 2,
              y: 1,
              z: (currentPilgor.position.z + currentOpp.position.z) / 2,
            },
            lifetime: 0.15,
            color: '#FF69B4',
            scale: currentDist,
          });
        }, 100);
        
        setCameraShake(0.4);
      } else {
        // Língua não alcançou - efeito de falha
        addEffect({
          type: 'tongue-miss',
          position: {
            x: player.position.x + direction.x * tongueRange,
            y: 1.2,
            z: player.position.z + direction.z * tongueRange,
          },
          lifetime: 0.3,
          color: '#FF69B4',
          scale: 1,
        });
      }
      break;
    }
    
    // SHREK - DO THE ROAR!
    case 'shrek': {
      const roarRange = 8;
      
      // Onda sonora
      addEffect({
        type: 'sound-wave',
        position: { x: player.position.x, y: 1.5, z: player.position.z },
        lifetime: 0.8,
        color: '#7CFC00',
        scale: 6,
      });
      
      // Texto
      addEffect({
        type: 'roar-text',
        position: { x: player.position.x, y: 3, z: player.position.z },
        lifetime: 1,
        color: '#7CFC00',
        scale: 2,
      });
      
      // Verificar hit
      const distToEnemy = getDistance(player.position, opponent.position);
      const toEnemyDir = normalizeDirection(
        opponent.position.x - player.position.x,
        opponent.position.z - player.position.z
      );
      const dot = toEnemyDir.x * direction.x + toEnemyDir.z * direction.z;
      
      if (distToEnemy < roarRange && dot > 0.3) {
        const pushDist = 5;
        const pushPos = clampPosition(
          opponent.position.x + direction.x * pushDist,
          opponent.position.z + direction.z * pushDist
        );
        
        updatePlayer(opponent.id, {
          position: { x: pushPos.x, y: 0, z: pushPos.z },
          velocity: { x: 0, y: 0, z: 0 },
          stunned: 1.8,
          isAttacking: false,
          health: Math.max(0, opponent.health - 10),
        });
        
        addEffect({
          type: 'stun-stars',
          position: { x: pushPos.x, y: 2.5, z: pushPos.z },
          lifetime: 1.8,
          color: '#FFFF00',
          scale: 1,
        });
      }
      
      setCameraShake(0.6);
      break;
    }
    
    // WALUIGI - TECHNICAL RETURN
    case 'waluigi': {
      addEffect({
        type: 'racket-swing',
        position: {
          x: player.position.x + direction.x * 1.5,
          y: 1.3,
          z: player.position.z + direction.z * 1.5,
        },
        lifetime: 0.3,
        color: '#4B0082',
        scale: 2.5,
      });
      
      // Procurar projéteis
      const state = useGameStore.getState();
      let reflected = false;
      
      for (const proj of state.projectiles) {
        if (proj.owner !== player.id) {
          const dist = getDistance(proj.position, player.position);
          if (dist < 5) {
            state.removeProjectile(proj.id);
            
            addProjectile({
              owner: player.id,
              position: { ...proj.position },
              velocity: { x: direction.x * 45, y: 0, z: direction.z * 45 },
              damage: proj.damage * 2,
              lifetime: 3,
              color: '#9400D3',
              size: proj.size * 1.3,
              effect: { knockbackMultiplier: 2.5 },
              visualType: 'magic',
            });
            
            addEffect({
              type: 'reflect-burst',
              position: { ...proj.position },
              lifetime: 0.4,
              color: '#FFD700',
              scale: 2,
            });
            
            reflected = true;
            setCameraShake(0.4);
            break;
          }
        }
      }
      
      if (!reflected) {
        addProjectile({
          owner: player.id,
          position: {
            x: player.position.x + direction.x * 1.8,
            y: 1.2,
            z: player.position.z + direction.z * 1.8,
          },
          velocity: { x: direction.x * 50, y: 0, z: direction.z * 50 },
          damage: 10,
          lifetime: 0.15,
          color: '#4B0082',
          size: 0.6,
        });
      }
      break;
    }
    
    // SEIYA - PEGASUS ROLLING CRUSH (Turbilhão de Pégaso)
    case 'seiya': {
      const grabRange = 5;
      const distToEnemy = getDistance(player.position, opponent.position);
      
      if (distToEnemy <= grabRange) {
        const playerId = player.id;
        const oppId = opponent.id;
        const grabX = player.position.x;
        const grabZ = player.position.z;
        const oppHealth = opponent.health;
        
        // Agarrar oponente e travar ambos - INIMIGO NÃO PODE FAZER NADA
        updatePlayer(oppId, { 
          stunned: 4.0, // Stun durante todo o ataque
          isGrabbed: true,
          isAttacking: false,
          velocity: { x: 0, y: 0, z: 0 }
        });
        updatePlayer(playerId, { 
          isInvincible: true,
          isGrabbed: true, // Seiya também está em grab (não pode ser interrompido)
          velocity: { x: 0, y: 0, z: 0 }
        });
        
        // Flash inicial do cosmo
        addEffect({
          type: 'cosmos-burst',
          position: { x: grabX, y: 1, z: grabZ },
          lifetime: 0.6,
          color: '#FFD700',
          scale: 5,
        });
        
        // FASE 1: SUBIR (0-1000ms) - Ambos sobem juntos girando
        const maxHeight = 15;
        const riseTime = 1000;
        const riseSteps = 20;
        
        for (let i = 0; i <= riseSteps; i++) {
          setTimeout(() => {
            const height = (i / riseSteps) * maxHeight;
            const state = useGameStore.getState();
            
            // Atualizar posições de ambos os jogadores subindo
            state.updatePlayer(playerId, {
              position: { x: grabX, y: height, z: grabZ },
              velocity: { x: 0, y: 0, z: 0 },
              isGrabbed: true // Manter grabbed
            });
            
            state.updatePlayer(oppId, {
              position: { x: grabX, y: height, z: grabZ },
              velocity: { x: 0, y: 0, z: 0 },
              stunned: 4.0, // Manter stunned
              isGrabbed: true,
              isAttacking: false
            });
            
            // Efeitos de rotação enquanto sobe
            if (i % 4 === 0) {
              const angle = (i / 4) * Math.PI * 0.5;
              state.addEffect({
                type: 'cosmos-ring',
                position: { 
                  x: grabX + Math.cos(angle) * 1.5, 
                  y: height, 
                  z: grabZ + Math.sin(angle) * 1.5 
                },
                lifetime: 0.4,
                color: '#FFD700',
                scale: 2,
              });
            }
          }, (i / riseSteps) * riseTime);
        }
        
        // FASE 2: GIRAR NO TOPO (1000-1800ms)
        setTimeout(() => {
          const state = useGameStore.getState();
          
          // Manter ambos travados no topo
          state.updatePlayer(oppId, {
            stunned: 3.0,
            isGrabbed: true,
            isAttacking: false
          });
          
          // Grande aura dourada no topo
          state.addEffect({
            type: 'cosmos-explosion',
            position: { x: grabX, y: maxHeight, z: grabZ },
            lifetime: 0.8,
            color: '#FFD700',
            scale: 6,
          });
          
          // Anéis girando
          for (let j = 0; j < 6; j++) {
            setTimeout(() => {
              const spinAngle = (j / 6) * Math.PI * 2;
              useGameStore.getState().addEffect({
                type: 'cosmos-trail',
                position: { 
                  x: grabX + Math.cos(spinAngle) * 2, 
                  y: maxHeight, 
                  z: grabZ + Math.sin(spinAngle) * 2 
                },
                lifetime: 0.3,
                color: '#4169E1',
                scale: 1.5,
              });
            }, j * 100);
          }
        }, riseTime);
        
        // FASE 3: DESCER (1800-2800ms) - Queda rápida
        const fallStartTime = 1800;
        const fallTime = 800;
        const fallSteps = 16;
        
        for (let i = 0; i <= fallSteps; i++) {
          setTimeout(() => {
            const height = maxHeight * (1 - (i / fallSteps));
            const state = useGameStore.getState();
            
            // Ambos descendo juntos - MANTER TRAVADOS
            state.updatePlayer(playerId, {
              position: { x: grabX, y: height, z: grabZ },
              velocity: { x: 0, y: 0, z: 0 },
              isGrabbed: true
            });
            
            state.updatePlayer(oppId, {
              position: { x: grabX, y: height, z: grabZ },
              velocity: { x: 0, y: 0, z: 0 },
              stunned: 2.5,
              isGrabbed: true,
              isAttacking: false
            });
            
            // Rastro de queda
            if (i % 3 === 0) {
              state.addEffect({
                type: 'fall-trail',
                position: { x: grabX, y: height + 2, z: grabZ },
                lifetime: 0.3,
                color: '#FFD700',
                scale: 2,
              });
            }
          }, fallStartTime + (i / fallSteps) * fallTime);
        }
        
        // FASE 4: IMPACTO (2800ms)
        setTimeout(() => {
          const state = useGameStore.getState();
          
          // Cratera massiva
          state.addEffect({
            type: 'ground-crater',
            position: { x: grabX, y: 0.05, z: grabZ },
            lifetime: 3,
            color: '#8B4513',
            scale: 8,
          });
          
          // Flash de impacto
          state.addEffect({
            type: 'impact-flash',
            position: { x: grabX, y: 0.5, z: grabZ },
            lifetime: 0.5,
            color: '#FFFFFF',
            scale: 8,
          });
          
          // Shockwave
          state.addEffect({
            type: 'shockwave',
            position: { x: grabX, y: 0.2, z: grabZ },
            lifetime: 0.8,
            color: '#FFD700',
            scale: 10,
          });
          
          // Detritos voando
          for (let d = 0; d < 8; d++) {
            const debrisAngle = (d / 8) * Math.PI * 2;
            state.addEffect({
              type: 'debris',
              position: { 
                x: grabX + Math.cos(debrisAngle) * 3, 
                y: 1, 
                z: grabZ + Math.sin(debrisAngle) * 3 
              },
              lifetime: 0.8,
              color: '#696969',
              scale: 1,
            });
          }
          
          // Finalizar - posicionar ambos no chão e LIBERAR
          state.updatePlayer(playerId, {
            position: { x: grabX - 2, y: 0, z: grabZ },
            velocity: { x: 0, y: 0, z: 0 },
            isInvincible: false,
            isGrabbed: false, // Liberar Seiya
          });
          
          state.updatePlayer(oppId, {
            position: { x: grabX + 2, y: 0, z: grabZ },
            velocity: { x: 0, y: 0, z: 0 },
            health: Math.max(0, oppHealth - 28),
            stunned: 2.0, // Stun após impacto
            isGrabbed: false, // Liberar oponente
            isAttacking: false,
          });
          
          state.setCameraShake(1.0);
        }, fallStartTime + fallTime + 200);
        
      } else {
        // Se longe, dash rápido em direção ao inimigo
        const dashDist = 6;
        const dashDest = clampPosition(
          player.position.x + direction.x * dashDist,
          player.position.z + direction.z * dashDist
        );
        
        updatePlayer(player.id, {
          position: { x: dashDest.x, y: 0, z: dashDest.z },
        });
        
        addEffect({
          type: 'cosmos-dash',
          position: { ...player.position },
          lifetime: 0.3,
          color: '#4169E1',
          scale: 3,
        });
        
        addProjectile({
          owner: player.id,
          position: {
            x: dashDest.x + direction.x * 1,
            y: 1,
            z: dashDest.z + direction.z * 1,
          },
          velocity: { x: direction.x * 40, y: 0, z: direction.z * 40 },
          damage: 12,
          lifetime: 0.25,
          color: '#FFD700',
          size: 0.7,
          visualType: 'cosmic',
        });
      }
      break;
    }
    
    // MAN FROM THE FOG - GLITCH STALK (Teleporte ATRÁS do oponente)
    case 'man-from-fog': {
      const playerId = player.id;
      const oppId = opponent.id;
      const originalPos = { ...player.position };
      
      // Efeito de glitch
      addEffect({
        type: 'static-glitch',
        position: { x: originalPos.x, y: 1.2, z: originalPos.z },
        lifetime: 0.5,
        color: '#FFFFFF',
        scale: 3,
      });
      
      updatePlayer(playerId, { isInvisible: true, isInvincible: true });
      
      // Teleporte após 100ms
      setTimeout(() => {
        const state = useGameStore.getState();
        const currentOpp = state.player1.id === oppId ? state.player1 : state.player2;
        
        // Calcular posição ATRÁS do oponente (baseado na rotação dele)
        const oppFacingX = Math.sin(currentOpp.rotation);
        const oppFacingZ = Math.cos(currentOpp.rotation);
        
        // Atrás = oponente - direção que ele olha
        const behindX = currentOpp.position.x - oppFacingX * 2.5;
        const behindZ = currentOpp.position.z - oppFacingZ * 2.5;
        const teleportPos = clampPosition(behindX, behindZ);
        
        // Rotação para olhar para o oponente
        const lookRot = Math.atan2(
          currentOpp.position.x - teleportPos.x,
          currentOpp.position.z - teleportPos.z
        );
        
        state.updatePlayer(playerId, {
          position: { x: teleportPos.x, y: 0, z: teleportPos.z },
          velocity: { x: 0, y: 0, z: 0 },
          rotation: lookRot,
          isInvisible: false,
          isGrounded: true,
        });
        
        state.addEffect({
          type: 'horror-appear',
          position: { x: teleportPos.x, y: 1.5, z: teleportPos.z },
          lifetime: 0.6,
          color: '#8B0000',
          scale: 2.5,
        });
        
        state.addEffect({
          type: 'glowing-eyes',
          position: { x: teleportPos.x, y: 1.8, z: teleportPos.z },
          lifetime: 0.5,
          color: '#FF0000',
          scale: 0.8,
        });
        
        // Dano por aparecer atrás
        state.updatePlayer(oppId, {
          health: Math.max(0, currentOpp.health - 10),
          stunned: 0.4,
        });
        
        state.setCameraShake(0.5);
      }, 100);
      
      // Raio na posição original
      setTimeout(() => {
        const state = useGameStore.getState();
        
        state.addProjectile({
          owner: playerId,
          position: { x: originalPos.x, y: 15, z: originalPos.z },
          velocity: { x: 0, y: -100, z: 0 },
          damage: 12,
          lifetime: 0.35,
          color: '#FFFFFF',
          size: 1.3,
          effect: { aoeRadius: 3.5 },
          visualType: 'electric',
        });
        
        state.addEffect({
          type: 'lightning-bolt',
          position: { x: originalPos.x, y: 5, z: originalPos.z },
          lifetime: 0.4,
          color: '#FFFF00',
          scale: 5,
        });
      }, 180);
      
      setTimeout(() => {
        useGameStore.getState().updatePlayer(playerId, { isInvincible: false });
      }, 400);
      break;
    }
    
    // DANDY - RANDOM STOCK (Roleta de Itens)
    case 'dandy': {
      const playerId = player.id;
      
      // Animação de roleta
      addEffect({
        type: 'roulette-spin',
        position: { x: player.position.x, y: 2.5, z: player.position.z },
        lifetime: 0.6,
        color: '#FF69B4',
        scale: 2,
      });
      
      // Resultado após delay
      setTimeout(() => {
        const roll = Math.random();
        const state = useGameStore.getState();
        const currentPlayer = state.player1.id === playerId ? state.player1 : state.player2;
        const currentOpponent = state.player1.id === playerId ? state.player2 : state.player1;
        
        const toOppDir = normalizeDirection(
          currentOpponent.position.x - currentPlayer.position.x,
          currentOpponent.position.z - currentPlayer.position.z
        );
        
        if (roll < 0.28) {
          // MEDKIT - Cura
          const healAmount = CHARACTERS[player.characterId].maxHealth * 0.20;
          state.updatePlayer(playerId, {
            health: Math.min(CHARACTERS[player.characterId].maxHealth, currentPlayer.health + healAmount),
          });
          
          state.addEffect({
            type: 'heal-cross',
            position: { x: currentPlayer.position.x, y: 2, z: currentPlayer.position.z },
            lifetime: 0.8,
            color: '#00FF00',
            scale: 2,
          });
          
        } else if (roll < 0.53) {
          // BOMBA
          state.addProjectile({
            owner: playerId,
            position: {
              x: currentPlayer.position.x + toOppDir.x * 1.5,
              y: 1.5,
              z: currentPlayer.position.z + toOppDir.z * 1.5,
            },
            velocity: { x: toOppDir.x * 20, y: 5, z: toOppDir.z * 20 },
            damage: 18,
            lifetime: 2.5,
            color: '#1a1a1a',
            size: 0.8,
            effect: { aoeRadius: 5 },
            skillType: 'bomb',
          });
          
        } else if (roll < 0.75) {
          // FITA - Stun
          state.addProjectile({
            owner: playerId,
            position: {
              x: currentPlayer.position.x + toOppDir.x * 1.5,
              y: 1.2,
              z: currentPlayer.position.z + toOppDir.z * 1.5,
            },
            velocity: { x: toOppDir.x * 30, y: 0, z: toOppDir.z * 30 },
            damage: 6,
            lifetime: 2,
            color: '#C0C0C0',
            size: 0.5,
            effect: { stunDuration: 2 },
          });
          
        } else if (roll < 0.92) {
          // BANANA - Slow
          state.addProjectile({
            owner: playerId,
            position: {
              x: currentPlayer.position.x + toOppDir.x * 1.5,
              y: 1,
              z: currentPlayer.position.z + toOppDir.z * 1.5,
            },
            velocity: { x: toOppDir.x * 18, y: 3, z: toOppDir.z * 18 },
            damage: 5,
            lifetime: 3,
            color: '#FFD700',
            size: 0.5,
            effect: { slowPercent: 60, stunDuration: 0.5 },
          });
          
        } else {
          // NADA
          state.addEffect({
            type: 'fail-poof',
            position: { x: currentPlayer.position.x, y: 2, z: currentPlayer.position.z },
            lifetime: 0.6,
            color: '#808080',
            scale: 1.5,
          });
        }
      }, 350);
      break;
    }
    
    // YUJI ITADORI - MANJI KICK (Counter)
    case 'yuji': {
      const playerId = player.id;
      const oppId = opponent.id;
      
      // Aura de counter
      addEffect({
        type: 'counter-stance',
        position: { ...player.position },
        lifetime: 1.0,
        color: '#FF6B6B',
        scale: 2.5,
      });
      
      updatePlayer(playerId, {
        isBlocking: true,
        damageBoost: 150,
        damageBoostTimer: 1.0,
      });
      
      // Sistema de counter
      let counterActivated = false;
      const counterWindow = 1000;
      let elapsed = 0;
      
      const intervalId = setInterval(() => {
        if (counterActivated) {
          clearInterval(intervalId);
          return;
        }
        
        elapsed += 30;
        if (elapsed >= counterWindow) {
          clearInterval(intervalId);
          useGameStore.getState().updatePlayer(playerId, {
            isBlocking: false,
            damageBoost: 0,
            damageBoostTimer: 0,
          });
          return;
        }
        
        const state = useGameStore.getState();
        const currentPlayer = state.player1.id === playerId ? state.player1 : state.player2;
        const currentOpponent = state.player1.id === playerId ? state.player2 : state.player1;
        
        const distCheck = getDistance(currentPlayer.position, currentOpponent.position);
        
        if (distCheck < 5.5 && currentOpponent.isAttacking) {
          counterActivated = true;
          clearInterval(intervalId);
          
          // COUNTER!
          state.addEffect({
            type: 'counter-flash',
            position: { ...currentPlayer.position },
            lifetime: 0.3,
            color: '#FFFFFF',
            scale: 4,
          });
          
          const kickDir = normalizeDirection(
            currentOpponent.position.x - currentPlayer.position.x,
            currentOpponent.position.z - currentPlayer.position.z
          );
          
          const knockPos = clampPosition(
            currentOpponent.position.x + kickDir.x * 6,
            currentOpponent.position.z + kickDir.z * 6
          );
          
          state.updatePlayer(oppId, {
            health: Math.max(0, currentOpponent.health - 24),
            stunned: 1.5,
            position: { x: knockPos.x, y: 0, z: knockPos.z },
            velocity: { x: 0, y: 0, z: 0 },
            isAttacking: false,
          });
          
          state.addEffect({
            type: 'kick-impact',
            position: { x: currentOpponent.position.x, y: 1.5, z: currentOpponent.position.z },
            lifetime: 0.5,
            color: '#FF0000',
            scale: 3,
          });
          
          state.updatePlayer(playerId, {
            isBlocking: false,
            damageBoost: 0,
            damageBoostTimer: 0,
          });
          
          state.setCameraShake(0.7);
        }
      }, 30);
      break;
    }
    
    // HARRY POTTER - EXPELLIARMUS
    case 'harry': {
      addEffect({
        type: 'wand-wave',
        position: {
          x: player.position.x + direction.x * 0.8,
          y: 1.5,
          z: player.position.z + direction.z * 0.8,
        },
        lifetime: 0.3,
        color: '#FF0000',
        scale: 1,
      });
      
      addProjectile({
        owner: player.id,
        position: {
          x: player.position.x + direction.x * 1.5,
          y: 1.3,
          z: player.position.z + direction.z * 1.5,
        },
        velocity: { x: direction.x * 48, y: 0, z: direction.z * 48 },
        damage: 8,
        lifetime: 1.5,
        color: '#FF0000',
        size: 0.4,
        effect: { stunDuration: 0.6 },
        visualType: 'magic',
      });
      
      // Cancelar projéteis
      const state = useGameStore.getState();
      for (const proj of state.projectiles) {
        if (proj.owner !== player.id) {
          const dist = getDistance(proj.position, player.position);
          if (dist < 6) {
            state.removeProjectile(proj.id);
            state.addEffect({
              type: 'spell-deflect',
              position: { ...proj.position },
              lifetime: 0.3,
              color: '#FF0000',
              scale: 1.5,
            });
          }
        }
      }
      break;
    }
    
    // BEN 10 - XLR8 DASH
    case 'ben10': {
      const playerId = player.id;
      const startPos = { ...player.position };
      
      // Flash Omnitrix
      addEffect({
        type: 'omnitrix-flash',
        position: { x: startPos.x, y: 1, z: startPos.z },
        lifetime: 0.4,
        color: '#00FF00',
        scale: 4,
      });
      
      updatePlayer(playerId, {
        currentForm: 'xlr8',
        formTimer: 5,
        isInvincible: true,
      });
      
      const dashDist = 15;
      const dashDest = clampPosition(
        startPos.x + direction.x * dashDist,
        startPos.z + direction.z * dashDist
      );
      
      // Mover
      updatePlayer(playerId, {
        position: { x: dashDest.x, y: 0, z: dashDest.z },
        velocity: { x: 0, y: 0, z: 0 },
      });
      
      // Efeito de velocidade
      addEffect({
        type: 'speed-trail',
        position: {
          x: (startPos.x + dashDest.x) / 2,
          y: 1,
          z: (startPos.z + dashDest.z) / 2,
        },
        lifetime: 0.4,
        color: '#00BFFF',
        scale: dashDist,
      });
      
      // Projéteis no caminho (menos para otimização)
      for (let i = 0; i < 5; i++) {
        const t = i / 5;
        const trailX = startPos.x + (dashDest.x - startPos.x) * t;
        const trailZ = startPos.z + (dashDest.z - startPos.z) * t;
        
        addProjectile({
          owner: playerId,
          position: { x: trailX, y: 1, z: trailZ },
          velocity: { x: 0, y: 0, z: 0 },
          damage: 4,
          lifetime: 0.15,
          color: '#00BFFF',
          size: 1,
          effect: { knockbackMultiplier: 0.3 },
        });
      }
      
      setTimeout(() => {
        useGameStore.getState().updatePlayer(playerId, { isInvincible: false });
      }, 200);
      
      setCameraShake(0.3);
      break;
    }
    
    // TANK - CONCRETE RIP
    case 'tank': {
      const playerId = player.id;
      const tankPos = { ...player.position };
      
      // Arrancar concreto
      addEffect({
        type: 'ground-rip',
        position: { x: tankPos.x, y: 0.1, z: tankPos.z },
        lifetime: 0.6,
        color: '#696969',
        scale: 3,
      });
      
      setCameraShake(0.4);
      
      // Arremesso após delay
      setTimeout(() => {
        const state = useGameStore.getState();
        const currentPlayer = state.player1.id === playerId ? state.player1 : state.player2;
        const currentOpponent = state.player1.id === playerId ? state.player2 : state.player1;
        
        // Direção exata para o oponente
        const dx = currentOpponent.position.x - currentPlayer.position.x;
        const dz = currentOpponent.position.z - currentPlayer.position.z;
        const dist = Math.sqrt(dx * dx + dz * dz);
        
        const throwDirX = dist > 0 ? dx / dist : direction.x;
        const throwDirZ = dist > 0 ? dz / dist : direction.z;
        
        // Projétil RETO
        state.addProjectile({
          owner: playerId,
          position: {
            x: currentPlayer.position.x + throwDirX * 2,
            y: 1.3,
            z: currentPlayer.position.z + throwDirZ * 2,
          },
          velocity: {
            x: throwDirX * 28,
            y: 0, // SEM velocidade vertical
            z: throwDirZ * 28,
          },
          damage: 24,
          lifetime: 3,
          color: '#696969',
          size: 2,
          effect: { knockbackMultiplier: 3.5, ignoreDefense: true },
          skillType: 'concrete-boulder',
        });
        
        state.setCameraShake(0.4);
      }, 350);
      break;
    }
    
    // ARCEUS - PLATE CHANGE
    case 'arceus': {
      const types = ['normal', 'fire', 'ice', 'electric'];
      const currentIdx = types.indexOf(player.currentForm || 'normal');
      const nextType = types[(currentIdx + 1) % types.length];
      
      const typeColors: Record<string, string> = {
        'normal': '#FFFFFF',
        'fire': '#FF4500',
        'ice': '#00BFFF',
        'electric': '#FFFF00',
      };
      
      updatePlayer(player.id, {
        currentForm: nextType,
        formTimer: 25,
      });
      
      addEffect({
        type: 'divine-ring',
        position: { ...player.position },
        lifetime: 0.8,
        color: typeColors[nextType],
        scale: 5,
      });
      
      addEffect({
        type: 'type-text',
        position: { x: player.position.x, y: 3.5, z: player.position.z },
        lifetime: 1,
        color: typeColors[nextType],
        scale: 1.5,
      });
      break;
    }
    
    // SCP-4975 - TEMPORAL CAMOUFLAGE
    case 'scp4975': {
      const playerId = player.id;
      
      addEffect({
        type: 'cloak-activate',
        position: { ...player.position },
        lifetime: 0.6,
        color: '#2F4F4F',
        scale: 2.5,
      });
      
      updatePlayer(playerId, {
        isInvisible: true,
        damageBoost: 60,
        damageBoostTimer: 10,
      });
      
      // Timer para remover
      setTimeout(() => {
        const state = useGameStore.getState();
        state.updatePlayer(playerId, { isInvisible: false });
        
        state.addEffect({
          type: 'decloak',
          position: { ...player.position },
          lifetime: 0.5,
          color: '#2F4F4F',
          scale: 2,
        });
      }, 10000);
      break;
    }
    
    default: {
      const charData = CHARACTERS[characterId as CharacterId];
      if (charData) {
        addProjectile({
          owner: player.id,
          position: {
            x: player.position.x + direction.x * 1.5,
            y: 1,
            z: player.position.z + direction.z * 1.5,
          },
          velocity: { x: direction.x * 30, y: 0, z: direction.z * 30 },
          damage: 10,
          lifetime: 2,
          color: charData.color,
          size: 0.5,
        });
      }
    }
  }
};

// ============== SKILL 2: HABILIDADES SECUNDÁRIAS ==============

export const executeSkill2 = (characterId: CharacterId, ctx: SkillContext): void => {
  const { player, opponent, direction, addProjectile, addEffect, addSummon, updatePlayer, setCameraShake } = ctx;
  
  switch (characterId) {
    
    // INK DEMON - SEARCHER AMBUSH (Armadilha)
    case 'ink-demon': {
      addEffect({
        type: 'ink-slam',
        position: { x: player.position.x, y: 0.1, z: player.position.z },
        lifetime: 0.5,
        color: '#1a1a1a',
        scale: 2,
      });
      
      const trapDist = 6;
      const trapPos = clampPosition(
        player.position.x + direction.x * trapDist,
        player.position.z + direction.z * trapDist
      );
      
      // Armadilha
      addSummon({
        owner: player.id,
        type: 'searcher-trap',
        position: { x: trapPos.x, y: 0.1, z: trapPos.z },
        targetId: opponent.id,
        damage: 14,
        lifetime: 20,
        speed: 0,
        behavior: 'trap',
      });
      
      addEffect({
        type: 'trap-place',
        position: { x: trapPos.x, y: 0.03, z: trapPos.z },
        lifetime: 20,
        color: '#000000',
        scale: 3,
      });
      break;
    }
    
    // VAPOR - SKULL BARRAGE
    case 'vapor': {
      addEffect({
        type: 'dark-ritual',
        position: { ...player.position },
        lifetime: 0.5,
        color: '#8B0000',
        scale: 3,
      });
      
      // 3 crânios
      for (let i = 0; i < 3; i++) {
        const angle = (i / 3) * Math.PI * 2;
        const orbRadius = 2;
        
        addSummon({
          owner: player.id,
          type: 'spectral-skull',
          position: {
            x: player.position.x + Math.cos(angle) * orbRadius,
            y: 1.8,
            z: player.position.z + Math.sin(angle) * orbRadius,
          },
          targetId: opponent.id,
          damage: 8,
          lifetime: 15,
          speed: 14,
          behavior: 'chase',
        });
      }
      break;
    }
    
    // PILGOR - HEADBUTT
    case 'pilgor': {
      const oppId = opponent.id;
      const startPos = { ...player.position };
      
      addEffect({
        type: 'headbutt-charge',
        position: { ...startPos },
        lifetime: 0.25,
        color: '#f5f5dc',
        scale: 2,
      });
      
      const headbuttDist = 7;
      const dest = clampPosition(
        startPos.x + direction.x * headbuttDist,
        startPos.z + direction.z * headbuttDist
      );
      
      updatePlayer(player.id, {
        position: { x: dest.x, y: 0, z: dest.z },
        velocity: { x: 0, y: 0, z: 0 },
        isInvincible: true,
      });
      
      const distToOpp = getDistance(startPos, opponent.position);
      if (distToOpp <= headbuttDist + 2.5) {
        const knockDir = normalizeDirection(direction.x, direction.z);
        const knockDist = 12;
        const knockPos = clampPosition(
          opponent.position.x + knockDir.x * knockDist,
          opponent.position.z + knockDir.z * knockDist
        );
        
        updatePlayer(oppId, {
          position: { x: knockPos.x, y: 0, z: knockPos.z },
          velocity: { x: 0, y: 0, z: 0 },
          health: Math.max(0, opponent.health - 16),
          stunned: 1.2,
        });
        
        addEffect({
          type: 'headbutt-impact',
          position: { x: opponent.position.x, y: 1.5, z: opponent.position.z },
          lifetime: 0.5,
          color: '#FFFF00',
          scale: 3,
        });
        
        setCameraShake(0.9);
      }
      
      setTimeout(() => {
        useGameStore.getState().updatePlayer(player.id, { isInvincible: false });
      }, 250);
      break;
    }
    
    // SHREK - ONION GRENADE
    case 'shrek': {
      addProjectile({
        owner: player.id,
        position: {
          x: player.position.x + direction.x * 1.5,
          y: 2,
          z: player.position.z + direction.z * 1.5,
        },
        velocity: {
          x: direction.x * 22,
          y: 6,
          z: direction.z * 22,
        },
        damage: 18,
        lifetime: 3.5,
        color: '#FAEBD7',
        size: 0.8,
        effect: { aoeRadius: 5.5, slowPercent: 50 },
        skillType: 'onion-bomb',
      });
      break;
    }
    
    // WALUIGI - ROSE WHIP
    case 'waluigi': {
      for (let i = 0; i < 5; i++) {
        const hitDist = 2 + i * 1.8;
        
        setTimeout(() => {
          const state = useGameStore.getState();
          
          state.addProjectile({
            owner: player.id,
            position: {
              x: player.position.x + direction.x * hitDist,
              y: 1.2,
              z: player.position.z + direction.z * hitDist,
            },
            velocity: { x: direction.x * 35, y: 0, z: direction.z * 35 },
            damage: i === 4 ? 14 : 5,
            lifetime: 0.18,
            color: '#FF1493',
            size: i === 4 ? 0.7 : 0.4,
            effect: i === 4 ? { stunDuration: 1.5 } : undefined,
          });
          
          state.addEffect({
            type: 'rose-petal',
            position: {
              x: player.position.x + direction.x * hitDist,
              y: 1.5,
              z: player.position.z + direction.z * hitDist,
            },
            lifetime: 0.5,
            color: '#FF69B4',
            scale: 0.5,
          });
        }, i * 60);
      }
      break;
    }
    
    // SEIYA - PEGASUS METEOR FIST (Meteoro de Pégaso)
    case 'seiya': {
      const playerId = player.id;
      
      addEffect({
        type: 'cosmos-explosion',
        position: { ...player.position },
        lifetime: 0.6,
        color: '#FFD700',
        scale: 3,
      });
      
      // 30 meteoros - CADA UM USA A POSIÇÃO ATUAL DO SEIYA
      for (let i = 0; i < 30; i++) {
        setTimeout(() => {
          const state = useGameStore.getState();
          
          // Obter posição ATUAL do Seiya
          let currentSeiya: Player | null = null;
          if (state.player1.id === playerId) currentSeiya = state.player1;
          else if (state.player2.id === playerId) currentSeiya = state.player2;
          else if (state.player3?.id === playerId) currentSeiya = state.player3;
          else if (state.player4?.id === playerId) currentSeiya = state.player4;
          
          if (!currentSeiya || !currentSeiya.isAlive) return;
          
          // Calcular direção ATUAL baseada na rotação do Seiya
          const currentDirX = Math.sin(currentSeiya.rotation);
          const currentDirZ = Math.cos(currentSeiya.rotation);
          
          const spread = 0.35;
          const spreadX = currentDirX + (Math.random() - 0.5) * spread;
          const spreadZ = currentDirZ + (Math.random() - 0.5) * spread;
          const normDir = normalizeDirection(spreadX, spreadZ);
          
          state.addProjectile({
            owner: playerId,
            position: {
              x: currentSeiya.position.x + normDir.x * 1.5,
              y: 1 + (Math.random() - 0.5) * 0.5,
              z: currentSeiya.position.z + normDir.z * 1.5,
            },
            velocity: {
              x: normDir.x * 45,
              y: (Math.random() - 0.5) * 2,
              z: normDir.z * 45,
            },
            damage: 1.2,
            lifetime: 1.2,
            color: '#87CEEB',
            size: 0.25,
            visualType: 'cosmic',
          });
          
          // Efeito visual a cada 5 meteoros
          if (i % 5 === 0) {
            state.addEffect({
              type: 'cosmos-burst',
              position: { x: currentSeiya.position.x, y: 1.2, z: currentSeiya.position.z },
              lifetime: 0.2,
              color: '#4169E1',
              scale: 1.5,
            });
          }
        }, i * 35);
      }
      break;
    }
    
    // MAN FROM FOG - LIGHTNING SMITE
    case 'man-from-fog': {
      const targetX = opponent.position.x;
      const targetZ = opponent.position.z;
      
      addEffect({
        type: 'lightning-warning',
        position: { x: targetX, y: 0.1, z: targetZ },
        lifetime: 0.7,
        color: '#FFFF00',
        scale: 4,
      });
      
      setTimeout(() => {
        const state = useGameStore.getState();
        
        state.addProjectile({
          owner: player.id,
          position: { x: targetX, y: 20, z: targetZ },
          velocity: { x: 0, y: -140, z: 0 },
          damage: 22,
          lifetime: 0.35,
          color: '#FFFF00',
          size: 2,
          effect: { aoeRadius: 3.5, ignoreDefense: true },
          visualType: 'electric',
        });
        
        state.addEffect({
          type: 'lightning-impact',
          position: { x: targetX, y: 0.5, z: targetZ },
          lifetime: 0.4,
          color: '#FFFF00',
          scale: 4,
        });
        
        state.setCameraShake(0.7);
      }, 600);
      break;
    }
    
    // DANDY - TAPE RESTRAINT
    case 'dandy': {
      for (let i = 0; i < 3; i++) {
        const spreadAngle = (i - 1) * 0.6;
        const trapDist = 4 + i * 2.5;
        
        const trapX = player.position.x +
          (direction.x * Math.cos(spreadAngle) - direction.z * Math.sin(spreadAngle)) * trapDist;
        const trapZ = player.position.z +
          (direction.x * Math.sin(spreadAngle) + direction.z * Math.cos(spreadAngle)) * trapDist;
        
        const clamped = clampPosition(trapX, trapZ);
        
        addSummon({
          owner: player.id,
          type: 'tape-trap',
          position: { x: clamped.x, y: 0.1, z: clamped.z },
          targetId: opponent.id,
          damage: 7,
          lifetime: 25,
          speed: 0,
          behavior: 'trap',
        });
      }
      break;
    }
    
    // YUJI - DIVERGENT FIST
    case 'yuji': {
      addProjectile({
        owner: player.id,
        position: {
          x: player.position.x + direction.x * 2,
          y: 1.2,
          z: player.position.z + direction.z * 2,
        },
        velocity: { x: direction.x * 42, y: 0, z: direction.z * 42 },
        damage: 10,
        lifetime: 0.22,
        color: '#FF6B6B',
        size: 0.8,
      });
      
      addEffect({
        type: 'cursed-punch',
        position: {
          x: player.position.x + direction.x * 2,
          y: 1,
          z: player.position.z + direction.z * 2,
        },
        lifetime: 0.4,
        color: '#8B0000',
        scale: 2,
      });
      
      // Segundo impacto
      setTimeout(() => {
        const state = useGameStore.getState();
        const currentPlayer = state.player1.id === player.id ? state.player1 : state.player2;
        
        state.addProjectile({
          owner: player.id,
          position: {
            x: currentPlayer.position.x + direction.x * 4,
            y: 1.2,
            z: currentPlayer.position.z + direction.z * 4,
          },
          velocity: { x: direction.x * 38, y: 0, z: direction.z * 38 },
          damage: 18,
          lifetime: 0.28,
          color: '#0000FF',
          size: 1.4,
          effect: { knockbackMultiplier: 3.5 },
        });
        
        state.addEffect({
          type: 'divergent-explosion',
          position: {
            x: currentPlayer.position.x + direction.x * 4,
            y: 1,
            z: currentPlayer.position.z + direction.z * 4,
          },
          lifetime: 0.5,
          color: '#0000FF',
          scale: 3,
        });
        
        state.setCameraShake(0.5);
      }, 450);
      break;
    }
    
    // HARRY - STUPEFY + INCENDIO
    case 'harry': {
      addProjectile({
        owner: player.id,
        position: {
          x: player.position.x + direction.x * 1.5,
          y: 1.2,
          z: player.position.z + direction.z * 1.5,
        },
        velocity: { x: direction.x * 38, y: 0, z: direction.z * 38 },
        damage: 12,
        lifetime: 2,
        color: '#FF0000',
        size: 0.7,
        effect: { stunDuration: 1.3 },
        visualType: 'magic',
      });
      
      setTimeout(() => {
        const state = useGameStore.getState();
        
        state.addProjectile({
          owner: player.id,
          position: {
            x: player.position.x + direction.x * 1.5,
            y: 1.2,
            z: player.position.z + direction.z * 1.5,
          },
          velocity: { x: direction.x * 32, y: 0, z: direction.z * 32 },
          damage: 16,
          lifetime: 2.5,
          color: '#FF6600',
          size: 1.2,
          effect: { aoeRadius: 5 },
          visualType: 'fire',
        });
      }, 400);
      break;
    }
    
    // BEN 10 - FOUR ARMS SMASH
    case 'ben10': {
      addEffect({
        type: 'omnitrix-transform',
        position: { ...player.position },
        lifetime: 0.5,
        color: '#00FF00',
        scale: 4,
      });
      
      updatePlayer(player.id, {
        currentForm: 'fourarms',
        formTimer: 12,
        superArmor: true,
      });
      
      setTimeout(() => {
        const state = useGameStore.getState();
        const currentPlayer = state.player1.id === player.id ? state.player1 : state.player2;
        const currentOpponent = state.player1.id === player.id ? state.player2 : state.player1;
        const oppId = currentOpponent.id;
        
        state.addEffect({
          type: 'fourarms-slam',
          position: { x: currentPlayer.position.x, y: 0.1, z: currentPlayer.position.z },
          lifetime: 1,
          color: '#FF4500',
          scale: 6,
        });
        
        const slamDist = getDistance(currentPlayer.position, currentOpponent.position);
        
        if (slamDist < 7) {
          const knockDir = normalizeDirection(
            currentOpponent.position.x - currentPlayer.position.x,
            currentOpponent.position.z - currentPlayer.position.z
          );
          
          const knockPos = clampPosition(
            currentOpponent.position.x + knockDir.x * 7,
            currentOpponent.position.z + knockDir.z * 7
          );
          
          state.updatePlayer(oppId, {
            health: Math.max(0, currentOpponent.health - 32),
            stunned: 1.6,
            position: { x: knockPos.x, y: 0, z: knockPos.z },
            velocity: { x: 0, y: 0, z: 0 },
          });
        }
        
        state.setCameraShake(0.9);
      }, 450);
      break;
    }
    
    // TANK - BULL RUSH
    case 'tank': {
      const chargeDist = 14;
      const startPos = { ...player.position };
      const chargeDest = clampPosition(
        startPos.x + direction.x * chargeDist,
        startPos.z + direction.z * chargeDist
      );
      
      // Menos hits no caminho
      const steps = 6;
      for (let i = 0; i < steps; i++) {
        const t = i / steps;
        const pathX = startPos.x + (chargeDest.x - startPos.x) * t;
        const pathZ = startPos.z + (chargeDest.z - startPos.z) * t;
        
        setTimeout(() => {
          const state = useGameStore.getState();
          
          state.addProjectile({
            owner: player.id,
            position: { x: pathX, y: 1, z: pathZ },
            velocity: { x: 0, y: 0, z: 0 },
            damage: 18,
            lifetime: 0.12,
            color: '#8B4513',
            size: 1.8,
            effect: { aoeRadius: 3.5 },
          });
          
          state.addEffect({
            type: 'charge-dust',
            position: { x: pathX, y: 0.5, z: pathZ },
            lifetime: 0.6,
            color: '#A0522D',
            scale: 2.5,
          });
        }, i * 50);
      }
      
      updatePlayer(player.id, {
        position: { x: chargeDest.x, y: 0, z: chargeDest.z },
      });
      
      setCameraShake(1);
      break;
    }
    
    // ARCEUS - HYPER VOICE
    case 'arceus': {
      addEffect({
        type: 'divine-voice',
        position: { ...player.position },
        lifetime: 1,
        color: '#FFFFFF',
        scale: 12,
      });
      
      // Refletir projéteis
      const state = useGameStore.getState();
      for (const proj of state.projectiles) {
        if (proj.owner !== player.id) {
          const dist = getDistance(proj.position, player.position);
          if (dist < 14) {
            state.removeProjectile(proj.id);
            state.addProjectile({
              owner: player.id,
              position: { ...proj.position },
              velocity: {
                x: -proj.velocity.x * 1.5,
                y: proj.velocity.y,
                z: -proj.velocity.z * 1.5,
              },
              damage: proj.damage * 1.5,
              lifetime: proj.lifetime,
              color: '#FFD700',
              size: proj.size,
            });
          }
        }
      }
      
      // Empurrar oponente
      const pushDist = getDistance(player.position, opponent.position);
      if (pushDist < 14) {
        const pushDir = normalizeDirection(
          opponent.position.x - player.position.x,
          opponent.position.z - player.position.z
        );
        
        const pushPos = clampPosition(
          opponent.position.x + pushDir.x * 8,
          opponent.position.z + pushDir.z * 8
        );
        
        updatePlayer(opponent.id, {
          position: { x: pushPos.x, y: 0, z: pushPos.z },
          health: Math.max(0, opponent.health - 14),
        });
      }
      break;
    }
    
    // SCP-4975 - BEAK PIERCE
    case 'scp4975': {
      addProjectile({
        owner: player.id,
        position: {
          x: player.position.x + direction.x * 1.5,
          y: 1.5,
          z: player.position.z + direction.z * 1.5,
        },
        velocity: { x: direction.x * 65, y: 0, z: direction.z * 65 },
        damage: 16,
        lifetime: 0.12,
        color: '#2F4F4F',
        size: 0.55,
        effect: {
          ignoreDefense: true,
          dotDamage: 6,
          dotDuration: 6,
        },
      });
      
      addEffect({
        type: 'beak-slash',
        position: {
          x: player.position.x + direction.x * 2.5,
          y: 1.5,
          z: player.position.z + direction.z * 2.5,
        },
        lifetime: 0.3,
        color: '#FF4500',
        scale: 1.5,
      });
      break;
    }
    
    default: {
      const charData = CHARACTERS[characterId as CharacterId];
      if (charData) {
        addProjectile({
          owner: player.id,
          position: {
            x: player.position.x + direction.x * 1.5,
            y: 1,
            z: player.position.z + direction.z * 1.5,
          },
          velocity: { x: direction.x * 24, y: 0, z: direction.z * 24 },
          damage: 16,
          lifetime: 2.5,
          color: charData.secondaryColor,
          size: 0.9,
        });
      }
    }
  }
};

// ============== SPECIAL ATTACK (BARRA G) ==============

export const executeSpecialAttack = (characterId: CharacterId, ctx: SkillContext): void => {
  const { player, opponent, direction, addProjectile, addEffect, updatePlayer, setCameraShake } = ctx;
  const character = CHARACTERS[characterId];
  
  switch (characterId) {
    // INK DEMON - CRESCENT CUTTER
    case 'ink-demon': {
      addEffect({
        type: 'ink-blade-charge',
        position: { ...player.position },
        lifetime: 0.4,
        color: '#1a1a1a',
        scale: 3,
      });
      
      addProjectile({
        owner: player.id,
        position: {
          x: player.position.x + direction.x * 2,
          y: 1.2,
          z: player.position.z + direction.z * 2,
        },
        velocity: { x: direction.x * 42, y: 0, z: direction.z * 42 },
        damage: 28,
        lifetime: 3,
        color: '#1a1a1a',
        size: 1.8,
        skillType: 'crescent-cutter',
      });
      
      setCameraShake(0.5);
      break;
    }
    
    // VAPOR - SPIDER CRAWL
    case 'vapor': {
      const oppId = opponent.id;
      
      updatePlayer(player.id, { isInvincible: true });
      
      addEffect({
        type: 'spider-morph',
        position: { ...player.position },
        lifetime: 0.4,
        color: '#8B0000',
        scale: 2.5,
      });
      
      setTimeout(() => {
        const state = useGameStore.getState();
        const currentOpponent = state.player1.id === player.id ? state.player2 : state.player1;
        
        const toOppDir = normalizeDirection(
          currentOpponent.position.x - player.position.x,
          currentOpponent.position.z - player.position.z
        );
        
        state.updatePlayer(player.id, {
          position: {
            x: currentOpponent.position.x - toOppDir.x * 1.5,
            y: 0,
            z: currentOpponent.position.z - toOppDir.z * 1.5,
          },
        });
        
        state.updatePlayer(oppId, {
          health: Math.max(0, currentOpponent.health - 28),
        });
        
        state.addEffect({
          type: 'bite-impact',
          position: { ...currentOpponent.position },
          lifetime: 0.6,
          color: '#FF0000',
          scale: 3,
        });
        
        state.updatePlayer(player.id, { isInvincible: false });
        state.setCameraShake(0.7);
      }, 300);
      break;
    }
    
    // PILGOR - JETPACK MALFUNCTION
    case 'pilgor': {
      addEffect({
        type: 'jetpack-activate',
        position: { ...player.position },
        lifetime: 0.5,
        color: '#FF4500',
        scale: 2,
      });
      
      for (let i = 0; i < 8; i++) {
        setTimeout(() => {
          const angle = Math.random() * Math.PI * 2;
          const dist = 2 + Math.random() * 6;
          
          useGameStore.getState().addProjectile({
            owner: player.id,
            position: {
              x: player.position.x + Math.cos(angle) * dist,
              y: 1.5 + Math.random() * 3,
              z: player.position.z + Math.sin(angle) * dist,
            },
            velocity: {
              x: (Math.random() - 0.5) * 15,
              y: -12,
              z: (Math.random() - 0.5) * 15,
            },
            damage: 12,
            lifetime: 0.6,
            color: '#FF4500',
            size: 0.8,
            visualType: 'fire',
          });
        }, i * 150);
      }
      break;
    }
    
    // SHREK - WRESTLING SLAM
    case 'shrek': {
      const grabDist = getDistance(player.position, opponent.position);
      const oppId = opponent.id;
      
      if (grabDist < 5) {
        const slamDir = normalizeDirection(direction.x, direction.z);
        const oppHealth = opponent.health;
        
        updatePlayer(oppId, { stunned: 2.5 });
        
        addEffect({
          type: 'ogre-grab',
          position: { ...opponent.position },
          lifetime: 0.6,
          color: '#7CFC00',
          scale: 3,
        });
        
        setTimeout(() => {
          const state = useGameStore.getState();
          
          const slamPos = clampPosition(
            player.position.x - slamDir.x * 3,
            player.position.z - slamDir.z * 3
          );
          
          state.updatePlayer(oppId, {
            health: Math.max(0, oppHealth - 38),
            stunned: 1.7,
            position: { x: slamPos.x, y: 0, z: slamPos.z },
            velocity: { x: 0, y: 0, z: 0 },
          });
          
          state.addEffect({
            type: 'slam-crater',
            position: { x: slamPos.x, y: 0.1, z: slamPos.z },
            lifetime: 0.8,
            color: '#8B4513',
            scale: 5,
          });
          
          state.setCameraShake(1);
        }, 700);
      } else {
        addProjectile({
          owner: player.id,
          position: {
            x: player.position.x + direction.x * 2,
            y: 1.2,
            z: player.position.z + direction.z * 2,
          },
          velocity: { x: direction.x * 32, y: 0, z: direction.z * 32 },
          damage: 20,
          lifetime: 0.28,
          color: '#7CFC00',
          size: 1.3,
          effect: { knockbackMultiplier: 2.5 },
        });
      }
      break;
    }
    
    default: {
      addEffect({
        type: 'special-charge',
        position: { ...player.position },
        lifetime: 0.4,
        color: character.secondaryColor,
        scale: 3,
      });
      
      addProjectile({
        owner: player.id,
        position: {
          x: player.position.x + direction.x * 1.5,
          y: 1,
          z: player.position.z + direction.z * 1.5,
        },
        velocity: { x: direction.x * 38, y: 0, z: direction.z * 38 },
        damage: character.specialDamage,
        lifetime: 2.5,
        color: character.secondaryColor,
        size: 1.4,
        effect: { knockbackMultiplier: 4 },
      });
      
      setCameraShake(0.6);
    }
  }
};
